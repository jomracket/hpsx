
#include "R3000A.h"
#include "R3000A_Lookup.h"
#include "x64Encoder.h"


#ifndef _R3000A_RECOMPILER_H_
#define _R3000A_RECOMPILER_H_

namespace R3000A
{
	// will probably create two recompilers for each processor. one for single stepping and one for multi-stepping
	class Recompiler
	{
	public:
		// number of code cache slots total
		// but the number of blocks should be variable
		//static const int c_iNumBlocks = 1024;
		//static const u32 c_iNumBlocks_Mask = c_iNumBlocks - 1;
		u32 NumBlocks;
		u32 NumBlocks_Mask;
		//static const int c_iBlockSize_Shift = 4;
		//static const int c_iBlockSize_Mask = ( 1 << c_iBlockSize_Shift ) - 1;
		
		static const u32 c_iAddress_Mask = 0x1fffffff;
		
		u32 TotalCodeCache_Size;	// = c_iNumBlocks * ( 1 << c_iBlockSize_Shift );
		
		u32 BlockSize;
		u32 BlockSize_Shift;
		u32 BlockSize_Mask;
		
		// maximum number of instructions that can be encoded/recompiled in a run
		u32 MaxStep;
		u32 MaxStep_Shift;
		u32 MaxStep_Mask;
		
		// the PC while recompiling
		static u32 LocalPC;
		
		// the optimization level
		// 0 means no optimization at all, anything higher means to optimize
		static s32 OpLevel;
		u32 OptimizeLevel;
		
		// the current enabled encoder
		static x64Encoder *e;
		//static ICache_Device *ICache;
		static Cpu *r;
		
		// the encoder for this particular instance
		x64Encoder *InstanceEncoder;
		
		// constructor
		// block size must be power of two, multiplier shift value
		// so for BlockSize_PowerOfTwo, for a block size of 4 pass 2, block size of 8 pass 3, etc
		// for MaxStep, use 0 for single stepping, 1 for stepping until end of 1 cache block, 2 for stepping until end of 2 cache blocks, etc
		// no, for MaxStep, it should be the maximum number of instructions to step
		// NumberOfBlocks MUST be a power of 2, where 1 means 2, 2 means 4, etc
		Recompiler ( Cpu* R3000ACpu, u32 NumberOfBlocks, u32 BlockSize_PowerOfTwo, u32 MaxIStep );
		
		// destructor
		~Recompiler ();
		
		
		void Reset ();	// { memset ( this, 0, sizeof( Recompiler ) ); }

		
		// set the optimization level
		inline void SetOptimizationLevel ( u32 Level ) { OptimizeLevel = Level; }
		
		// accessors
		inline u32 Get_DoNotCache ( u32 Address ) { return DoNotCache [ ( Address >> 2 ) & NumBlocks_Mask ]; }
		inline u32 Get_CacheMissCount ( u32 Address ) { return CacheMissCount [ ( Address >> 2 ) & NumBlocks_Mask ]; }
		inline u32 Get_StartAddress ( u32 Address ) { return StartAddress [ ( Address >> 2 ) & NumBlocks_Mask ]; }
		//inline u32 Get_LastAddress ( u32 Address ) { return LastAddress [ ( Address >> 2 ) & NumBlocks_Mask ]; }
		inline u32 Get_RunCount ( u32 Address ) { return RunCount [ ( Address >> 2 ) & NumBlocks_Mask ]; }
		inline u32 Get_MaxCycles ( u32 Address ) { return MaxCycles [ ( Address >> 2 ) & NumBlocks_Mask ]; }
		
		// returns a pointer to the instructions cached starting at Address
		// this function assumes that this instance of recompiler only has one instruction per run
		inline u32* Get_InstructionsPtr ( u32 Address ) { return & ( Instructions [ ( ( Address >> 2 ) & NumBlocks_Mask ) << MaxStep_Shift ] ); }
		
		// returns a pointer to the start addresses cached starting at Address
		// this function assumes that this instance of recompiler only has one instruction per run
		inline u32* Get_AddressPtr ( u32 Address ) { return & ( StartAddress [ ( ( Address >> 2 ) & NumBlocks_Mask ) ] ); }
		
		// check that Address is not -1
		// returns 1 if address is ok, returns 0 if it is not ok
		inline bool isBlockValid ( u32 Address ) { return ( StartAddress [ ( Address >> 2 ) & NumBlocks_Mask ] != 0xffffffff ); }
		
		// check that Address matches StartAddress for the block
		// returns 1 if address is ok, returns 0 if it is not ok
		inline bool isStartAddressMatch ( u32 Address ) { return ( Address == StartAddress [ ( Address >> 2 ) & NumBlocks_Mask ] ); }
		
		// this function assumes that this instance of recompiler only has one instruction per run
		// returns 1 if the instruction is cached for address, 0 otherwise
		inline bool isCached ( u32 Address, u32 Instruction ) { return ( Address == StartAddress [ ( Address >> 2 ) & NumBlocks_Mask ] ) && ( Instruction == Instructions [ ( Address >> 2 ) & NumBlocks_Mask ] ); }
		
		inline bool isRecompiled ( u32 BeginAddress, u32* InstructionList )
		{
			u32 Index, RunSize;
			u32 *InstrPtr;
			
			Index = ( ( BeginAddress >> 2 ) & NumBlocks_Mask );
			
			if ( BeginAddress != StartAddress [ Index ] ) return false;
			
			RunSize = RunCount [ Index ];
			Index <<= MaxStep_Shift;
			InstrPtr = & ( Instructions [ Index ] );
			for ( int i = 0; i < RunSize; i++ )
			{
				if ( *InstrPtr++ != *InstructionList++ ) return false;
			}
			return true;
		}
		
		inline u64 Execute ( u32 Address ) { InstanceEncoder->ExecuteCodeBlock ( ( Address >> 2 ) & NumBlocks_Mask ); }
		
		// says if block points to an R3000A instruction that should NOT be EVER cached
		// *note* this should be dynamically allocated
		u8* DoNotCache;	// [ c_iNumBlocks ];
		
		// number of times a cache miss was encountered while recompiling for this block
		// *note* this should be dynamically allocated
		u32* CacheMissCount;	// [ c_iNumBlocks ];
		
		// code cache block not invalidated
		// *note* this should be dynamically allocated
		//u8 isValid [ c_iNumBlocks ];
		
		// start address for instruction encodings (inclusive)
		// *note* this should be dynamically allocated
		u32* StartAddress;	// [ c_iNumBlocks ];
		
		// last address that instruction encoding is valid for (inclusive)
		// *note* this should be dynamically allocated
		// It actually makes things MUCH simpler if you store the number of instructions recompiled instead of the last address
		//u32* LastAddress;	// [ c_iNumBlocks ];
		u32* RunCount;
		
		u32* Instructions;
		
		// max number of cycles that instruction encoding could use up if executed
		// need to know this to single step when there are interrupts in between
		// code block is not valid when this is zero
		// *note* this should be dynamically allocated
		u64* MaxCycles;	// [ c_iNumBlocks ];
		
		static u32 Local_LastModifiedReg;
		static u32 Local_NextPCModified;
		
		static u32 CurrentCount;
		
		static u32 isBranchDelaySlot;
		static u32 isLoadDelaySlot;
		
		static u32 bStopEncodingAfter;
		static u32 bStopEncodingBefore;
		
		// recompiler function
		// returns -1 if the instruction cannot be recompiled, otherwise returns the maximum number of cycles the instruction uses
		typedef long (*Function) ( Instruction::Format Instruction, u32 Address );

		// *** todo *** do not recompile more than one instruction if currently in a branch delay slot or load delay slot!!
		u32 Recompile ( u32 StartAddress, void* SrcCode );
		//void Invalidate ( u32 Address );
		void Invalidate ( u32 Address, u32 Count );
		
		u32 CloseOpLevel ( u32 OptLevel, u32 Address );
		
		//void Recompile ( u32 Instruction );
		
			static const Function FunctionList [];
			
		// used by object to recompile an instruction into a code block
		// returns -1 if the instruction cannot be recompiled
		// returns 0 if the instruction was recompiled, but MUST start a new block for the next instruction (because it is guaranteed in a delay slot)
		// returns 1 if successful and can continue recompiling
		inline static long Recompile ( Instruction::Format i, u32 Address ) { return FunctionList [ Instruction::Lookup::FindByInstruction ( i.Value ) ] ( i, Address ); }
		
		
		inline void Run ( u32 Address ) { InstanceEncoder->ExecuteCodeBlock ( ( Address >> 2 ) & NumBlocks_Mask ); }

			static long Invalid ( Instruction::Format i, u32 Address );

			static long J ( Instruction::Format i, u32 Address );
			static long JAL ( Instruction::Format i, u32 Address );
			static long BEQ ( Instruction::Format i, u32 Address );
			static long BNE ( Instruction::Format i, u32 Address );
			static long BLEZ ( Instruction::Format i, u32 Address );
			static long BGTZ ( Instruction::Format i, u32 Address );
			static long ADDI ( Instruction::Format i, u32 Address );
			static long ADDIU ( Instruction::Format i, u32 Address );
			static long SLTI ( Instruction::Format i, u32 Address );
			static long SLTIU ( Instruction::Format i, u32 Address );
			static long ANDI ( Instruction::Format i, u32 Address );
			static long ORI ( Instruction::Format i, u32 Address );
			static long XORI ( Instruction::Format i, u32 Address );
			static long LUI ( Instruction::Format i, u32 Address );
			static long LB ( Instruction::Format i, u32 Address );
			static long LH ( Instruction::Format i, u32 Address );
			static long LWL ( Instruction::Format i, u32 Address );
			static long LW ( Instruction::Format i, u32 Address );
			static long LBU ( Instruction::Format i, u32 Address );
			static long LHU ( Instruction::Format i, u32 Address );
			
			static long LWR ( Instruction::Format i, u32 Address );
			static long SB ( Instruction::Format i, u32 Address );
			static long SH ( Instruction::Format i, u32 Address );
			static long SWL ( Instruction::Format i, u32 Address );
			static long SW ( Instruction::Format i, u32 Address );
			static long SWR ( Instruction::Format i, u32 Address );
			static long LWC2 ( Instruction::Format i, u32 Address );
			static long SWC2 ( Instruction::Format i, u32 Address );
			static long SLL ( Instruction::Format i, u32 Address );
			static long SRL ( Instruction::Format i, u32 Address );
			static long SRA ( Instruction::Format i, u32 Address );
			static long SLLV ( Instruction::Format i, u32 Address );
			static long SRLV ( Instruction::Format i, u32 Address );
			static long SRAV ( Instruction::Format i, u32 Address );
			static long JR ( Instruction::Format i, u32 Address );
			static long JALR ( Instruction::Format i, u32 Address );
			static long SYSCALL ( Instruction::Format i, u32 Address );
			static long BREAK ( Instruction::Format i, u32 Address );
			static long MFHI ( Instruction::Format i, u32 Address );
			static long MTHI ( Instruction::Format i, u32 Address );

			static long MFLO ( Instruction::Format i, u32 Address );
			static long MTLO ( Instruction::Format i, u32 Address );
			static long MULT ( Instruction::Format i, u32 Address );
			static long MULTU ( Instruction::Format i, u32 Address );
			static long DIV ( Instruction::Format i, u32 Address );
			static long DIVU ( Instruction::Format i, u32 Address );
			static long ADD ( Instruction::Format i, u32 Address );
			static long ADDU ( Instruction::Format i, u32 Address );
			static long SUB ( Instruction::Format i, u32 Address );
			static long SUBU ( Instruction::Format i, u32 Address );
			static long AND ( Instruction::Format i, u32 Address );
			static long OR ( Instruction::Format i, u32 Address );
			static long XOR ( Instruction::Format i, u32 Address );
			static long NOR ( Instruction::Format i, u32 Address );
			static long SLT ( Instruction::Format i, u32 Address );
			static long SLTU ( Instruction::Format i, u32 Address );
			static long BLTZ ( Instruction::Format i, u32 Address );
			static long BGEZ ( Instruction::Format i, u32 Address );
			static long BLTZAL ( Instruction::Format i, u32 Address );
			static long BGEZAL ( Instruction::Format i, u32 Address );

			static long MFC0 ( Instruction::Format i, u32 Address );
			static long MTC0 ( Instruction::Format i, u32 Address );
			static long RFE ( Instruction::Format i, u32 Address );
			static long MFC2 ( Instruction::Format i, u32 Address );
			static long CFC2 ( Instruction::Format i, u32 Address );
			static long MTC2 ( Instruction::Format i, u32 Address );
			static long CTC2 ( Instruction::Format i, u32 Address );
			static long COP2 ( Instruction::Format i, u32 Address );
			
			static long RTPS ( Instruction::Format i, u32 Address );
			static long NCLIP ( Instruction::Format i, u32 Address );
			static long OP ( Instruction::Format i, u32 Address );
			static long DPCS ( Instruction::Format i, u32 Address );
			static long INTPL ( Instruction::Format i, u32 Address );
			static long MVMVA ( Instruction::Format i, u32 Address );
			static long NCDS ( Instruction::Format i, u32 Address );
			static long CDP ( Instruction::Format i, u32 Address );
			static long NCDT ( Instruction::Format i, u32 Address );
			static long NCCS ( Instruction::Format i, u32 Address );
			static long CC ( Instruction::Format i, u32 Address );
			static long NCS ( Instruction::Format i, u32 Address );
			static long NCT ( Instruction::Format i, u32 Address );
			static long SQR ( Instruction::Format i, u32 Address );
			static long DCPL ( Instruction::Format i, u32 Address );
			static long DPCT ( Instruction::Format i, u32 Address );
			static long AVSZ3 ( Instruction::Format i, u32 Address );
			static long AVSZ4 ( Instruction::Format i, u32 Address );
			static long RTPT ( Instruction::Format i, u32 Address );
			static long GPF ( Instruction::Format i, u32 Address );
			static long GPL ( Instruction::Format i, u32 Address );
			static long NCCT ( Instruction::Format i, u32 Address );

	};
};

#endif
