
#include <iostream>
#include "R5900_Lookup.h"

int main ( void )
{
	cout << "\ntesting";
	cin.ignore ();
	return 0;
}