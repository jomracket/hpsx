/*
	Copyright (C) 2012-2016

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/




#include "R5900_Recompile.h"
#include "R5900_Lookup.h"

#include "VU.h"
#include "VU_Execute.h"
#include "PS2Float.h"

#include "R5900_Print.h"

#include "GeneralUtilities.h"

#include <iostream>
#include <iomanip>

using namespace GeneralUtilities;
using namespace Playstation2;
using namespace PS2Float;


//#define VERBOSE_MSCAL
//#define VERBOSE_VCALLMS
//#define VERBOSE_VCALLMSR

#define ENABLE_STALLS




#ifdef _DEBUG_VERSION_

// enable debug
#define INLINE_DEBUG_ENABLE

//#define INLINE_DEBUG_SPLIT

/*
#define INLINE_DEBUG_MULT
#define INLINE_DEBUG_MULTU
#define INLINE_DEBUG_DIV
#define INLINE_DEBUG_DIVU
#define INLINE_DEBUG_MTHI
#define INLINE_DEBUG_MTLO
#define INLINE_DEBUG_MFHI
#define INLINE_DEBUG_MFLO
*/


//#define INLINE_DEBUG_LQ
//#define INLINE_DEBUG_SQ
//#define INLINE_DEBUG_SWL
//#define INLINE_DEBUG_LWL
//#define INLINE_DEBUG_SWR
//#define INLINE_DEBUG_LWR
//#define INLINE_DEBUG_SDL
//#define INLINE_DEBUG_LDL
//#define INLINE_DEBUG_SDR
//#define INLINE_DEBUG_LDR
//#define INLINE_DEBUG_SYSCALL
//#define INLINE_DEBUG_RFE
//#define INLINE_DEBUG_ADD
//#define INLINE_DEBUG_R5900
#define INLINE_DEBUG_BREAK
#define INLINE_DEBUG_INVALID
#define INLINE_DEBUG_UNIMPLEMENTED
//#define INLINE_DEBUG_ERET
//#define INLINE_DEBUG_INTEGER_VECTOR
//#define INLINE_DEBUG_VU0
//#define INLINE_DEBUG_VUEXECUTE
//#define INLINE_DEBUG_FPU
//#define INLINE_DEBUG_PADDSW
//#define INLINE_DEBUG_QFSRV
//#define INLINE_DEBUG_MTSAB
//#define INLINE_DEBUG_MTSAH

/*
#define INLINE_DEBUG_PABSH
#define INLINE_DEBUG_PABSW
#define INLINE_DEBUG_PADDB
#define INLINE_DEBUG_PADDH
#define INLINE_DEBUG_PADDW
#define INLINE_DEBUG_PADSBH
#define INLINE_DEBUG_PAND


#define INLINE_DEBUG_PCPYH
#define INLINE_DEBUG_PCPYLD
#define INLINE_DEBUG_PCPYUD

#define INLINE_DEBUG_PDIVBW
#define INLINE_DEBUG_PDIVUW
#define INLINE_DEBUG_PDIVW

#define INLINE_DEBUG_PEXCH
#define INLINE_DEBUG_PEXCW
#define INLINE_DEBUG_PEXEH
#define INLINE_DEBUG_PEXEW
#define INLINE_DEBUG_PEXT5
#define INLINE_DEBUG_PEXTLB
#define INLINE_DEBUG_PEXTLH
#define INLINE_DEBUG_PEXTLW
#define INLINE_DEBUG_PEXTUB
#define INLINE_DEBUG_PEXTUH
#define INLINE_DEBUG_PEXTUW


#define INLINE_DEBUG_PCEQB
#define INLINE_DEBUG_PCEQH
#define INLINE_DEBUG_PCEQW
#define INLINE_DEBUG_PCGTB
#define INLINE_DEBUG_PCGTH
#define INLINE_DEBUG_PCGTW
#define INLINE_DEBUG_PMAXH
#define INLINE_DEBUG_PMAXW
#define INLINE_DEBUG_PMINH
#define INLINE_DEBUG_PMINW
*/

//#define INLINE_DEBUG_MTC0
//#define INLINE_DEBUG_MFC0
//#define INLINE_DEBUG_CTC0
//#define INLINE_DEBUG_CFC0
//#define INLINE_DEBUG_MFC1
//#define INLINE_DEBUG_MTC1
//#define INLINE_DEBUG_CFC1
//#define INLINE_DEBUG_CTC1


//#define INLINE_DEBUG_LWC2
//#define INLINE_DEBUG_SWC2
//#define INLINE_DEBUG_QMTC2_I
//#define INLINE_DEBUG_QMFC2_I
//#define INLINE_DEBUG_QMTC2_NI
//#define INLINE_DEBUG_QMFC2_NI
//#define INLINE_DEBUG_CTC2
//#define INLINE_DEBUG_CFC2
//#define INLINE_DEBUG_COP2


//#define INLINE_DEBUG_DIV_S
//#define INLINE_DEBUG_ADD_S
//#define INLINE_DEBUG_SUB_S
//#define INLINE_DEBUG_MUL_S
//#define INLINE_DEBUG_ADDA_S
//#define INLINE_DEBUG_SUBA_S
//#define INLINE_DEBUG_MULA_S
//#define INLINE_DEBUG_SQRT_S
//#define INLINE_DEBUG_RSQRT_S
//#define INLINE_DEBUG_MADD_S
//#define INLINE_DEBUG_MSUB_S
//#define INLINE_DEBUG_MADDA_S
//#define INLINE_DEBUG_MSUBA_S
//#define INLINE_DEBUG_CVT_S_W
//#define INLINE_DEBUG_CVT_W_S
//#define INLINE_DEBUG_MIN_S
//#define INLINE_DEBUG_MAX_S


//#define COUT_USERMODE_LOAD
//#define COUT_USERMODE_STORE
//#define COUT_FC
//#define COUT_SWC

#define INLINE_DEBUG_TRACE

#endif



using namespace std;

// this area deals with the execution of instructions on the R5900
using namespace R5900;
using namespace R5900::Instruction;



// if a register is loading after load-delay slot, then we need to stall the pipeline until it finishes loading from memory
// if register is loading but is stored to, then we should clear loading flag for register and cancel load
//#define CHECK_LOADING(arg)	/*if ( r->GPRLoading_Bitmap & ( arg ) ) { r->BusyUntil_Cycle = r->Bus->BusyUntil_Cycle; return false; }*/

//#define CHECK_LOADING_COP2(arg)	/*if ( r->COP2.CPRLoading_Bitmap & ( arg ) ) { r->BusyUntil_Cycle = r->Bus->BusyUntil_Cycle; return false; }*/

// we can also cancel the loading of a register if it gets written to before load is complete
//#define CANCEL_LOADING(arg) ( r->GPRLoading_Bitmap &= ~( arg ) )

// if modified register is in delay slot, then kill the load from delay slot
#define CHECK_DELAYSLOT(ModifiedRegister) r->LastModifiedRegister = ModifiedRegister;

#define TRACE_VALUE(ValTr) r->TraceValue = ValTr;

//#define PROCESS_LOADDELAY_BEFORELOAD
//#define PROCESS_LOADDELAY_BEFORESTORE


namespace R5900
{

namespace Instruction
{


// static vars //
Cpu *Recompile::r;

static u32* Recompile::CachedAddresses;
static u32* Recompile::CachedInstructions;
static x64Encoder* Recompile::x;


static void Recompile::Start ()
{
#ifdef INLINE_DEBUG_ENABLE

#ifdef INLINE_DEBUG_SPLIT
	// put debug output into a separate file
	debug.SetSplit ( true );
	debug.SetCombine ( false );
#endif

	debug.Create ( "R5900_Execute_Log.txt" );
#endif

	cout << "\nRunning R5900::Recompile::Start\n";

	// this function currently takes a long time to execute
	Lookup::Start ();
}


// *** R3000A Instructions *** //


////////////////////////////////////////////////
// R-Type Instructions (non-interrupt)


// regular arithemetic
void Recompile::ADDU ( Instruction::Format i )
{
#if defined INLINE_DEBUG_ADDU || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	//debug << "; Input: rs = " << r->GPR [ i.Rs ].u << "; rt = " << r->GPR [ i.Rt ].u;
#endif

	// add without overflow exception: rd = rs + rt
	//r->GPR [ i.Rd ].s = (s32) ( r->GPR [ i.Rs ].u + r->GPR [ i.Rt ].u );
	
#if defined INLINE_DEBUG_ADDU || defined INLINE_DEBUG_R5900
	//debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

void Recompile::SUBU ( Instruction::Format i )
{
#if defined INLINE_DEBUG_SUBU || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	//debug << "; Input: rs = " << r->GPR [ i.Rs ].u << "; rt = " << r->GPR [ i.Rt ].u;
#endif

	// subtract without overflow exception: rd = rs - rt
	//r->GPR [ i.Rd ].s = (s32) ( r->GPR [ i.Rs ].u - r->GPR [ i.Rt ].u );
	
#if defined INLINE_DEBUG_SUBU || defined INLINE_DEBUG_R5900
	//debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

void Recompile::AND ( Instruction::Format i )
{
#if defined INLINE_DEBUG_AND || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	//debug << "; Input: rs = " << r->GPR [ i.Rs ].u << "; rt = " << r->GPR [ i.Rt ].u;
#endif

	// logical AND: rd = rs & rt
	//r->GPR [ i.Rd ].u = r->GPR [ i.Rs ].u & r->GPR [ i.Rt ].u;
	
#if defined INLINE_DEBUG_AND || defined INLINE_DEBUG_R5900
	//debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

void Recompile::OR ( Instruction::Format i )
{
#if defined INLINE_DEBUG_OR || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	//debug << "; Input: rs = " << r->GPR [ i.Rs ].u << "; rt = " << r->GPR [ i.Rt ].u;
#endif

	// logical OR: rd = rs | rt
	//r->GPR [ i.Rd ].u = r->GPR [ i.Rs ].u | r->GPR [ i.Rt ].u;
	
#if defined INLINE_DEBUG_OR || defined INLINE_DEBUG_R5900
	//debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

void Recompile::XOR ( Instruction::Format i )
{
#if defined INLINE_DEBUG_XOR || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	//debug << "; Input: rs = " << r->GPR [ i.Rs ].u << "; rt = " << r->GPR [ i.Rt ].u;
#endif

	// logical XOR: rd = rs ^ rt
	//r->GPR [ i.Rd ].u = r->GPR [ i.Rs ].u ^ r->GPR [ i.Rt ].u;
	
#if defined INLINE_DEBUG_XOR || defined INLINE_DEBUG_R5900
	//debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

void Recompile::NOR ( Instruction::Format i )
{
#if defined INLINE_DEBUG_NOR || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	//debug << "; Input: rs = " << r->GPR [ i.Rs ].u << "; rt = " << r->GPR [ i.Rt ].u;
#endif

	// logical NOR: rd = ~(rs | rt)
	//r->GPR [ i.Rd ].u = ~( r->GPR [ i.Rs ].u | r->GPR [ i.Rt ].u );
	
#if defined INLINE_DEBUG_NOR || defined INLINE_DEBUG_R5900
	//debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

void Recompile::SLT ( Instruction::Format i )
{
#if defined INLINE_DEBUG_SLT || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	//debug << "; Input: rs = " << r->GPR [ i.Rs ].u << "; rt = " << r->GPR [ i.Rt ].u;
#endif

	// set less than signed: rd = rs < rt ? 1 : 0
	//r->GPR [ i.Rd ].s = r->GPR [ i.Rs ].s < r->GPR [ i.Rt ].s ? 1 : 0;
	
#if defined INLINE_DEBUG_SLT || defined INLINE_DEBUG_R5900
	//debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

void Recompile::SLTU ( Instruction::Format i )
{
#if defined INLINE_DEBUG_SLTU || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	//debug << "; Input: rs = " << r->GPR [ i.Rs ].u << "; rt = " << r->GPR [ i.Rt ].u;
#endif

	// set less than signed: rd = rs < rt ? 1 : 0
	//r->GPR [ i.Rd ].u = r->GPR [ i.Rs ].u < r->GPR [ i.Rt ].u ? 1 : 0;
	
#if defined INLINE_DEBUG_SLTU || defined INLINE_DEBUG_R5900
	//debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}


////////////////////////////////////////////
// I-Type Instructions (non-interrupt)



void Recompile::ADDIU ( Instruction::Format i )
{
#if defined INLINE_DEBUG_ADDIU || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	//debug << "; Input: rs = " << r->GPR [ i.Rs ].u;
#endif

	// *note* immediate value is sign-extended before the addition is performed

	// add immedeate without overflow exception: rt = rs + immediate
	//r->GPR [ i.Rt ].s = (s32) ( r->GPR [ i.Rs ].s + i.sImmediate );
	
#if defined INLINE_DEBUG_ADDIU || defined INLINE_DEBUG_R5900
	//debug << "; Output: rt = " << r->GPR [ i.Rt ].u;
#endif
}

void Recompile::ANDI ( Instruction::Format i )
{
#if defined INLINE_DEBUG_ANDI || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	//debug << "; Input: rs = " << r->GPR [ i.Rs ].u;
#endif
	
	// Logical AND zero-extended immedeate: rt = rs & immediate
	//r->GPR [ i.Rt ].u = r->GPR [ i.Rs ].u & ( (u64) i.uImmediate );
	
#if defined INLINE_DEBUG_ANDI || defined INLINE_DEBUG_R5900
	//debug << "; Output: rt = " << r->GPR [ i.Rt ].u;
#endif
}

void Recompile::ORI ( Instruction::Format i )
{
#if defined INLINE_DEBUG_ORI || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	//debug << "; Input: rs = " << r->GPR [ i.Rs ].u;
#endif
	
	// Logical OR zero-extended immedeate: rt = rs | immediate
	//r->GPR [ i.Rt ].u = r->GPR [ i.Rs ].u | ( (u64) i.uImmediate );
	
#if defined INLINE_DEBUG_ORI || defined INLINE_DEBUG_R5900
	//debug << "; Output: rt = " << r->GPR [ i.Rt ].u;
#endif
}

void Recompile::XORI ( Instruction::Format i )
{
#if defined INLINE_DEBUG_XORI || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	//debug << "; Input: rs = " << r->GPR [ i.Rs ].u;
#endif
	
	// Logical XOR zero-extended immedeate: rt = rs & immediate
	//r->GPR [ i.Rt ].u = r->GPR [ i.Rs ].u ^ ( (u64) i.uImmediate );
	
#if defined INLINE_DEBUG_XORI || defined INLINE_DEBUG_R5900
	//debug << "; Output: rt = " << r->GPR [ i.Rt ].u;
#endif
}

void Recompile::SLTI ( Instruction::Format i )
{
#if defined INLINE_DEBUG_SLTI || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	//debug << "; Input: rs = " << r->GPR [ i.Rs ].u;
#endif
	
	// Set less than sign-extended immedeate: rt = rs < immediate ? 1 : 0
	//r->GPR [ i.Rt ].s = r->GPR [ i.Rs ].s < ( (s64) i.sImmediate ) ? 1 : 0;
	
#if defined INLINE_DEBUG_SLTI || defined INLINE_DEBUG_R5900
	//debug << "; Output: rt = " << r->GPR [ i.Rt ].u;
#endif
}

void Recompile::SLTIU ( Instruction::Format i )
{
#if defined INLINE_DEBUG_SLTIU || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	//debug << "; Input: rs = " << r->GPR [ i.Rs ].u;
#endif
	
	// *note* Rs is still sign-extended here, but the comparison is an unsigned one

	// Set if unsigned less than sign-extended immedeate: rt = rs < immediate ? 1 : 0
	//r->GPR [ i.Rt ].u = r->GPR [ i.Rs ].u < ((u64) ((s64) i.sImmediate)) ? 1 : 0;
	
#if defined INLINE_DEBUG_SLTIU || defined INLINE_DEBUG_R5900
	//debug << "; Output: rt = " << r->GPR [ i.Rt ].u;
#endif
}

void Recompile::LUI ( Instruction::Format i )
{
#if defined INLINE_DEBUG_LUI || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif
	
	// Load upper immediate
	//r->GPR [ i.Rt ].s = ( ( (s64) i.sImmediate ) << 16 );
	
#if defined INLINE_DEBUG_LUI || defined INLINE_DEBUG_R5900
	//debug << "; Output: rt = " << r->GPR [ i.Rt ].u;
#endif
}





void Recompile::MFHI ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MFHI || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	//debug << "; Input: HI = " << r->HI.u;
#endif
	
	// this instruction interlocks if multiply/divide unit is busy
	//if ( r->MulDiv_BusyUntil_Cycle > r->CycleCount )
	//{
	//	r->CycleCount = r->MulDiv_BusyUntil_Cycle;
	//}
	
	// move from Hi register
	//r->GPR [ i.Rd ].u = r->HI.u;	//r->HiLo.uHi;
	
#if defined INLINE_DEBUG_MFHI || defined INLINE_DEBUG_R5900
	//debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

void Recompile::MFLO ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MFLO || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	//debug << "; Input: LO = " << r->LO.u;
#endif
	
	// this instruction interlocks if multiply/divide unit is busy
	//if ( r->MulDiv_BusyUntil_Cycle > r->CycleCount )
	//{
	//	r->CycleCount = r->MulDiv_BusyUntil_Cycle;
	//}
	
	// move from Lo register
	//r->GPR [ i.Rd ].u = r->LO.u;	//r->HiLo.uLo;
	
#if defined INLINE_DEBUG_MFLO || defined INLINE_DEBUG_R5900
	//debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}




void Recompile::MTHI ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MTHI || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	//debug << "; Input: rs = " << r->GPR [ i.Rs ].u;
#endif
	
	// there is no MTHI/MTLO delay slot
	//r->HI.u = r->GPR [ i.Rs ].u;
}

void Recompile::MTLO ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MTLO || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	//debug << "; Input: rs = " << r->GPR [ i.Rs ].u;
#endif
	
	// there is no MTHI/MTLO delay slot
	//r->LO.u = r->GPR [ i.Rs ].u;
}


//////////////////////////////////////////////////////////
// Shift instructions



void Recompile::SLL ( Instruction::Format i )
{
#if defined INLINE_DEBUG_SLL || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	//debug << "; Input: rt = " << r->GPR [ i.Rt ].u;
#endif
	
	// shift left logical: rd = rt << shift
	//r->GPR [ i.Rd ].s = (s32) ( r->GPR [ i.Rt ].uw0 << i.Shift );
	
#if defined INLINE_DEBUG_SLL || defined INLINE_DEBUG_R5900
	//debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

void Recompile::SRL ( Instruction::Format i )
{
#if defined INLINE_DEBUG_SRL || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	//debug << "; Input: rt = " << r->GPR [ i.Rt ].u;
#endif
	
	// shift right logical: rd = rt >> shift
	//r->GPR [ i.Rd ].s = (s32) ( r->GPR [ i.Rt ].uw0 >> i.Shift );
	
#if defined INLINE_DEBUG_SRL || defined INLINE_DEBUG_R5900
	//debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

void Recompile::SRA ( Instruction::Format i )
{
#if defined INLINE_DEBUG_SRA || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	//debug << "; Input: rt = " << r->GPR [ i.Rt ].u;
#endif
	
	// shift right arithmetic: rd = rt >> shift
	//r->GPR [ i.Rd ].s = (s32) ( r->GPR [ i.Rt ].sw0 >> i.Shift );
	
#if defined INLINE_DEBUG_SRA || defined INLINE_DEBUG_R5900
	//debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

void Recompile::SLLV ( Instruction::Format i )
{
#if defined INLINE_DEBUG_SLLV || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	//debug << "; Input: rt = " << r->GPR [ i.Rt ].u << "; rs = " << r->GPR [ i.Rs ].u;
#endif
	
	// shift left logical variable: rd = rt << rs
	//r->GPR [ i.Rd ].s = (s32) ( r->GPR [ i.Rt ].uw0 << ( r->GPR [ i.Rs ].uw0 & 0x1f ) );
	
#if defined INLINE_DEBUG_SLLV || defined INLINE_DEBUG_R5900
	//debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

void Recompile::SRLV ( Instruction::Format i )
{
#if defined INLINE_DEBUG_SRLV || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	//debug << "; Input: rt = " << r->GPR [ i.Rt ].u << "; rs = " << r->GPR [ i.Rs ].u;
#endif
	
	// shift right logical variable: rd = rt >> rs
	//r->GPR [ i.Rd ].s = (s32) ( r->GPR [ i.Rt ].uw0 >> ( r->GPR [ i.Rs ].uw0 & 0x1f ) );
	
#if defined INLINE_DEBUG_SRLV || defined INLINE_DEBUG_R5900
	//debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

void Recompile::SRAV ( Instruction::Format i )
{
#if defined INLINE_DEBUG_SRAV || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	//debug << "; Input: rt = " << r->GPR [ i.Rt ].u << "; rs = " << r->GPR [ i.Rs ].u;
#endif
	
	// shift right arithmetic variable: rd = rt >> rs
	//r->GPR [ i.Rd ].s = (s32) ( r->GPR [ i.Rt ].sw0 >> ( r->GPR [ i.Rs ].uw0 & 0x1f ) );
	
#if defined INLINE_DEBUG_SRAV || defined INLINE_DEBUG_R5900
	//debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}


/////////////////////////////////////////////////////////////
// Multiply/Divide Instructions


void Recompile::MULT ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MULT || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	//debug << "; Input: rs = " << r->GPR [ i.Rs ].u << "; rt = " << r->GPR [ i.Rt ].u;
#endif

	// check if mul/div unit is in use
	//if ( r->MulDiv_BusyUntil_Cycle > r->CycleCount )
	//{
	//	r->CycleCount = r->MulDiv_BusyUntil_Cycle;
	//}

	// on PS2, only need to calculate cycles for multiply if it is running at full clock speed?
	// *** TODO *** Calc cycles for multiply??
	
	// multiply signed Lo,Hi = rs * rt
	//s64 temp;
	//temp = ( (s64) ( r->GPR [ i.Rs ].sw0 ) ) * ( (s64) ( r->GPR [ i.Rt ].sw0 ) );
	//r->LO.s = (s32) temp;
	//r->HI.s = (s32) ( temp >> 32 );
	
	// R5900 can additionally write to register
	//if ( i.Rd )
	//{
	//	r->GPR [ i.Rd ].sq0 = (s32) temp;
	//}

#if defined INLINE_DEBUG_MULT || defined INLINE_DEBUG_R5900
	//debug << "; Output: LO=" << r->LO.s << "; HI=" << r->HI.s << "; rd=" << r->GPR [ i.Rd ].s;
#endif
}

void Recompile::MULTU ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MULTU || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	//debug << "; Input: rs = " << r->GPR [ i.Rs ].u << "; rt = " << r->GPR [ i.Rt ].u;
#endif
	
	
	// check if mul/div unit is in use
	//if ( r->MulDiv_BusyUntil_Cycle > r->CycleCount )
	//{
	//	r->CycleCount = r->MulDiv_BusyUntil_Cycle;
	//}
	
	// on PS2, only need to calculate cycles for multiply if it is running at full clock speed?
	// *** TODO *** Calc cycles for multiply??

	// multiply unsigned Lo,Hi = rs * rt
	//u64 temp;
	//temp = ( (u64) ( r->GPR [ i.Rs ].uw0 ) ) * ( (u64) ( r->GPR [ i.Rt ].uw0 ) );
	//r->LO.s = (s32) temp;
	//r->HI.s = (s32) ( temp >> 32 );
	
	// R5900 can additionally write to register
	//if ( i.Rd )
	//{
	//	r->GPR [ i.Rd ].sq0 = (s32) temp;
	//}
	
#if defined INLINE_DEBUG_MULTU || defined INLINE_DEBUG_R5900
	//debug << "; Output: LO=" << r->LO.s << "; HI=" << r->HI.s << "; rd=" << r->GPR [ i.Rd ].s;
#endif
}

void Recompile::DIV ( Instruction::Format i )
{
#if defined INLINE_DEBUG_DIV || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	//debug << "; Input: rs = " << r->GPR [ i.Rs ].u << "; rt = " << r->GPR [ i.Rt ].u;
#endif
	
	// 37 cycles
	// divide by 2 here since r5900 is currently only running at bus speed for testing
	static const int c_iDivideCycles = 37 / 2;

	// check if mul/div unit is in use
	//if ( r->MulDiv_BusyUntil_Cycle > r->CycleCount )
	//{
	//	r->CycleCount = r->MulDiv_BusyUntil_Cycle;
	//}
	
	// mult/div unit is busy now
	//r->MulDiv_BusyUntil_Cycle = r->CycleCount + c_iDivideCycles;

	// divide signed: Lo = rs / rt; Hi = rs % rt
	//if ( r->GPR [ i.Rt ].uw0 != 0 )
	//{
	//	// if rs = 0x80000000 and rt = -1 then hi = 0 and lo = 0x80000000
	//	if ( r->GPR [ i.Rs ].uw0 == 0x80000000 && r->GPR [ i.Rt ].sw0 == -1 )
	//	{
	//		// *todo* check if all this stuff is sign extended during testing
	//		r->HI.s = 0;
	//		r->LO.s = (s32) 0x80000000;
	//	}
	//	else
	//	{
	//		// *todo* check during testing if signs are switched on modulus result when sign of dividend and divisor are different
	//		r->LO.s = r->GPR [ i.Rs ].sw0 / r->GPR [ i.Rt ].sw0;
	//		r->HI.s = r->GPR [ i.Rs ].sw0 % r->GPR [ i.Rt ].sw0;
	//	}
	//}
	//else
	//{
	//	if ( r->GPR [ i.Rs ].s < 0 )
	//	{
	//		r->LO.s = 1;
	//	}
	//	else
	//	{
	//		r->LO.s = -1;
	//	}
	//	
	//	r->HI.s = r->GPR [ i.Rs ].sw0;
	//}
	
#if defined INLINE_DEBUG_DIV || defined INLINE_DEBUG_R5900
	//debug << "; Output: LO = " << r->LO.s << "; HI = " << r->HI.s;
#endif
}

void Recompile::DIVU ( Instruction::Format i )
{
#if defined INLINE_DEBUG_DIVU || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u << "; rt = " << r->GPR [ i.Rt ].u;
#endif

	// 37 cycles
	// divide by 2 here since r5900 is currently only running at bus speed for testing
	static const int c_iDivideCycles = 37 / 2;
	
	
	// check if mul/div unit is in use
	//if ( r->MulDiv_BusyUntil_Cycle > r->CycleCount )
	//{
	//	r->CycleCount = r->MulDiv_BusyUntil_Cycle;
	//}
	
	// mult/div unit is busy now
	//r->MulDiv_BusyUntil_Cycle = r->CycleCount + c_iDivideCycles;

	// divide unsigned: Lo = rs / rt; Hi = rs % rt
	//if ( r->GPR [ i.Rt ].uw0 != 0 )
	//{
	//	r->LO.s = (s32) ( r->GPR [ i.Rs ].uw0 / r->GPR [ i.Rt ].uw0 );
	//	r->HI.s = (s32) ( r->GPR [ i.Rs ].uw0 % r->GPR [ i.Rt ].uw0 );
	//}
	//else
	//{
	//	r->LO.s = -1;
	//	r->HI.s = r->GPR [ i.Rs ].sw0;
	//}
	
#if defined INLINE_DEBUG_DIVU || defined INLINE_DEBUG_R5900
	//debug << "; Output: LO = " << r->LO.s << "; HI = " << r->HI.s;
#endif
}



////////////////////////////////////////////
// Jump/Branch Instructions



void Recompile::J ( Instruction::Format i )
{
#if defined INLINE_DEBUG_J || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif
	
	// next instruction is in the branch delay slot
	//Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
	//d->Instruction = i;
	//d->cb = r->ProcessBranchDelaySlot_t<OPJ>;
	//r->Status.DelaySlot_Valid |= 0x2;
}

void Recompile::JR ( Instruction::Format i )
{
#if defined INLINE_DEBUG_JR || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u;
#endif
	
	// generates an address exception if two low order bits of Rs are not zero


	// check for address exception??
	if ( r->GPR [ i.Rs ].u & 3 )
	{
		// if lower 2-bits of register are not zero, fire address exception
		r->ProcessSynchronousInterrupt ( Cpu::EXC_ADEL );
		return;
	}
	
	// next instruction is in the branch delay slot
	Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
	d->Instruction = i;
	//d->cb = r->_cb_JumpRegister;
	d->cb = r->ProcessBranchDelaySlot_t<OPJR>;

	// *** todo *** check if address exception should be generated if lower 2-bits of jump address are not zero
	// will clear out lower two bits of address for now
	d->Data = r->GPR [ i.Rs ].u & ~3;
	
	r->Status.DelaySlot_Valid |= 0x2;
}

void Recompile::JAL ( Instruction::Format i )
{
#if defined INLINE_DEBUG_JAL || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	
	// next instruction is in the branch delay slot
	Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
	d->Instruction = i;
	//d->cb = r->_cb_Jump;
	d->cb = r->ProcessBranchDelaySlot_t<OPJAL>;
	r->Status.DelaySlot_Valid |= 0x2;

	// *** note *** this is tricky because return address gets stored to r31 after execution of load delay slot but before next instruction
	///////////////////////////////////////////////////////////////
	// Store return address when instruction is executed in r31
	r->GPR [ 31 ].u = r->PC + 8;
	
#if defined INLINE_DEBUG_JAL || defined INLINE_DEBUG_R5900
	debug << "; Output: r31 = " << r->GPR [ 31 ].u;
#endif
}

void Recompile::JALR ( Instruction::Format i )
{
#if defined INLINE_DEBUG_JALR || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u;
#endif
	
	// JALR rd, rs


	// check for address exception??
	if ( r->GPR [ i.Rs ].u & 3 )
	{
		// if lower 2-bits of register are not zero, fire address exception
		r->ProcessSynchronousInterrupt ( Cpu::EXC_ADEL );
		
		return;
	}
	
	// next instruction is in the branch delay slot
	//r->DelaySlot0.Instruction = i;
	
	// *** todo *** check if address exception should be generated if lower 2-bits of jump address are not zero
	// will clear out lower two bits of address for now
	Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
	d->Instruction = i;
	d->Data = r->GPR [ i.Rs ].u & ~3;
	//d->cb = r->_cb_JumpRegister;
	d->cb = r->ProcessBranchDelaySlot_t<OPJALR>;
	
	r->Status.DelaySlot_Valid |= 0x2;

	///////////////////////////////////////////////////////////////
	// Store return address when instruction is executed in Rd
	// *note* this must happen AFTER the stuff above
	r->GPR [ i.Rd ].u = r->PC + 8;
	
#if defined INLINE_DEBUG_JALR || defined INLINE_DEBUG_R5900
	debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

void Recompile::BEQ ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BEQ || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u << "; rt = " << r->GPR [ i.Rt ].u;
#endif
	
	if ( r->GPR [ i.Rs ].u == r->GPR [ i.Rt ].u )
	{
		// next instruction is in the branch delay slot
		Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		d->cb = r->ProcessBranchDelaySlot_t<OPBEQ>;
		r->Status.DelaySlot_Valid |= 0x2;
		
#if defined INLINE_DEBUG_BEQ || defined INLINE_DEBUG_R5900
		debug << ";  WILL TAKE";
#endif
	}
}

void Recompile::BNE ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BNE || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u << "; rt = " << r->GPR [ i.Rt ].u;
#endif
	
	if ( r->GPR [ i.Rs ].u != r->GPR [ i.Rt ].u )
	{
		// next instruction is in the branch delay slot
		Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		d->cb = r->ProcessBranchDelaySlot_t<OPBNE>;
		r->Status.DelaySlot_Valid |= 0x2;
		
#if defined INLINE_DEBUG_BNE || defined INLINE_DEBUG_R5900
		debug << ";  WILL TAKE";
#endif
	}
}

void Recompile::BLEZ ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BLEZ || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u;
#endif
	
	if ( r->GPR [ i.Rs ].s <= 0 )
	{
		// next instruction is in the branch delay slot
		Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		d->cb = r->ProcessBranchDelaySlot_t<OPBLEZ>;
		r->Status.DelaySlot_Valid |= 0x2;
		
#if defined INLINE_DEBUG_BLEZ || defined INLINE_DEBUG_R5900
		debug << ";  WILL TAKE";
#endif
	}
}

void Recompile::BGTZ ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BGTZ || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u;
#endif
	
	if ( r->GPR [ i.Rs ].s > 0 )
	{
		// next instruction is in the branch delay slot
		Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		d->cb = r->ProcessBranchDelaySlot_t<OPBGTZ>;
		r->Status.DelaySlot_Valid |= 0x2;
		
#if defined INLINE_DEBUG_BGTZ || defined INLINE_DEBUG_R5900
		debug << ";  WILL TAKE";
#endif
	}
}

void Recompile::BLTZ ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BLTZ || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u;
#endif
	
	if ( r->GPR [ i.Rs ].s < 0 )
	{
		// next instruction is in the branch delay slot
		Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		d->cb = r->ProcessBranchDelaySlot_t<OPBLTZ>;
		r->Status.DelaySlot_Valid |= 0x2;
		
#if defined INLINE_DEBUG_BLTZ || defined INLINE_DEBUG_R5900
		debug << ";  WILL TAKE";
#endif
	}
}

void Recompile::BGEZ ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BGEZ || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u;
#endif
	
	if ( r->GPR [ i.Rs ].s >= 0 )
	{
		// next instruction is in the branch delay slot
		Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		d->cb = r->ProcessBranchDelaySlot_t<OPBGEZ>;
		r->Status.DelaySlot_Valid |= 0x2;
		
#if defined INLINE_DEBUG_BGEZ || defined INLINE_DEBUG_R5900
		debug << ";  WILL TAKE";
#endif
	}
}

void Recompile::BLTZAL ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BLTZAL || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u;
#endif
	
	if ( r->GPR [ i.Rs ].s < 0 )
	{
		// next instruction is in the branch delay slot
		Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		d->cb = r->ProcessBranchDelaySlot_t<OPBLTZAL>;
		r->Status.DelaySlot_Valid |= 0x2;
		
#if defined INLINE_DEBUG_BLTZAL || defined INLINE_DEBUG_R5900
		debug << ";  WILL TAKE";
#endif
	}
	
	////////////////////////////////////////////////////////////////////////
	// Store return address when instruction is executed in r31
	// for this instruction this happens whether branch is taken or not
	// *note* this must happen AFTER comparison check
	r->GPR [ 31 ].u = r->PC + 8;
}

void Recompile::BGEZAL ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BGEZAL || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u;
#endif
	
	if ( r->GPR [ i.Rs ].s >= 0 )
	{
		// next instruction is in the branch delay slot
		Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		d->cb = r->ProcessBranchDelaySlot_t<OPBGEZAL>;
		r->Status.DelaySlot_Valid |= 0x2;
		
#if defined INLINE_DEBUG_BGEZAL || defined INLINE_DEBUG_R5900
		debug << ";  WILL TAKE";
#endif
	}

	////////////////////////////////////////////////////////////////////////
	// Store return address when instruction is executed in r31
	// for this instruction this happens whether branch is taken or not
	// *note* this must happen AFTER comparison check
	r->GPR [ 31 ].u = r->PC + 8;
}



/*
void Recompile::RFE ( Instruction::Format i )
{
#if defined INLINE_DEBUG_RFE || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "\r\nReturning From: ";
	if ( r->CPR0.Cause.ExcCode == 0 ) debug << "ASYNC Interrupt"; else if ( r->CPR0.Cause.ExcCode == 8 ) debug << "Syscall"; else debug << "Other";
	debug << "\r\nReturning To: " << hex << setw ( 8 ) << r->GPR [ 26 ].u << "; EPC=" << r->CPR0.EPC;
	debug << "\r\nUpdateInterrupt;(before) _Intc_Stat=" << hex << *r->_Intc_Stat << " _Intc_Mask=" << *r->_Intc_Mask << " _R3000A_Status=" << r->CPR0.Regs [ 12 ] << " _R3000A_Cause=" << r->CPR0.Regs [ 13 ] << " _ProcStatus=" << r->Status.Value;
#endif
	
	// restore user/kernel status register bits
	// bits 7-8 should stay zero, and bits 5-6 should stay the same
	r->CPR0.Status.b0 = ( r->CPR0.Status.b0 & 0x30 ) | ( ( r->CPR0.Status.b0 >> 2 ) & 0xf );
	
	// check if interrupts should be re-enabled or cleared ?
	
	// whenever interrupt related stuff is messed with, must update the other interrupt stuff
	r->UpdateInterrupt ();

#if defined INLINE_DEBUG_RFE || defined INLINE_DEBUG_R5900
	debug << "\r\n(after) _Intc_Stat=" << hex << *r->_Intc_Stat << " _Intc_Mask=" << *r->_Intc_Mask << " _R3000A_Status=" << r->CPR0.Regs [ 12 ] << " _R3000A_Cause=" << r->CPR0.Regs [ 13 ] << " _ProcStatus=" << r->Status.Value << " CycleCount=" << dec << r->CycleCount;
#endif
}
*/



////////////////////////////////////////////////////////
// Instructions that can cause Synchronous Interrupts //
////////////////////////////////////////////////////////


void Recompile::ADD ( Instruction::Format i )
{
#if defined INLINE_DEBUG_ADD || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u << "; rt = " << r->GPR [ i.Rt ].u;
#endif
	
	s32 temp;
	
	temp = r->GPR [ i.Rs ].sw0 + r->GPR [ i.Rt ].sw0;
	
	// if the carry outs of bits 30 and 31 differ, then it's signed overflow
	//if ( ( temp < -2147483648LL ) || ( temp > 2147483647LL ) )
	//if( (INT32)( ~( m_r[ INS_RS( m_op ) ] ^ m_r[ INS_RT( m_op ) ] ) & ( m_r[ INS_RS( m_op ) ] ^ result ) ) < 0 )
	//if ( (s32)( ~( r->GPR [ i.Rs ].s ^ r->GPR [ i.Rt ].s ) & ( r->GPR [ i.Rs ].s ^ temp ) ) < 0 )
	//if ( temp < -0x80000000LL || temp > 0x7fffffffLL )
	if ( ( ( ~( r->GPR [ i.Rs ].sw0 ^ r->GPR [ i.Rt ].sw0 ) ) & ( r->GPR [ i.Rs ].sw0 ^ temp ) ) < 0 )
	{
		// overflow
		cout << "\nhps2x64: Recompile::ADD generated an overflow exception @ Cycle#" << dec << r->CycleCount << " PC=" << hex << r->PC << "\n";
		r->ProcessSynchronousInterrupt ( Cpu::EXC_OV );
		
#if defined INLINE_DEBUG_ADD || defined INLINE_DEBUG_R5900
		debug << ";  INT";
#endif
	}
	else
	{
		// it's cool - we can do the add and store the result to register
		// sign-extend for R5900
		r->GPR [ i.Rd ].s = temp;
	}
	
#if defined INLINE_DEBUG_ADD || defined INLINE_DEBUG_R5900
	debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

void Recompile::ADDI ( Instruction::Format i )
{
#if defined INLINE_DEBUG_ADDI || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u;
#endif

	s32 temp;
	
	//temp = ( (s64) r->GPR [ i.Rs ].sw0 ) + ( (s64) i.sImmediate );
	temp = r->GPR [ i.Rs ].sw0 + ( (s32) i.sImmediate );
	
	// if the carry outs of bits 30 and 31 differ, then it's signed overflow
	//if ( ( temp < -2147483648LL ) || ( temp > 2147483647LL ) )
	//if( (INT32)( ~( m_r[ INS_RS( m_op ) ] ^ m_r[ INS_RT( m_op ) ] ) & ( m_r[ INS_RS( m_op ) ] ^ result ) ) < 0 )
	//if ( (s32)( ~( r->GPR [ i.Rs ].s ^ ( (s32) i.sImmediate ) ) & ( r->GPR [ i.Rs ].s ^ temp ) ) < 0 )
	//if ( temp < -0x80000000LL || temp > 0x7fffffffLL )
	if ( ( ( ~( r->GPR [ i.Rs ].sw0 ^ ( (s32) i.sImmediate ) ) ) & ( r->GPR [ i.Rs ].sw0 ^ temp ) ) < 0 )
	{
		// overflow
		cout << "\nhps2x64: Recompile::ADDI generated an overflow exception @ Cycle#" << dec << r->CycleCount << " PC=" << hex << r->PC << "\n";
		r->ProcessSynchronousInterrupt ( Cpu::EXC_OV );
		
#if defined INLINE_DEBUG_ADDI || defined INLINE_DEBUG_R5900
		debug << ";  INT";
#endif
	}
	else
	{
		// it's cool - we can do the addi and store the result to register
		r->GPR [ i.Rt ].s = temp;
	}
	
#if defined INLINE_DEBUG_ADDI || defined INLINE_DEBUG_R5900
	debug << "; Output: rt = " << r->GPR [ i.Rt ].u;
#endif
}

void Recompile::SUB ( Instruction::Format i )
{
#if defined INLINE_DEBUG_SUB || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u << "; rt = " << r->GPR [ i.Rt ].u;
#endif
	
	s32 temp;
	
	temp = r->GPR [ i.Rs ].sw0 - r->GPR [ i.Rt ].sw0;
	
	// if the carry outs of bits 30 and 31 differ, then it's signed overflow
	//if ( ( temp < -2147483648LL ) || ( temp > 2147483647LL ) )
	//if( (INT32)( ( m_r[ INS_RS( m_op ) ] ^ m_r[ INS_RT( m_op ) ] ) & ( m_r[ INS_RS( m_op ) ] ^ result ) ) < 0 )
	//if ( (s32) ( ( r->GPR [ i.Rs ].s ^ r->GPR [ i.Rt ].s ) & ( r->GPR [ i.Rs ].s ^ temp ) ) < 0 )
	//if ( temp < -0x80000000LL || temp > 0x7fffffffLL )
	if ( ( ( r->GPR [ i.Rs ].sw0 ^ r->GPR [ i.Rt ].sw0 ) & ( r->GPR [ i.Rs ].sw0 ^ temp ) ) < 0 )
	{
		// overflow
		cout << "\nhps2x64: Recompile::SUB generated an overflow exception @ Cycle#" << dec << r->CycleCount << " PC=" << hex << r->PC << "\n";
		r->ProcessSynchronousInterrupt ( Cpu::EXC_OV );
		
#if defined INLINE_DEBUG_SUB || defined INLINE_DEBUG_R5900
		debug << ";  INT";
#endif
	}
	else
	{
		// it's cool - we can do the sub and store the result to register
		r->GPR [ i.Rd ].s = temp;
	}
	
#if defined INLINE_DEBUG_SUB || defined INLINE_DEBUG_R5900
	debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}




void Recompile::SYSCALL ( Instruction::Format i )
{
#if defined INLINE_DEBUG_SYSCALL || defined INLINE_DEBUG_R5900
	debug << "\r\nBefore:" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << i.Value;
	debug << "\r\n" << hex << "Status=" << r->CPR0.Regs [ 12 ] << " Cause=" << r->CPR0.Regs [ 13 ] << " a0=" << r->GPR [ 4 ].u << " a1=" << r->GPR [ 5 ].u;
	debug << " r1=" << r->GPR [ 1 ].u;
	debug << " r2=" << r->GPR [ 2 ].u;
	debug << " r3=" << r->GPR [ 3 ].u;
#endif
	
	r->ProcessSynchronousInterrupt ( Cpu::EXC_SYSCALL );
	
#if defined INLINE_DEBUG_SYSCALL || defined INLINE_DEBUG_R5900
	debug << "\r\nAfter:" << hex << setw( 8 ) << r->PC << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << i.Value;
	debug << "\r\n" << hex << "Status=" << r->CPR0.Regs [ 12 ] << " Cause=" << r->CPR0.Regs [ 13 ] << " a0=" << r->GPR [ 4 ].u << " a1=" << r->GPR [ 5 ].u;
	debug << " r1=" << r->GPR [ 1 ].u;
	debug << " r2=" << r->GPR [ 2 ].u;
	debug << " r3=" << r->GPR [ 3 ].u;
#endif
}

void Recompile::BREAK ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BREAK || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif
	
	cout << "\nhps2x64: Recompile::BREAK generated an exception @ Cycle#" << dec << r->CycleCount << " PC=" << hex << r->PC << "\n";
	r->ProcessSynchronousInterrupt ( Cpu::EXC_BP );
	
	// say to stop if we are debugging
	Cpu::DebugStatus.Stop = true;
	Cpu::DebugStatus.Done = true;
}

void Recompile::Invalid ( Instruction::Format i )
{
#if defined INLINE_DEBUG_INVALID || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	cout << "\nhps2x64 NOTE: Invalid Instruction @ Cycle#" << dec << r->CycleCount << " PC=" << hex << r->PC << " Instruction=" << i.Value << " LastPC=" << r->LastPC << "\n";
	r->ProcessSynchronousInterrupt ( Cpu::EXC_RI );
}





void Recompile::MFC0 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MFC0 || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: CPR[0,rd] = " << r->CPR0.Regs [ i.Rd ];
#endif

	// MFCz rt, rd
	// 1 instruction delay?
	//r->DelaySlot0.Instruction = i;
	//r->DelaySlot0.Data = r->CPR0.Regs [ i.Rd ];
	//r->DelaySlot0.cb = r->_cb_FC;
	//r->Status.DelaySlot_Valid |= 0x1;
	
	// no delay slot on R5900?
	r->GPR [ i.Rt ].sq0 = (s32) r->Read_MFC0 ( i.Rd );	//r->CPR0.Regs [ i.Rd ];
	
#ifdef INLINE_DEBUG_TRACE
	TRACE_VALUE ( r->CPR0.Regs [ i.Rd ] )
#endif
}


void Recompile::FC_Callback ( Cpu* r )
{
	if ( r->DelaySlot1.Instruction.Rt == r->LastModifiedRegister )
	{
#ifdef COUT_FC
		cout << "\nhps1x64 ALERT: Reg#" << dec << r->DelaySlot1.Instruction.Rt << " was modified in MFC/CFC delay slot @ Cycle#" << r->CycleCount << hex << " PC=" << r->PC << "\n";
#endif

	}
	
	r->GPR [ r->DelaySlot1.Instruction.Rt ].u = r->DelaySlot1.Data;
	
	// clear delay slot
	r->DelaySlot1.Value = 0;
}


void Recompile::MTC0 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MTC0 || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rt = " << r->GPR [ i.Rt ].u;
#endif
	
	// MTCz rt, rd
	// 1 instruction delay?
	//r->DelaySlot0.Instruction = i;
	//r->DelaySlot0.Data = r->GPR [ i.Rt ].u;
	//r->DelaySlot0.cb = r->_cb_MTC0;
	//r->Status.DelaySlot_Valid |= 0x1;
	
	// no delay slot on R5900?
	//r->CPR0.Regs [ i.Rd ] = r->GPR [ i.Rt ].sw0;
	r->Write_MTC0 ( i.Rd, r->GPR [ i.Rt ].sw0 );
	
#ifdef INLINE_DEBUG_TRACE
	TRACE_VALUE ( r->GPR [ i.Rt ].sw0 )
#endif
}


void Recompile::MTC0_Callback ( Cpu* r )
{
	r->Write_MTC0 ( r->DelaySlot1.Instruction.Rd, r->DelaySlot1.Data );
	
	// clear delay slot
	r->DelaySlot1.Value = 0;
}




void Recompile::MTC2_Callback ( Cpu* r )
{
	//r->COP2.Write_MTC ( r->DelaySlot1.Instruction.Rd, r->DelaySlot1.Data );
	
	// clear delay slot
	r->DelaySlot1.Value = 0;
}



void Recompile::CFC2 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_CFC2 || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_VU0
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: CPC[2,rd] = " << VU0::_VU0->vi [ i.Rd ].u;
#endif
	
	// CFCz rt, rd
	// no delay slot on R5900?
	//r->GPR [ i.Rt ].sq0 = (s32) ( r->CPC2 [ i.Rd ] & 0xffff );
	//r->GPR [ i.Rt ].uq0 = VU0::_VU0->vi [ i.Rd ].u;
	r->GPR [ i.Rt ].sq0 = (s32) VU0::_VU0->Read_CFC ( i.Rd );
	
#ifdef INLINE_DEBUG_TRACE
	TRACE_VALUE ( VU0::_VU0->vi [ i.Rd ].u )
#endif
}



void Recompile::CTC2 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_CTC2 || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_VU0
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rt = " << r->GPR [ i.Rt ].u;
#endif
	
	// CTCz rt, rd
	// no delay slot on R5900?
	
	// ***todo*** this instruction can have interlock, so need to check I bit
	
	//r->CPC2 [ i.Rd ] = ( r->GPR [ i.Rt ].sw0 & 0xffff );
	//VU0::_VU0->vi [ i.Rd ].u = r->GPR [ i.Rt ].uw0;
	VU0::_VU0->Write_CTC ( i.Rd, r->GPR [ i.Rt ].uw0 );

#ifdef INLINE_DEBUG_TRACE
	TRACE_VALUE ( r->GPR [ i.Rt ].uw0 )
#endif
}


void Recompile::CTC2_Callback ( Cpu* r )
{
	//r->COP2.Write_CTC ( r->DelaySlot1.Instruction.Rd, r->DelaySlot1.Data );
	
	// clear delay slot
	r->DelaySlot1.Value = 0;
}



// Load/Store - will need to use address translation to get physical addresses when needed

//////////////////////////////////////////////////////////////////////////
// store instructions

// store instructions
void Recompile::SB ( Instruction::Format i )
{
#if defined INLINE_DEBUG_SB || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rt = " << r->GPR [ i.Rt ].u << "; base = " << r->GPR [ i.Base ].u;
#endif
	
	// SB rt, offset(base)

	// step 1: check if storing to data cache
	//u32 StoreAddress = r->GPR [ i.Base ].s + i.sOffset;
	u32 StoreAddress = r->GPR [ i.Base ].sw0 + i.sOffset;
	
	// clear top 3 bits since there is no data cache for caching stores
	// don't clear top 3 bits since scratchpad is at 0x70000000
	//StoreAddress &= 0x1fffffff;

	
	// ***todo*** perform store of byte
	//r->Bus->Write ( StoreAddress, r->GPR [ i.Rt ].uq0, 0xff );
	r->Bus->Write_t<0xff> ( StoreAddress, r->GPR [ i.Rt ].uq0 );
	
	
	// used for debugging
	r->Last_WriteAddress = StoreAddress;
	r->Last_ReadWriteAddress = StoreAddress;
	
#ifdef INLINE_DEBUG_TRACE
	TRACE_VALUE ( r->GPR [ i.Rt ].u )
#endif
}





void Recompile::SH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_SH || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rt = " << r->GPR [ i.Rt ].u << "; base = " << r->GPR [ i.Base ].u;
#endif
	
	// SH rt, offset(base)
	
	// step 1: check if storing to data cache
	//u32 StoreAddress = r->GPR [ i.Base ].s + i.sOffset;
	u32 StoreAddress = r->GPR [ i.Base ].sw0 + i.sOffset;

	// *** testing *** alert if load is from unaligned address
	if ( StoreAddress & 0x1 )
	{
		cout << "\nhps2x64 ALERT: StoreAddress is unaligned for SH @ cycle=" << dec << r->CycleCount << " PC=" << hex << r->PC << " Address=" << StoreAddress << "\n";
		
		// *** testing ***
		r->ProcessSynchronousInterrupt ( Cpu::EXC_ADES );
		return;
	}
	
	// clear top 3 bits since there is no data cache for caching stores
	// don't clear top 3 bits since scratchpad is at 0x70000000
	//StoreAddress &= 0x1fffffff;
	
	
	// ***todo*** perform store of halfword
	//r->Bus->Write ( StoreAddress, r->GPR [ i.Rt ].uq0, 0xffff );
	r->Bus->Write_t<0xffff> ( StoreAddress, r->GPR [ i.Rt ].uq0 );
	
	

	// used for debugging
	r->Last_WriteAddress = StoreAddress;
	r->Last_ReadWriteAddress = StoreAddress;
	
#ifdef INLINE_DEBUG_TRACE
	TRACE_VALUE ( r->GPR [ i.Rt ].u )
#endif
}

void Recompile::SW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_SW || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rt = " << r->GPR [ i.Rt ].u << "; base = " << r->GPR [ i.Base ].u;
#endif
	
	// SW rt, offset(base)
	u32 StoreAddress;
	
	// check if storing to data cache
	//StoreAddress = r->GPR [ i.Base ].s + i.sOffset;
	StoreAddress = r->GPR [ i.Base ].sw0 + i.sOffset;
	
	// *** testing *** alert if load is from unaligned address
	if ( StoreAddress & 0x3 )
	{
		cout << "\nhps2x64 ALERT: StoreAddress is unaligned for SW @ cycle=" << dec << r->CycleCount << " PC=" << hex << r->PC << " Address=" << StoreAddress << "\n";
		
		// *** testing ***
		r->ProcessSynchronousInterrupt ( Cpu::EXC_ADES );
		return;
	}
	
	// clear top 3 bits since there is no data cache for caching stores
	// don't clear top 3 bits since scratchpad is at 0x70000000
	//StoreAddress &= 0x1fffffff;
	
	
	// ***todo*** perform store of word
	//r->Bus->Write ( StoreAddress, r->GPR [ i.Rt ].uq0, 0xffffffffULL );
	r->Bus->Write_t<0xffffffff> ( StoreAddress, r->GPR [ i.Rt ].uq0 );
	
	

	// used for debugging
	r->Last_WriteAddress = StoreAddress;
	r->Last_ReadWriteAddress = StoreAddress;
	
#ifdef INLINE_DEBUG_TRACE
	TRACE_VALUE ( r->GPR [ i.Rt ].uw0 )
#endif
}



void Recompile::SWL ( Instruction::Format i )
{
#if defined INLINE_DEBUG_SWL || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rt = " << r->GPR [ i.Rt ].u << "; base = " << r->GPR [ i.Base ].u;
#endif

	static const u32 c_Mask = 0xffffffff;
	u32 Type, Offset;

	// SWL rt, offset(base)
	
	// step 1: check if storing to data cache
	//u32 StoreAddress = r->GPR [ i.Base ].s + i.sOffset;
	u32 StoreAddress = r->GPR [ i.Base ].sw0 + i.sOffset;

	// clear top 3 bits since there is no data cache for caching stores
	//StoreAddress &= 0x1fffffff;
	
	
	// ***todo*** perform store SWL
	r->Bus->Write ( StoreAddress & ~3, r->GPR [ i.Rt ].uw0 >> ( ( 3 - ( StoreAddress & 3 ) ) << 3 ), 0xffffffffULL >> ( ( 3 - ( StoreAddress & 3 ) ) << 3 ) );
	

	// used for debugging
	r->Last_WriteAddress = StoreAddress;
	r->Last_ReadWriteAddress = StoreAddress;
	
#ifdef INLINE_DEBUG_TRACE
	TRACE_VALUE ( r->GPR [ i.Rt ].u )
#endif
}

void Recompile::SWR ( Instruction::Format i )
{
#if defined INLINE_DEBUG_SWR || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rt = " << r->GPR [ i.Rt ].u << "; base = " << r->GPR [ i.Base ].u;
#endif

	static const u32 c_Mask = 0xffffffff;
	u32 Type, Offset;
	
	// SWR rt, offset(base)
	
	// step 1: check if storing to data cache
	//u32 StoreAddress = r->GPR [ i.Base ].s + i.sOffset;
	u32 StoreAddress = r->GPR [ i.Base ].sw0 + i.sOffset;

	// clear top 3 bits since there is no data cache for caching stores
	//StoreAddress &= 0x1fffffff;
	
	
	// ***todo*** perform store SWR
	r->Bus->Write ( StoreAddress & ~3, r->GPR [ i.Rt ].uw0 << ( ( StoreAddress & 3 ) << 3 ), 0xffffffffULL << ( ( StoreAddress & 3 ) << 3 ) );
	
	
	
	// used for debugging
	r->Last_WriteAddress = StoreAddress;
	r->Last_ReadWriteAddress = StoreAddress;
	
#ifdef INLINE_DEBUG_TRACE
	TRACE_VALUE ( r->GPR [ i.Rt ].u )
#endif
}



/////////////////////////////////////////////////
// load instructions

// load instructions with delay slot
void Recompile::LB ( Instruction::Format i )
{
#if defined INLINE_DEBUG_LB || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: base = " << r->GPR [ i.Base ].u;
#endif
	
	// signed load byte from memory
	// LB rt, offset(base)
	
	u32 LoadAddress;
	
	// set load to happen after delay slot
	//LoadAddress = r->GPR [ i.Base ].s + i.sOffset;
	LoadAddress = r->GPR [ i.Base ].sw0 + i.sOffset;
	
	
	// ***todo*** perform signed load of byte
	//r->GPR [ i.Rt ].sq0 = (s8) r->Bus->Read ( LoadAddress, 0xff );
	r->GPR [ i.Rt ].sq0 = (s8) r->Bus->Read_t<0xff> ( LoadAddress );
	
	
	// used for debugging
	r->Last_ReadAddress = LoadAddress;
	r->Last_ReadWriteAddress = LoadAddress;
	
#if defined INLINE_DEBUG_LB || defined INLINE_DEBUG_R5900
	debug << "; Output: rt = " << r->GPR [ i.Rt ].sq0;
#endif
}






void Recompile::LH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_LH || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: base = " << r->GPR [ i.Base ].u;
#endif
	
	// LH rt, offset(base)
	
	u32 LoadAddress;
	
	// set load to happen after delay slot
	//LoadAddress = r->GPR [ i.Base ].s + i.sOffset;
	LoadAddress = r->GPR [ i.Base ].sw0 + i.sOffset;
	
	// *** testing *** alert if load is from unaligned address
	if ( LoadAddress & 0x1 )
	{
		cout << "\nhps2x64 ALERT: LoadAddress is unaligned for LH @ cycle=" << dec << r->CycleCount << " PC=" << hex << r->PC << " Address=" << LoadAddress << "\n";
		
		// *** testing ***
		r->ProcessSynchronousInterrupt ( Cpu::EXC_ADEL );
		return;
	}
	
	
	// ***todo*** perform signed load of halfword
	//r->GPR [ i.Rt ].sq0 = (s16) r->Bus->Read ( LoadAddress, 0xffff );
	r->GPR [ i.Rt ].sq0 = (s16) r->Bus->Read_t<0xffff> ( LoadAddress );
	
	
	
	// used for debugging
	r->Last_ReadAddress = LoadAddress;
	r->Last_ReadWriteAddress = LoadAddress;
	
#if defined INLINE_DEBUG_LH || defined INLINE_DEBUG_R5900
	debug << "; Output: rt = " << r->GPR [ i.Rt ].sq0;
#endif
}








void Recompile::LW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_LW || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: base = " << r->GPR [ i.Base ].u;
#endif
	
	// LW rt, offset(base)
	
	u32 LoadAddress;
	
	// set load to happen after delay slot
	//LoadAddress = r->GPR [ i.Base ].s + i.sOffset;
	LoadAddress = r->GPR [ i.Base ].sw0 + i.sOffset;
	
	// *** testing *** alert if load is from unaligned address
	if ( LoadAddress & 0x3 )
	{
		cout << "\nhps2x64 ALERT: LoadAddress is unaligned for LW @ cycle=" << dec << r->CycleCount << " PC=" << hex << r->PC << " Address=" << LoadAddress << "\n";
		
#if defined INLINE_DEBUG_LW || defined INLINE_DEBUG_R5900
		debug << "\r\nhps2x64 ALERT: LoadAddress is unaligned for LW @ cycle=" << dec << r->CycleCount << " PC=" << hex << r->PC << " Address=" << LoadAddress << "\r\n";
#endif

		// *** testing ***
		r->ProcessSynchronousInterrupt ( Cpu::EXC_ADEL );
		return;
	}
	
	
	// ***todo*** perform signed load of word
	//r->GPR [ i.Rt ].sq0 = (s32) r->Bus->Read ( LoadAddress, 0xffffffffULL );
	r->GPR [ i.Rt ].sq0 = (s32) r->Bus->Read_t<0xffffffff> ( LoadAddress );
	
	
	
	// used for debugging
	r->Last_ReadAddress = LoadAddress;
	r->Last_ReadWriteAddress = LoadAddress;
	
#if defined INLINE_DEBUG_LW || defined INLINE_DEBUG_R5900
	debug << "; Output: rt = " << r->GPR [ i.Rt ].sq0;
#endif
}

void Recompile::LBU ( Instruction::Format i )
{
#if defined INLINE_DEBUG_LBU || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: base = " << r->GPR [ i.Base ].u;
#endif
	
	// LBU rt, offset(base)
	
	u32 LoadAddress;
	
	// set load to happen after delay slot
	//LoadAddress = r->GPR [ i.Base ].s + i.sOffset;
	LoadAddress = r->GPR [ i.Base ].sw0 + i.sOffset;
	
	
	// ***todo*** perform load of unsigned byte
	//r->GPR [ i.Rt ].uq0 = (u8) r->Bus->Read ( LoadAddress, 0xff );
	r->GPR [ i.Rt ].uq0 = (u8) r->Bus->Read_t<0xff> ( LoadAddress );
	
	
	
	// used for debugging
	r->Last_ReadAddress = LoadAddress;
	r->Last_ReadWriteAddress = LoadAddress;
	
#if defined INLINE_DEBUG_LBU || defined INLINE_DEBUG_R5900
	debug << "; Output: rt = " << r->GPR [ i.Rt ].sq0;
#endif
}

void Recompile::LHU ( Instruction::Format i )
{
#if defined INLINE_DEBUG_LHU || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: base = " << r->GPR [ i.Base ].u;
#endif
	
	// LHU rt, offset(base)
	
	u32 LoadAddress;
	
	// set load to happen after delay slot
	//LoadAddress = r->GPR [ i.Base ].s + i.sOffset;
	LoadAddress = r->GPR [ i.Base ].sw0 + i.sOffset;
	
	// *** testing *** alert if load is from unaligned address
	if ( LoadAddress & 0x1 )
	{
		cout << "\nhps2x64 ALERT: LoadAddress is unaligned for LHU @ cycle=" << dec << r->CycleCount << " PC=" << hex << r->PC << " Address=" << LoadAddress << "\n";
		
		// *** testing ***
		r->ProcessSynchronousInterrupt ( Cpu::EXC_ADEL );
		return;
	}
	
	
	// ***todo*** perform unsigned load of halfword
	//r->GPR [ i.Rt ].uq0 = (u16) r->Bus->Read ( LoadAddress, 0xffff );
	r->GPR [ i.Rt ].uq0 = (u16) r->Bus->Read_t<0xffff> ( LoadAddress );
	
	
	// used for debugging
	r->Last_ReadAddress = LoadAddress;
	r->Last_ReadWriteAddress = LoadAddress;
	
#if defined INLINE_DEBUG_LHU || defined INLINE_DEBUG_R5900
	debug << "; Output: rt = " << r->GPR [ i.Rt ].sq0;
#endif
}




// load instructions without load-delay slot
void Recompile::LWL ( Instruction::Format i )
{
#if defined INLINE_DEBUG_LWL || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rt = " << r->GPR [ i.Rt ].u << "; base = " << r->GPR [ i.Base ].u;
#endif

	// LWL rt, offset(base)
	
	u32 LoadAddress;
	u32 Value, Temp;
	
	// set load to happen after delay slot
	//LoadAddress = r->GPR [ i.Base ].s + i.sOffset;
	LoadAddress = r->GPR [ i.Base ].sw0 + i.sOffset;
	
	
	// ***todo*** perform load LWL
	//Value = r->Bus->Read ( LoadAddress & ~3, 0xffffffffULL );
	Value = r->Bus->Read_t<0xffffffffULL> ( LoadAddress & ~3 );
	
	Value <<= ( ( 3 - ( LoadAddress & 3 ) ) << 3 );
	Temp = r->GPR [ i.Rt ].uw0;
	Temp <<= ( ( ( LoadAddress & 3 ) + 1 ) << 3 );
	if ( ( LoadAddress & 3 ) == 3 ) Temp = 0;
	Temp >>= ( ( ( LoadAddress & 3 ) + 1 ) << 3 );
	r->GPR [ i.Rt ].sq0 = (s32) ( Value | Temp );
	
	
	// used for debugging
	r->Last_ReadAddress = LoadAddress;
	r->Last_ReadWriteAddress = LoadAddress;
	
#if defined INLINE_DEBUG_LWL || defined INLINE_DEBUG_R5900
	debug << "; Output: rt = " << r->GPR [ i.Rt ].sq0;
#endif
}

void Recompile::LWR ( Instruction::Format i )
{
#if defined INLINE_DEBUG_LWR || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rt = " << r->GPR [ i.Rt ].u << "; base = " << r->GPR [ i.Base ].u;
#endif

	// LWR rt, offset(base)
	
	u32 LoadAddress;
	u32 Value, Temp;
	
	// set load to happen after delay slot
	//LoadAddress = r->GPR [ i.Base ].s + i.sOffset;
	LoadAddress = r->GPR [ i.Base ].sw0 + i.sOffset;
	
	
	// ***todo*** perform load LWR
	//Value = r->Bus->Read ( LoadAddress & ~3, 0xffffffffULL );
	Value = r->Bus->Read_t<0xffffffffULL> ( LoadAddress & ~3 );
	
	Value >>= ( ( LoadAddress & 3 ) << 3 );
	Temp = r->GPR [ i.Rt ].uw0;
	Temp >>= ( ( 4 - ( LoadAddress & 3 ) ) << 3 );
	if ( ( LoadAddress & 3 ) == 0 ) Temp = 0;
	Temp <<= ( ( 4 - ( LoadAddress & 3 ) ) << 3 );
	
	// note: LWR is only sign extended when the full memory value is loaded, which is when ( LoadAddress & 3 ) == 0
	if ( LoadAddress & 3 )
	{
		// NOT sign extended //
		r->GPR [ i.Rt ].uw0 = Value | Temp;
	}
	else
	{
		// sign extended //
		r->GPR [ i.Rt ].sq0 = (s32) ( Value | Temp );
	}
	
	
	// used for debugging
	r->Last_ReadAddress = LoadAddress;
	r->Last_ReadWriteAddress = LoadAddress;
	
#if defined INLINE_DEBUG_LWR || defined INLINE_DEBUG_R5900
	debug << "; Output: rt = " << r->GPR [ i.Rt ].sq0;
#endif
}






//// ***** R5900 INSTRUCTIONS ***** ////

// arithemetic instructions //

static void Recompile::DADD ( Instruction::Format i )
{
#if defined INLINE_DEBUG_DADD || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u << "; rt = " << r->GPR [ i.Rt ].u;
#endif

	s64 temp;
	
	temp = r->GPR [ i.Rs ].s + r->GPR [ i.Rt ].s;

	// ***todo*** implement overflow exception
	// note: this is similar to something seen in MAME and adapted from something in pcsx2
	if ( ( ( ~( r->GPR [ i.Rs ].s ^ r->GPR [ i.Rt ].s ) ) & ( r->GPR [ i.Rs ].s ^ temp ) ) < 0 )
	{
		// overflow
		cout << "\nhps2x64: Recompile::DADD generated an overflow exception @ Cycle#" << dec << r->CycleCount << " PC=" << hex << r->PC << "\n";
		r->ProcessSynchronousInterrupt ( Cpu::EXC_OV );
		
#if defined INLINE_DEBUG_DADD || defined INLINE_DEBUG_R5900
		debug << ";  INT";
#endif
	}
	else
	{
		// it's cool - we can do the add and store the result to register
		// sign-extend for R5900
		r->GPR [ i.Rd ].s = temp;
	}
	
	// add WITH overflow exception: rd = rs + rt
	//r->GPR [ i.Rd ].u = r->GPR [ i.Rs ].u + r->GPR [ i.Rt ].u;
	
#if defined INLINE_DEBUG_DADD || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

static void Recompile::DADDI ( Instruction::Format i )
{
#if defined INLINE_DEBUG_DADDI || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	s64 temp;
	
	// ***todo*** implement overflow exception
	temp = r->GPR [ i.Rs ].s + ( (s64) i.sImmediate );
	
	// ***todo*** implement overflow exception
	// note: this is similar to something seen in MAME and adapted from something in pcsx2
	if ( ( ( ~( r->GPR [ i.Rs ].s ^ ( (s64) i.sImmediate ) ) ) & ( r->GPR [ i.Rs ].s ^ temp ) ) < 0 )
	{
		// overflow
		cout << "\nhps2x64: Recompile::DADDI generated an overflow exception @ Cycle#" << dec << r->CycleCount << " PC=" << hex << r->PC << "\n";
		r->ProcessSynchronousInterrupt ( Cpu::EXC_OV );
		
#if defined INLINE_DEBUG_DADDI || defined INLINE_DEBUG_R5900
		debug << ";  INT";
#endif
	}
	else
	{
		// it's cool - we can do the add and store the result to register
		// sign-extend for R5900
		r->GPR [ i.Rt ].s = temp;
	}
	
	// add immedeate WITH overflow exception: rt = rs + immediate
	//r->GPR [ i.Rt ].s = r->GPR [ i.Rs ].s + ( (s64) i.sImmediate );
	
#if defined INLINE_DEBUG_DADD || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "; Output: rt = " << r->GPR [ i.Rt ].u;
#endif
}

static void Recompile::DADDU ( Instruction::Format i )
{
#if defined INLINE_DEBUG_DADDU || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u << "; rt = " << r->GPR [ i.Rt ].u;
#endif

	// add without overflow exception: rd = rs + rt
	r->GPR [ i.Rd ].u = r->GPR [ i.Rs ].u + r->GPR [ i.Rt ].u;
	
#if defined INLINE_DEBUG_DADDU || defined INLINE_DEBUG_R5900
	debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

static void Recompile::DADDIU ( Instruction::Format i )
{
#if defined INLINE_DEBUG_DADDIU || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u;
#endif

	// *note* immediate value is sign-extended before the addition is performed

	// add immedeate without overflow exception: rt = rs + immediate
	r->GPR [ i.Rt ].s = r->GPR [ i.Rs ].s + ( (s64) i.sImmediate );
	
#if defined INLINE_DEBUG_DADDIU || defined INLINE_DEBUG_R5900
	debug << "; Output: rt = " << r->GPR [ i.Rt ].u;
#endif
}

static void Recompile::DSUB ( Instruction::Format i )
{
#if defined INLINE_DEBUG_DSUB || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	s64 temp;

	temp = r->GPR [ i.Rs ].s - r->GPR [ i.Rt ].s;
	
	// ***todo*** implement overflow exception
	if ( ( ( r->GPR [ i.Rs ].s ^ r->GPR [ i.Rt ].s ) & ( r->GPR [ i.Rs ].s ^ temp ) ) < 0 )
	{
		// overflow
		cout << "\nhps2x64: Recompile::DSUB generated an overflow exception @ Cycle#" << dec << r->CycleCount << " PC=" << hex << r->PC << "\n";
		r->ProcessSynchronousInterrupt ( Cpu::EXC_OV );
		
#if defined INLINE_DEBUG_DSUB || defined INLINE_DEBUG_R5900
		debug << ";  INT";
#endif
	}
	else
	{
		// it's cool - we can do the sub and store the result to register
		r->GPR [ i.Rd ].s = temp;
	}
	
	// subtract WITH overflow exception: rd = rs - rt
	//r->GPR [ i.Rd ].s = r->GPR [ i.Rs ].u - r->GPR [ i.Rt ].u;
	
#if defined INLINE_DEBUG_DSUB || defined INLINE_DEBUG_R5900
	debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

static void Recompile::DSUBU ( Instruction::Format i )
{
#if defined INLINE_DEBUG_DSUBU || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u << "; rt = " << r->GPR [ i.Rt ].u;
#endif

	// subtract without overflow exception: rd = rs - rt
	r->GPR [ i.Rd ].s = r->GPR [ i.Rs ].u - r->GPR [ i.Rt ].u;
	
#if defined INLINE_DEBUG_DSUBU || defined INLINE_DEBUG_R5900
	debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

static void Recompile::DSLL ( Instruction::Format i )
{
#if defined INLINE_DEBUG_DSLL || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rt = " << r->GPR [ i.Rt ].u;
#endif
	
	// shift left logical: rd = rt << shift
	r->GPR [ i.Rd ].u = ( r->GPR [ i.Rt ].u << i.Shift );
	
#if defined INLINE_DEBUG_DSLL || defined INLINE_DEBUG_R5900
	debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

static void Recompile::DSLL32 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_DSLL32 || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rt = " << r->GPR [ i.Rt ].u;
#endif
	
	// shift left logical: rd = rt << shift
	r->GPR [ i.Rd ].u = ( r->GPR [ i.Rt ].u << ( i.Shift + 32 ) );
	
#if defined INLINE_DEBUG_DSLL32 || defined INLINE_DEBUG_R5900
	debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

static void Recompile::DSLLV ( Instruction::Format i )
{
#if defined INLINE_DEBUG_DSLLV || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rt = " << r->GPR [ i.Rt ].u << "; rs = " << r->GPR [ i.Rs ].u;
#endif
	
	// shift left logical variable: rd = rt << rs
	r->GPR [ i.Rd ].s = r->GPR [ i.Rt ].u << ( r->GPR [ i.Rs ].u & 0x3f );
	
#if defined INLINE_DEBUG_DSLLV || defined INLINE_DEBUG_R5900
	debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

static void Recompile::DSRA ( Instruction::Format i )
{
#if defined INLINE_DEBUG_DSRA || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rt = " << r->GPR [ i.Rt ].u;
#endif
	
	// shift right arithmetic: rd = rt >> shift
	r->GPR [ i.Rd ].s = ( r->GPR [ i.Rt ].s >> i.Shift );
	
#if defined INLINE_DEBUG_DSRA || defined INLINE_DEBUG_R5900
	debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

static void Recompile::DSRA32 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_DSRA32 || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rt = " << r->GPR [ i.Rt ].u;
#endif
	
	// shift right arithmetic: rd = rt >> shift
	r->GPR [ i.Rd ].s = ( r->GPR [ i.Rt ].s >> ( i.Shift + 32 ) );
	
#if defined INLINE_DEBUG_DSRA32 || defined INLINE_DEBUG_R5900
	debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

static void Recompile::DSRAV ( Instruction::Format i )
{
#if defined INLINE_DEBUG_DSRAV || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rt = " << r->GPR [ i.Rt ].u << "; rs = " << r->GPR [ i.Rs ].u;
#endif
	
	// shift right arithmetic variable: rd = rt >> rs
	r->GPR [ i.Rd ].s = ( r->GPR [ i.Rt ].s >> ( r->GPR [ i.Rs ].u & 0x3f ) );
	
#if defined INLINE_DEBUG_DSRAV || defined INLINE_DEBUG_R5900
	debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

static void Recompile::DSRL ( Instruction::Format i )
{
#if defined INLINE_DEBUG_DSRL || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rt = " << r->GPR [ i.Rt ].u;
#endif
	
	// shift right logical: rd = rt >> shift
	r->GPR [ i.Rd ].s = ( r->GPR [ i.Rt ].u >> i.Shift );
	
#if defined INLINE_DEBUG_DSRL || defined INLINE_DEBUG_R5900
	debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

static void Recompile::DSRL32 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_DSRL32 || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rt = " << r->GPR [ i.Rt ].u;
#endif
	
	// shift right logical: rd = rt >> shift
	r->GPR [ i.Rd ].s = ( r->GPR [ i.Rt ].u >> ( i.Shift + 32 ) );
	
#if defined INLINE_DEBUG_DSRL32 || defined INLINE_DEBUG_R5900
	debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

static void Recompile::DSRLV ( Instruction::Format i )
{
#if defined INLINE_DEBUG_DSRLV || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rt = " << r->GPR [ i.Rt ].u << "; rs = " << r->GPR [ i.Rs ].u;
#endif
	
	// shift right logical variable: rd = rt >> rs
	r->GPR [ i.Rd ].s = ( r->GPR [ i.Rt ].u >> ( r->GPR [ i.Rs ].u & 0x3f ) );
	
#if defined INLINE_DEBUG_DSRLV || defined INLINE_DEBUG_R5900
	debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}


static void Recompile::MULT1 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MULT1 || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u << "; rt = " << r->GPR [ i.Rt ].u;
#endif

	
	// if rs is between -0x800 and 0x7ff, then multiply takes 6 cycles
	static const int c_iMultiplyCycles_Fast = 6;
	
	// if rs is between 0x800 and 0xfffff or between -0x7ff and -0x100000, then multiply takes 9 cycles
	static const int c_iMultiplyCycles_Med = 9;
	
	// otherwise, multiply takes 13 cycles
	static const int c_iMultiplyCycles_Slow = 13;
	
	// check if mul/div unit is in use
	if ( r->MulDiv_BusyUntil_Cycle1 > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle1;
	}

	// cycle times are different on ps2 ??
	/*
	// calculate cycles mul/div unit will be busy for
	r->MulDiv_BusyUntil_Cycle = r->CycleCount + c_iMultiplyCycles_Slow;
	if ( r->GPR [ i.Rs ].s < 0x800 && r->GPR [ i.Rs ].s >= -0x800 )
	{
		r->MulDiv_BusyUntil_Cycle = r->CycleCount + c_iMultiplyCycles_Fast;
	}
	else if ( r->GPR [ i.Rs ].s < 0x100000 && r->GPR [ i.Rs ].s >= -0x100000 )
	{
		r->MulDiv_BusyUntil_Cycle = r->CycleCount + c_iMultiplyCycles_Med;
	}
	*/
	
	// multiply signed Lo,Hi = rs * rt
	//r->HiLo.sValue = ((s64) (r->GPR [ i.Rs ].s)) * ((s64) (r->GPR [ i.Rt ].s));
	s64 temp;
	temp = ( (s64) ( r->GPR [ i.Rs ].sw0 ) ) * ( (s64) ( r->GPR [ i.Rt ].sw0 ) );
	r->LO.sq1 = (s32) temp;
	r->HI.sq1 = (s32) ( temp >> 32 );
	
	// R5900 can additionally write to register
	if ( i.Rd )
	{
		r->GPR [ i.Rd ].sq0 = (s32) temp;
	}

#if defined INLINE_DEBUG_MULT1 || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "; Output: LO1=" << r->LO.sq1 << "; HI1=" << r->HI.sq1 << "; rd=" << r->GPR [ i.Rd ].sq0;
#endif

}

static void Recompile::MULTU1 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MULTU1 || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u << "; rt = " << r->GPR [ i.Rt ].u;
#endif

	// if rs is between 0 and 0x7ff, then multiply takes 6 cycles
	static const int c_iMultiplyCycles_Fast = 6;
	
	// if rs is between 0x800 and 0xfffff, then multiply takes 9 cycles
	static const int c_iMultiplyCycles_Med = 9;
	
	// otherwise, multiply takes 13 cycles
	static const int c_iMultiplyCycles_Slow = 13;
	
	// check if mul/div unit is in use
	if ( r->MulDiv_BusyUntil_Cycle1 > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle1;
	}
	
	// cycle times are different on ps2 ??
	/*
	// calculate cycles mul/div unit will be busy for
	r->MulDiv_BusyUntil_Cycle = r->CycleCount + c_iMultiplyCycles_Slow;
	if ( r->GPR [ i.Rs ].u < 0x800 )
	{
		r->MulDiv_BusyUntil_Cycle = r->CycleCount + c_iMultiplyCycles_Fast;
	}
	else if ( r->GPR [ i.Rs ].u < 0x100000 )
	{
		r->MulDiv_BusyUntil_Cycle = r->CycleCount + c_iMultiplyCycles_Med;
	}
	*/

	// multiply unsigned Lo,Hi = rs * rt
	//r->HiLo.uValue = ((u64) (r->GPR [ i.Rs ].u)) * ((u64) (r->GPR [ i.Rt ].u));
	u64 temp;
	temp = ( (u64) ( r->GPR [ i.Rs ].uw0 ) ) * ( (u64) ( r->GPR [ i.Rt ].uw0 ) );
	r->LO.sq1 = (s32) temp;
	r->HI.sq1 = (s32) ( temp >> 32 );
	
	// R5900 can additionally write to register
	if ( i.Rd )
	{
		r->GPR [ i.Rd ].sq0 = (s32) temp;
	}
	
#if defined INLINE_DEBUG_MULTU1 || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "; Output: LO1=" << r->LO.sq1 << "; HI1=" << r->HI.sq1 << "; rd=" << r->GPR [ i.Rd ].sq0;
#endif

}

static void Recompile::DIV1 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_DIV1 || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u << "; rt = " << r->GPR [ i.Rt ].u;
#endif

	
	// 37 cycles
	// divide by two until r5900 implementation is running at proper speed
	static const int c_iDivideCycles = 37 / 2;

	// check if mul/div unit is in use
	if ( r->MulDiv_BusyUntil_Cycle1 > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle1;
	}
	
	// mult/div unit is busy now
	r->MulDiv_BusyUntil_Cycle1 = r->CycleCount + c_iDivideCycles;

	// divide signed: Lo = rs / rt; Hi = rs % rt
	//if ( r->GPR [ i.Rt ].u != 0 )
	if ( r->GPR [ i.Rt ].uw0 != 0 )
	{
		// if rs = 0x80000000 and rt = -1 then hi = 0 and lo = 0x80000000
		if ( r->GPR [ i.Rs ].uw0 == 0x80000000 && r->GPR [ i.Rt ].sw0 == -1 )
		{
			// *todo* check if all this stuff is sign extended during testing
			//r->HiLo.uHi = 0;
			//r->HiLo.uLo = 0x80000000;
			r->HI.sq1 = 0;
			r->LO.sq1 = (s32) 0x80000000;
		}
		else
		{
			// *todo* check during testing if signs are switched on modulus result when sign of dividend and divisor are different
			//r->HiLo.sLo = r->GPR [ i.Rs ].s / r->GPR [ i.Rt ].s;
			//r->HiLo.sHi = r->GPR [ i.Rs ].s % r->GPR [ i.Rt ].s;
			r->LO.sq1 = r->GPR [ i.Rs ].sw0 / r->GPR [ i.Rt ].sw0;
			r->HI.sq1 = r->GPR [ i.Rs ].sw0 % r->GPR [ i.Rt ].sw0;
		}
	}
	else
	{
		if ( r->GPR [ i.Rs ].s < 0 )
		{
			//r->HiLo.sLo = 1;
			r->LO.sq1 = 1;
		}
		else
		{
			//r->HiLo.sLo = -1;
			r->LO.sq1 = -1;
		}
		
		//r->HiLo.uHi = r->GPR [ i.Rs ].u;
		r->HI.sq1 = r->GPR [ i.Rs ].sw0;
	}
	
#if defined INLINE_DEBUG_DIV1 || defined INLINE_DEBUG_R5900
	debug << "; Output: LO1 = " << r->LO.sq1 << "; HI1 = " << r->HI.sq1;
#endif
}

static void Recompile::DIVU1 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_DIVU1 || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u << "; rt = " << r->GPR [ i.Rt ].u;
#endif

	// 37 cycles
	// divide by two until r5900 implementation is running at proper speed
	static const int c_iDivideCycles = 37 / 2;
	
	// check if mul/div unit is in use
	if ( r->MulDiv_BusyUntil_Cycle1 > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle1;
	}
	
	// mult/div unit is busy now
	r->MulDiv_BusyUntil_Cycle1 = r->CycleCount + c_iDivideCycles;

	// divide unsigned: Lo = rs / rt; Hi = rs % rt
	//if ( r->GPR [ i.Rt ].u != 0 )
	if ( r->GPR [ i.Rt ].uw0 != 0 )
	{
		//r->HiLo.uLo = r->GPR [ i.Rs ].u / r->GPR [ i.Rt ].u;
		//r->HiLo.uHi = r->GPR [ i.Rs ].u % r->GPR [ i.Rt ].u;
		r->LO.sq1 = (s32) ( r->GPR [ i.Rs ].uw0 / r->GPR [ i.Rt ].uw0 );
		r->HI.sq1 = (s32) ( r->GPR [ i.Rs ].uw0 % r->GPR [ i.Rt ].uw0 );
	}
	else
	{
		//r->HiLo.sLo = -1;
		//r->HiLo.uHi = r->GPR [ i.Rs ].u;
		r->LO.sq1 = -1;
		r->HI.sq1 = r->GPR [ i.Rs ].sw0;
	}
	
#if defined INLINE_DEBUG_DIVU1 || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "; Output: LO1 = " << r->LO.sq1 << "; HI1 = " << r->HI.sq1;
#endif
}

static void Recompile::MADD ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MADD || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	// if rs is between -0x800 and 0x7ff, then multiply takes 6 cycles
	static const int c_iMultiplyCycles_Fast = 6;
	
	// if rs is between 0x800 and 0xfffff or between -0x7ff and -0x100000, then multiply takes 9 cycles
	static const int c_iMultiplyCycles_Med = 9;
	
	// otherwise, multiply takes 13 cycles
	static const int c_iMultiplyCycles_Slow = 13;
	
	// check if mul/div unit is in use
	if ( r->MulDiv_BusyUntil_Cycle > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle;
	}

	/*
	// calculate cycles mul/div unit will be busy for
	r->MulDiv_BusyUntil_Cycle = r->CycleCount + c_iMultiplyCycles_Slow;
	if ( r->GPR [ i.Rs ].s < 0x800 && r->GPR [ i.Rs ].s >= -0x800 )
	{
		r->MulDiv_BusyUntil_Cycle = r->CycleCount + c_iMultiplyCycles_Fast;
	}
	else if ( r->GPR [ i.Rs ].s < 0x100000 && r->GPR [ i.Rs ].s >= -0x100000 )
	{
		r->MulDiv_BusyUntil_Cycle = r->CycleCount + c_iMultiplyCycles_Med;
	}
	*/
	
	// multiply signed Lo,Hi = rs * rt
	//r->HiLo.sValue = ((s64) (r->GPR [ i.Rs ].s)) * ((s64) (r->GPR [ i.Rt ].s));
	s64 temp, lltemp2;
	temp = ( (s64) ( r->GPR [ i.Rs ].sw0 ) ) * ( (s64) ( r->GPR [ i.Rt ].sw0 ) );
	
	// also add in hi,lo
	lltemp2 = ( (u64) r->LO.uw0 ) | ( ( (u64) r->HI.uw0 ) << 32 );
	temp += lltemp2;
	
	r->LO.sq0 = (s32) temp;
	r->HI.sq0 = (s32) ( temp >> 32 );
	
	// R5900 can additionally write to register
	if ( i.Rd )
	{
		r->GPR [ i.Rd ].sq0 = (s32) temp;
	}
}

static void Recompile::MADD1 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MADD1 || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	// if rs is between -0x800 and 0x7ff, then multiply takes 6 cycles
	static const int c_iMultiplyCycles_Fast = 6;
	
	// if rs is between 0x800 and 0xfffff or between -0x7ff and -0x100000, then multiply takes 9 cycles
	static const int c_iMultiplyCycles_Med = 9;
	
	// otherwise, multiply takes 13 cycles
	static const int c_iMultiplyCycles_Slow = 13;
	
	// check if mul/div unit is in use
	if ( r->MulDiv_BusyUntil_Cycle1 > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle1;
	}

	/*
	// calculate cycles mul/div unit will be busy for
	r->MulDiv_BusyUntil_Cycle = r->CycleCount + c_iMultiplyCycles_Slow;
	if ( r->GPR [ i.Rs ].s < 0x800 && r->GPR [ i.Rs ].s >= -0x800 )
	{
		r->MulDiv_BusyUntil_Cycle = r->CycleCount + c_iMultiplyCycles_Fast;
	}
	else if ( r->GPR [ i.Rs ].s < 0x100000 && r->GPR [ i.Rs ].s >= -0x100000 )
	{
		r->MulDiv_BusyUntil_Cycle = r->CycleCount + c_iMultiplyCycles_Med;
	}
	*/
	
	// multiply signed Lo,Hi = rs * rt
	//r->HiLo.sValue = ((s64) (r->GPR [ i.Rs ].s)) * ((s64) (r->GPR [ i.Rt ].s));
	s64 temp, lltemp2;
	temp = ( (s64) ( r->GPR [ i.Rs ].sw0 ) ) * ( (s64) ( r->GPR [ i.Rt ].sw0 ) );
	
	// also add in hi,lo
	lltemp2 = ( (u64) r->LO.uw2 ) | ( ( (u64) r->HI.uw2 ) << 32 );
	temp += lltemp2;
	
	r->LO.sq1 = (s32) temp;
	r->HI.sq1 = (s32) ( temp >> 32 );
	
	// R5900 can additionally write to register
	if ( i.Rd )
	{
		r->GPR [ i.Rd ].sq0 = (s32) temp;
	}
}

static void Recompile::MADDU ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MADDU || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	// if rs is between 0 and 0x7ff, then multiply takes 6 cycles
	static const int c_iMultiplyCycles_Fast = 6;
	
	// if rs is between 0x800 and 0xfffff, then multiply takes 9 cycles
	static const int c_iMultiplyCycles_Med = 9;
	
	// otherwise, multiply takes 13 cycles
	static const int c_iMultiplyCycles_Slow = 13;
	
	// check if mul/div unit is in use
	if ( r->MulDiv_BusyUntil_Cycle > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle;
	}
	
	/*
	// calculate cycles mul/div unit will be busy for
	r->MulDiv_BusyUntil_Cycle = r->CycleCount + c_iMultiplyCycles_Slow;
	if ( r->GPR [ i.Rs ].u < 0x800 )
	{
		r->MulDiv_BusyUntil_Cycle = r->CycleCount + c_iMultiplyCycles_Fast;
	}
	else if ( r->GPR [ i.Rs ].u < 0x100000 )
	{
		r->MulDiv_BusyUntil_Cycle = r->CycleCount + c_iMultiplyCycles_Med;
	}
	*/

	// multiply unsigned Lo,Hi = rs * rt
	//r->HiLo.uValue = ((u64) (r->GPR [ i.Rs ].u)) * ((u64) (r->GPR [ i.Rt ].u));
	u64 temp, ulltemp2;
	temp = ( (u64) ( r->GPR [ i.Rs ].uw0 ) ) * ( (u64) ( r->GPR [ i.Rt ].uw0 ) );
	
	// also add in hi,lo
	ulltemp2 = ( (u64) r->LO.uw0 ) | ( ( (u64) r->HI.uw0 ) << 32 );
	temp += ulltemp2;
	
	r->LO.sq0 = (s32) temp;
	r->HI.sq0 = (s32) ( temp >> 32 );
	
	// R5900 can additionally write to register
	if ( i.Rd )
	{
		r->GPR [ i.Rd ].sq0 = (s32) temp;
	}
	
#if defined INLINE_DEBUG_MULTU || defined INLINE_DEBUG_R5900
	debug << "; Output: LO=" << r->LO.s << "; HI=" << r->HI.s << "; rd=" << r->GPR [ i.Rd ].s;
#endif
}

static void Recompile::MADDU1 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MADDU1 || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	// if rs is between 0 and 0x7ff, then multiply takes 6 cycles
	static const int c_iMultiplyCycles_Fast = 6;
	
	// if rs is between 0x800 and 0xfffff, then multiply takes 9 cycles
	static const int c_iMultiplyCycles_Med = 9;
	
	// otherwise, multiply takes 13 cycles
	static const int c_iMultiplyCycles_Slow = 13;
	
	// check if mul/div unit is in use
	if ( r->MulDiv_BusyUntil_Cycle1 > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle1;
	}
	
	/*
	// calculate cycles mul/div unit will be busy for
	r->MulDiv_BusyUntil_Cycle = r->CycleCount + c_iMultiplyCycles_Slow;
	if ( r->GPR [ i.Rs ].u < 0x800 )
	{
		r->MulDiv_BusyUntil_Cycle = r->CycleCount + c_iMultiplyCycles_Fast;
	}
	else if ( r->GPR [ i.Rs ].u < 0x100000 )
	{
		r->MulDiv_BusyUntil_Cycle = r->CycleCount + c_iMultiplyCycles_Med;
	}
	*/

	// multiply unsigned Lo,Hi = rs * rt
	//r->HiLo.uValue = ((u64) (r->GPR [ i.Rs ].u)) * ((u64) (r->GPR [ i.Rt ].u));
	u64 temp, ulltemp2;
	temp = ( (u64) ( r->GPR [ i.Rs ].uw0 ) ) * ( (u64) ( r->GPR [ i.Rt ].uw0 ) );
	
	// also add in hi,lo
	ulltemp2 = ( (u64) r->LO.uw2 ) | ( ( (u64) r->HI.uw2 ) << 32 );
	temp += ulltemp2;
	
	r->LO.sq1 = (s32) temp;
	r->HI.sq1 = (s32) ( temp >> 32 );
	
	// R5900 can additionally write to register
	if ( i.Rd )
	{
		r->GPR [ i.Rd ].sq0 = (s32) temp;
	}
	
#if defined INLINE_DEBUG_MULTU || defined INLINE_DEBUG_R5900
	debug << "; Output: LO=" << r->LO.s << "; HI=" << r->HI.s << "; rd=" << r->GPR [ i.Rd ].s;
#endif
}



// Load/Store instructions //

static void Recompile::SD ( Instruction::Format i )
{
#if defined INLINE_DEBUG_SD || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rt = " << r->GPR [ i.Rt ].u << "; base = " << r->GPR [ i.Base ].u;
#endif
	
	// SW rt, offset(base)
	u32 StoreAddress;
	
	// check if storing to data cache
	//StoreAddress = r->GPR [ i.Base ].s + i.sOffset;
	StoreAddress = r->GPR [ i.Base ].sw0 + i.sOffset;
	
	// *** testing *** alert if load is from unaligned address
	if ( StoreAddress & 0x7 )
	{
		cout << "\nhps2x64 ALERT: StoreAddress is unaligned for SD @ cycle=" << dec << r->CycleCount << " PC=" << hex << r->PC << " Address=" << StoreAddress << "\n";
		
		// *** testing ***
		r->ProcessSynchronousInterrupt ( Cpu::EXC_ADES );
		return;
	}
	
	// clear top 3 bits since there is no data cache for caching stores
	// don't clear top 3 bits since scratchpad is at 0x70000000
	//StoreAddress &= 0x1fffffff;
	
	
	// ***todo*** perform store of word
	//r->Bus->Write ( StoreAddress, r->GPR [ i.Rt ].uq0, 0xffffffffffffffffULL );
	r->Bus->Write_t<0xffffffffffffffffULL> ( StoreAddress, r->GPR [ i.Rt ].uq0 );
	
	

	// used for debugging
	r->Last_WriteAddress = StoreAddress;
	r->Last_ReadWriteAddress = StoreAddress;
	
#ifdef INLINE_DEBUG_TRACE
	TRACE_VALUE ( r->GPR [ i.Rt ].uw0 )
#endif
}

static void Recompile::LD ( Instruction::Format i )
{
#if defined INLINE_DEBUG_LD || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: base = " << r->GPR [ i.Base ].u;
#endif
	
	// LW rt, offset(base)
	
	u32 LoadAddress;
	
	// set load to happen after delay slot
	//LoadAddress = r->GPR [ i.Base ].s + i.sOffset;
	LoadAddress = r->GPR [ i.Base ].sw0 + i.sOffset;
	
	// *** testing *** alert if load is from unaligned address
	if ( LoadAddress & 0x7 )
	{
		cout << "\nhps2x64 ALERT: LoadAddress is unaligned for LD @ cycle=" << dec << r->CycleCount << " PC=" << hex << r->PC << " Address=" << LoadAddress << "\n";
		
		// *** testing ***
		r->ProcessSynchronousInterrupt ( Cpu::EXC_ADEL );
		return;
	}
	
	
	// ***todo*** perform signed load of word
	//r->GPR [ i.Rt ].uq0 = r->Bus->Read ( LoadAddress, 0xffffffffffffffffULL );
	r->GPR [ i.Rt ].uq0 = r->Bus->Read_t<0xffffffffffffffffULL> ( LoadAddress );
	
	
	
	// used for debugging
	r->Last_ReadAddress = LoadAddress;
	r->Last_ReadWriteAddress = LoadAddress;

#ifdef INLINE_DEBUG_TRACE
	TRACE_VALUE ( r->GPR [ i.Rt ].uw0 )
#endif

#if defined INLINE_DEBUG_LD || defined INLINE_DEBUG_R5900
	debug << "; Output: rt = " << r->GPR [ i.Rt ].sq0;
#endif
}

static void Recompile::LWU ( Instruction::Format i )
{
#if defined INLINE_DEBUG_LWU || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: base = " << r->GPR [ i.Base ].u;
#endif
	
	// LW rt, offset(base)
	
	u32 LoadAddress;
	
	// set load to happen after delay slot
	//LoadAddress = r->GPR [ i.Base ].s + i.sOffset;
	LoadAddress = r->GPR [ i.Base ].sw0 + i.sOffset;
	
	// *** testing *** alert if load is from unaligned address
	if ( LoadAddress & 0x3 )
	{
		cout << "\nhps2x64 ALERT: LoadAddress is unaligned for LW @ cycle=" << dec << r->CycleCount << " PC=" << hex << r->PC << " Address=" << LoadAddress << "\n";
		
		// *** testing ***
		r->ProcessSynchronousInterrupt ( Cpu::EXC_ADEL );
		return;
	}
	
	
	// ***todo*** perform signed load of word
	//r->GPR [ i.Rt ].uq0 = (u32) r->Bus->Read ( LoadAddress, 0xffffffffULL );
	r->GPR [ i.Rt ].uq0 = (u32) r->Bus->Read_t<0xffffffff> ( LoadAddress );
	
	
	
	// used for debugging
	r->Last_ReadAddress = LoadAddress;
	r->Last_ReadWriteAddress = LoadAddress;

#ifdef INLINE_DEBUG_TRACE
	TRACE_VALUE ( r->GPR [ i.Rt ].uw0 )
#endif
	
#if defined INLINE_DEBUG_LWU || defined INLINE_DEBUG_R5900
	debug << "; Output: rt = " << r->GPR [ i.Rt ].sq0;
#endif
}

static void Recompile::SDL ( Instruction::Format i )
{
#if defined INLINE_DEBUG_SDL || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rt = " << r->GPR [ i.Rt ].u << "; base = " << r->GPR [ i.Base ].u;
#endif

	static const u32 c_Mask = 0xffffffff;
	u64 Type, Offset;

	// SDL rt, offset(base)
	
	// step 1: check if storing to data cache
	//u32 StoreAddress = r->GPR [ i.Base ].s + i.sOffset;
	u32 StoreAddress = r->GPR [ i.Base ].sw0 + i.sOffset;

	// clear top 3 bits since there is no data cache for caching stores
	//StoreAddress &= 0x1fffffff;
	
	
	// ***todo*** perform store SDL
	r->Bus->Write ( StoreAddress & ~7, r->GPR [ i.Rt ].uq0 >> ( ( 7 - ( StoreAddress & 7 ) ) << 3 ), 0xffffffffffffffffULL >> ( ( 7 - ( StoreAddress & 7 ) ) << 3 ) );
	

	// used for debugging
	r->Last_WriteAddress = StoreAddress;
	r->Last_ReadWriteAddress = StoreAddress;

#ifdef INLINE_DEBUG_TRACE
	TRACE_VALUE ( r->GPR [ i.Rt ].uw0 )
#endif
}

static void Recompile::SDR ( Instruction::Format i )
{
#if defined INLINE_DEBUG_SDR || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rt = " << r->GPR [ i.Rt ].u << "; base = " << r->GPR [ i.Base ].u;
#endif

	static const u32 c_Mask = 0xffffffff;
	u32 Type, Offset;
	
	// SDR rt, offset(base)
	
	// step 1: check if storing to data cache
	//u32 StoreAddress = r->GPR [ i.Base ].s + i.sOffset;
	u32 StoreAddress = r->GPR [ i.Base ].sw0 + i.sOffset;

	// clear top 3 bits since there is no data cache for caching stores
	//StoreAddress &= 0x1fffffff;
	
	
	// ***todo*** perform store SWR
	r->Bus->Write ( StoreAddress & ~7, r->GPR [ i.Rt ].uq0 << ( ( StoreAddress & 7 ) << 3 ), 0xffffffffffffffffULL << ( ( StoreAddress & 7 ) << 3 ) );
	
	
	
	// used for debugging
	r->Last_WriteAddress = StoreAddress;
	r->Last_ReadWriteAddress = StoreAddress;
	
#ifdef INLINE_DEBUG_TRACE
	TRACE_VALUE ( r->GPR [ i.Rt ].uw0 )
#endif
}

static void Recompile::LDL ( Instruction::Format i )
{
#if defined INLINE_DEBUG_LDL || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: base = " << r->GPR [ i.Base ].u;
#endif

	// LDL rt, offset(base)
	
	u32 LoadAddress;
	u64 Value, Temp;
	
	// set load to happen after delay slot
	//LoadAddress = r->GPR [ i.Base ].s + i.sOffset;
	LoadAddress = r->GPR [ i.Base ].sw0 + i.sOffset;
	
	
	// ***todo*** perform load LDL
	//Value = r->Bus->Read ( LoadAddress & ~7, 0xffffffffffffffffULL );
	Value = r->Bus->Read_t<0xffffffffffffffffULL> ( LoadAddress & ~7 );
	
	Value <<= ( ( 7 - ( LoadAddress & 7 ) ) << 3 );
	Temp = r->GPR [ i.Rt ].uq0;
	Temp <<= ( ( ( LoadAddress & 7 ) + 1 ) << 3 );
	if ( ( LoadAddress & 7 ) == 7 ) Temp = 0;
	Temp >>= ( ( ( LoadAddress & 7 ) + 1 ) << 3 );
	r->GPR [ i.Rt ].sq0 = Value | Temp;
	
	
	// used for debugging
	r->Last_ReadAddress = LoadAddress;
	r->Last_ReadWriteAddress = LoadAddress;

#ifdef INLINE_DEBUG_TRACE
	TRACE_VALUE ( r->GPR [ i.Rt ].uw0 )
#endif
	
#if defined INLINE_DEBUG_LDL || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "; Output: rt = " << r->GPR [ i.Rt ].sq0;
#endif
}

static void Recompile::LDR ( Instruction::Format i )
{
#if defined INLINE_DEBUG_LDR || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: base = " << r->GPR [ i.Base ].u;
#endif

	// LDR rt, offset(base)
	
	u32 LoadAddress;
	u64 Value, Temp;
	
	// set load to happen after delay slot
	//LoadAddress = r->GPR [ i.Base ].s + i.sOffset;
	LoadAddress = r->GPR [ i.Base ].sw0 + i.sOffset;
	
	
	// ***todo*** perform load LWR
	//Value = r->Bus->Read ( LoadAddress & ~7, 0xffffffffffffffffULL );
	Value = r->Bus->Read_t<0xffffffffffffffffULL> ( LoadAddress & ~7 );
	
	Value >>= ( ( LoadAddress & 7 ) << 3 );
	Temp = r->GPR [ i.Rt ].uq0;
	Temp >>= ( ( 8 - ( LoadAddress & 7 ) ) << 3 );
	if ( ( LoadAddress & 7 ) == 0 ) Temp = 0;
	Temp <<= ( ( 8 - ( LoadAddress & 7 ) ) << 3 );
	r->GPR [ i.Rt ].sq0 = Value | Temp;
	
	
	// used for debugging
	r->Last_ReadAddress = LoadAddress;
	r->Last_ReadWriteAddress = LoadAddress;

#ifdef INLINE_DEBUG_TRACE
	TRACE_VALUE ( r->GPR [ i.Rt ].uw0 )
#endif
	
#if defined INLINE_DEBUG_LDR || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "; Output: rt = " << r->GPR [ i.Rt ].sq0;
#endif
}

static void Recompile::LQ ( Instruction::Format i )
{
#if defined INLINE_DEBUG_LQ || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: base = " << r->GPR [ i.Base ].u;
#endif

	// LQ rt, offset(base)
	
	u32 LoadAddress;
	u64* Data;
	
	// set load to happen after delay slot
	//LoadAddress = r->GPR [ i.Base ].s + i.sOffset;
	LoadAddress = r->GPR [ i.Base ].sw0 + i.sOffset;
	
#if defined INLINE_DEBUG_LQ || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " LoadAddress=" << LoadAddress;
#endif

	// *** testing *** alert if load is from unaligned address
	// this one actually does NOT have any address errors due to alignment, as it pretends the bottom 4-bits are zero on R5900
	//if ( LoadAddress & 0xf )
	//{
	//	cout << "\nhps2x64 ALERT: LoadAddress is unaligned for LW @ cycle=" << dec << r->CycleCount << " PC=" << hex << r->PC << " Address=" << LoadAddress << "\n";
	//	
	//	// *** testing ***
	//	r->ProcessSynchronousInterrupt ( Cpu::EXC_ADEL );
	//	return;
	//}
	
	// bottom four bits of Address are cleared
	LoadAddress &= ~0xf;
	
	// ***todo*** perform signed load of word
	//Data = (u64*) r->Bus->Read ( LoadAddress, 0 );
	//r->GPR [ i.Rt ].uLo = Data [ 1 ];
	//r->GPR [ i.Rt ].uHi = Data [ 0 ];
	
	
	//Data = (u64*) r->Bus->Read ( LoadAddress, 0 );
	Data = (u64*) r->Bus->Read_t<0> ( LoadAddress );
	
	r->GPR [ i.Rt ].uLo = Data [ 0 ];
	r->GPR [ i.Rt ].uHi = Data [ 1 ];
	
	//r->GPR [ i.Rt ].uw3 = ((u32*)Data) [ 0 ];
	//r->GPR [ i.Rt ].uw2 = ((u32*)Data) [ 1 ];
	//r->GPR [ i.Rt ].uw1 = ((u32*)Data) [ 2 ];
	//r->GPR [ i.Rt ].uw0 = ((u32*)Data) [ 3 ];

	//r->GPR [ i.Rt ].uw0 = ((u32*)Data) [ 0 ];
	//r->GPR [ i.Rt ].uw1 = ((u32*)Data) [ 1 ];
	//r->GPR [ i.Rt ].uw2 = ((u32*)Data) [ 2 ];
	//r->GPR [ i.Rt ].uw3 = ((u32*)Data) [ 3 ];
	
	
	// used for debugging
	r->Last_ReadAddress = LoadAddress;
	r->Last_ReadWriteAddress = LoadAddress;

#ifdef INLINE_DEBUG_TRACE
	TRACE_VALUE ( r->GPR [ i.Rt ].uw0 )
#endif

#if defined INLINE_DEBUG_LQ || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "; Output: rt = " << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif
}

static void Recompile::SQ ( Instruction::Format i )
{
#if defined INLINE_DEBUG_SQ || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rt = " << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1 << "; base = " << r->GPR [ i.Base ].u;
#endif

	// SQ rt, offset(base)
	u32 StoreAddress;
	
	// check if storing to data cache
	//StoreAddress = r->GPR [ i.Base ].s + i.sOffset;
	StoreAddress = r->GPR [ i.Base ].sw0 + i.sOffset;
	
	// *** testing *** alert if load is from unaligned address
	// this one actually does NOT have any address errors due to alignment, as it pretends the bottom 4-bits are zero on R5900
	//if ( StoreAddress & 0xf )
	//{
	//	cout << "\nhps2x64 ALERT: StoreAddress is unaligned for SW @ cycle=" << dec << r->CycleCount << " PC=" << hex << r->PC << " Address=" << StoreAddress << "\n";
	//	
	//	// *** testing ***
	//	r->ProcessSynchronousInterrupt ( Cpu::EXC_ADES );
	//	return;
	//}
	
	// clear top 3 bits since there is no data cache for caching stores
	// don't clear top 3 bits since scratchpad is at 0x70000000
	//StoreAddress &= 0x1fffffff;
	
	// bottom four bits of Address are cleared
	StoreAddress &= ~0xf;
	
	// ***todo*** perform store of word
	// *note* probably want to pass a pointer to hi part, since that is in lower area of memory
	//r->Bus->Write ( StoreAddress, & ( r->GPR [ i.Rt ].uw0 ), 0 );
	r->Bus->Write_t<0> ( StoreAddress, (u64) & ( r->GPR [ i.Rt ].uw0 ) );
	
	

	// used for debugging
	r->Last_WriteAddress = StoreAddress;
	r->Last_ReadWriteAddress = StoreAddress;
	
#ifdef INLINE_DEBUG_TRACE
	TRACE_VALUE ( r->GPR [ i.Rt ].uw0 )
#endif
}


static void Recompile::MOVZ ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MOVZ || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rd=" << r->GPR [ i.Rd ].uq0 << "; rs=" << r->GPR [ i.Rs ].uq0 << "; rt=" << r->GPR [ i.Rt ].uq0;
#endif

	// movz rd, rs, rt
	// if ( rt == 0 ) rd = rs
	
	if ( !r->GPR [ i.Rt ].uq0 )
	{
		r->GPR [ i.Rd ].uq0 = r->GPR [ i.Rs ].uq0;
	}
	
#if defined INLINE_DEBUG_MOVZ || defined INLINE_DEBUG_R5900
	debug << hex << "; Output: rd=" << r->GPR [ i.Rd ].uq0;
#endif
}

static void Recompile::MOVN ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MOVN || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rd=" << r->GPR [ i.Rd ].uq0 << "; rs=" << r->GPR [ i.Rs ].uq0 << "; rt=" << r->GPR [ i.Rt ].uq0;
#endif

	// movn rd, rs, rt
	// if ( rt != 0 ) rd = rs

	if ( r->GPR [ i.Rt ].uq0 )
	{
		r->GPR [ i.Rd ].uq0 = r->GPR [ i.Rs ].uq0;
	}
	
#if defined INLINE_DEBUG_MOVN || defined INLINE_DEBUG_R5900
	debug << hex << "; Output: rd=" << r->GPR [ i.Rd ].uq0;
#endif
}


static void Recompile::MFHI1 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MFHI1 || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: HI1 = " << r->HI.uq1;
#endif
	
	// this instruction interlocks if multiply/divide unit is busy
	if ( r->MulDiv_BusyUntil_Cycle1 > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle1;
	}
	
	// move from Hi register
	r->GPR [ i.Rd ].uq0 = r->HI.uq1;
	
#if defined INLINE_DEBUG_MFHI || defined INLINE_DEBUG_R5900
	debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

static void Recompile::MTHI1 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MTHI1 || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	r->HI.uq1 = r->GPR [ i.Rs ].uq0;
}

static void Recompile::MFLO1 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MFLO1 || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: LO1 = " << r->LO.uq1;
#endif

	
	// this instruction interlocks if multiply/divide unit is busy
	if ( r->MulDiv_BusyUntil_Cycle1 > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle1;
	}
	
	// move from Lo register
	r->GPR [ i.Rd ].uq0 = r->LO.uq1;
	
#if defined INLINE_DEBUG_MFLO || defined INLINE_DEBUG_R5900
	debug << "; Output: rd = " << r->GPR [ i.Rd ].u;
#endif
}

static void Recompile::MTLO1 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MTLO1 || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	r->LO.uq1 = r->GPR [ i.Rs ].uq0;
}



static void Recompile::MFSA ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MFSA || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: SA = " << r->SA;
#endif

	// MFSA rd
	// only operates in instruction pipeline 0
	r->GPR [ i.Rd ].uq0 = r->SA;

#if defined INLINE_DEBUG_MFSA || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "; Output: rd = " << r->GPR [ i.Rd ].uq0;
#endif
}

static void Recompile::MTSA ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MTSA || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].uq0;
#endif

	// MTSA rs
	// only operates in instruction pipeline 0
	r->SA = r->GPR [ i.Rs ].uq0;
	
#if defined INLINE_DEBUG_MTSA || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "; Output: SA = " << r->SA;
#endif
}

static void Recompile::MTSAB ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MTSAB || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].uq0;
#endif

	// MTSAB rs, immediate
	// only operates in instruction pipeline 0
	// or does this not shift left 3 ??
	//r->SA = ( ( ( r->GPR [ i.Rs ].uw0 ) ^ ( i.uImmediate ) ) & 0xf ) << 3;
	r->SA = ( ( ( r->GPR [ i.Rs ].uw0 ) ^ ( i.uImmediate ) ) & 0xf );
	
#if defined INLINE_DEBUG_MTSAB || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "; Output: SA = " << r->SA;
#endif
}

static void Recompile::MTSAH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MTSAH || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].uq0;
#endif

	// MTSAH rs, immediate
	// only operates in instruction pipeline 0
	// or does this shift left only one instead ??
	//r->SA = ( ( ( r->GPR [ i.Rs ].uw0 ) ^ ( i.uImmediate ) ) & 0x7 ) << 4;
	r->SA = ( ( ( r->GPR [ i.Rs ].uw0 ) ^ ( i.uImmediate ) ) & 0x7 ) << 1;
	
#if defined INLINE_DEBUG_MTSAH || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "; Output: SA = " << r->SA;
#endif
}




// Branch instructions //

static void Recompile::BEQL ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BEQL || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u << "; rt = " << r->GPR [ i.Rt ].u;
#endif

	if ( r->GPR [ i.Rs ].u == r->GPR [ i.Rt ].u )
	{
		// taking branch (after delay slot of course) //
		
		// next instruction is in the branch delay slot
		Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		d->cb = r->ProcessBranchDelaySlot_t<OPBEQL>;
		r->Status.DelaySlot_Valid |= 0x2;
		
#if defined INLINE_DEBUG_BEQ || defined INLINE_DEBUG_R5900
		debug << ";  WILL TAKE";
#endif
	}
	else
	{
		// NOT branching (and skips next instruction) //
		
		// skip next instruction
		r->NextPC = r->PC + 8;
		
		// *todo* add an additional cycle for the skipped instruction
		//CycleCount++;
	}
}

static void Recompile::BNEL ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BNEL || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u << "; rt = " << r->GPR [ i.Rt ].u;
#endif

	if ( r->GPR [ i.Rs ].u != r->GPR [ i.Rt ].u )
	{
		// next instruction is in the branch delay slot
		Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		d->cb = r->ProcessBranchDelaySlot_t<OPBNEL>;
		r->Status.DelaySlot_Valid |= 0x2;
		
#if defined INLINE_DEBUG_BNE || defined INLINE_DEBUG_R5900
		debug << ";  WILL TAKE";
#endif
	}
	else
	{
		// NOT branching (and skips next instruction) //
		
		// skip next instruction
		r->NextPC = r->PC + 8;
		
		// *todo* add an additional cycle for the skipped instruction
		//CycleCount++;
	}
}

static void Recompile::BGEZL ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BGEZL || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u;
#endif

	if ( r->GPR [ i.Rs ].s >= 0 )
	{
		// next instruction is in the branch delay slot
		Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		d->cb = r->ProcessBranchDelaySlot_t<OPBGEZL>;
		r->Status.DelaySlot_Valid |= 0x2;
		
#if defined INLINE_DEBUG_BGEZ || defined INLINE_DEBUG_R5900
		debug << ";  WILL TAKE";
#endif
	}
	else
	{
		// NOT branching (and skips next instruction) //
		
		// skip next instruction
		r->NextPC = r->PC + 8;
		
		// *todo* add an additional cycle for the skipped instruction
		//CycleCount++;
	}
}

static void Recompile::BLEZL ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BLEZL || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u;
#endif

	if ( r->GPR [ i.Rs ].s <= 0 )
	{
		// next instruction is in the branch delay slot
		Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		d->cb = r->ProcessBranchDelaySlot_t<OPBLEZL>;
		r->Status.DelaySlot_Valid |= 0x2;
		
#if defined INLINE_DEBUG_BLEZ || defined INLINE_DEBUG_R5900
		debug << ";  WILL TAKE";
#endif
	}
	else
	{
		// NOT branching (and skips next instruction) //
		
		// skip next instruction
		r->NextPC = r->PC + 8;
		
		// *todo* add an additional cycle for the skipped instruction
		//CycleCount++;
	}
}

static void Recompile::BGTZL ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BGTZL || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u;
#endif

	if ( r->GPR [ i.Rs ].s > 0 )
	{
		// next instruction is in the branch delay slot
		Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		d->cb = r->ProcessBranchDelaySlot_t<OPBGTZL>;
		r->Status.DelaySlot_Valid |= 0x2;
		
#if defined INLINE_DEBUG_BGTZ || defined INLINE_DEBUG_R5900
		debug << ";  WILL TAKE";
#endif
	}
	else
	{
		// NOT branching (and skips next instruction) //
		
		// skip next instruction
		r->NextPC = r->PC + 8;
		
		// *todo* add an additional cycle for the skipped instruction
		//CycleCount++;
	}
}

static void Recompile::BLTZL ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BLTZL || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u;
#endif

	if ( r->GPR [ i.Rs ].s < 0 )
	{
		// next instruction is in the branch delay slot
		Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		d->cb = r->ProcessBranchDelaySlot_t<OPBLTZL>;
		r->Status.DelaySlot_Valid |= 0x2;
		
#if defined INLINE_DEBUG_BLTZ || defined INLINE_DEBUG_R5900
		debug << ";  WILL TAKE";
#endif
	}
	else
	{
		// NOT branching (and skips next instruction) //
		
		// skip next instruction
		r->NextPC = r->PC + 8;
		
		// *todo* add an additional cycle for the skipped instruction
		//CycleCount++;
	}
}



static void Recompile::BLTZALL ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BLTZALL || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u;
#endif

	if ( r->GPR [ i.Rs ].s < 0 )
	{
		// next instruction is in the branch delay slot
		Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		d->cb = r->ProcessBranchDelaySlot_t<OPBLTZALL>;
		r->Status.DelaySlot_Valid |= 0x2;
		
#if defined INLINE_DEBUG_BLTZAL || defined INLINE_DEBUG_R5900
		debug << ";  WILL TAKE";
#endif
	}
	else
	{
		// NOT branching (and skips next instruction) //
		
		// skip next instruction
		r->NextPC = r->PC + 8;
		
		// *todo* add an additional cycle for the skipped instruction
		//CycleCount++;
	}
	
	////////////////////////////////////////////////////////////////////////
	// Store return address when instruction is executed in r31
	// for this instruction this happens whether branch is taken or not
	// *note* this must happen AFTER comparison check
	r->GPR [ 31 ].u = r->PC + 8;
}

static void Recompile::BGEZALL ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BGEZALL || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rs = " << r->GPR [ i.Rs ].u;
#endif

	if ( r->GPR [ i.Rs ].s >= 0 )
	{
		// next instruction is in the branch delay slot
		Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		d->cb = r->ProcessBranchDelaySlot_t<OPBGEZALL>;
		r->Status.DelaySlot_Valid |= 0x2;
		
#if defined INLINE_DEBUG_BGEZAL || defined INLINE_DEBUG_R5900
		debug << ";  WILL TAKE";
#endif
	}
	else
	{
		// NOT branching (and skips next instruction) //
		
		// skip next instruction
		r->NextPC = r->PC + 8;
		
		// *todo* add an additional cycle for the skipped instruction
		//CycleCount++;
	}

	////////////////////////////////////////////////////////////////////////
	// Store return address when instruction is executed in r31
	// for this instruction this happens whether branch is taken or not
	// *note* this must happen AFTER comparison check
	r->GPR [ 31 ].u = r->PC + 8;
}




static void Recompile::BC0T ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BC0T || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; CPCOND0=" << hex << r->CPCOND0;
#endif

	if ( r->CPCOND0 )
	{
		// next instruction is in the branch delay slot
		Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		d->cb = r->ProcessBranchDelaySlot_t<OPBC0T>;
		r->Status.DelaySlot_Valid |= 0x2;
		
#if defined INLINE_DEBUG_BC0T || defined INLINE_DEBUG_R5900
		debug << ";  WILL TAKE";
#endif
	}
}

static void Recompile::BC0TL ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BC0TL || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; CPCOND0=" << hex << r->CPCOND0;
#endif

	if ( r->CPCOND0 )
	{
		// taking branch (after delay slot of course) //
		
		// next instruction is in the branch delay slot
		Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		d->cb = r->ProcessBranchDelaySlot_t<OPBC0TL>;
		r->Status.DelaySlot_Valid |= 0x2;
		
#if defined INLINE_DEBUG_BC0TL || defined INLINE_DEBUG_R5900
		debug << ";  WILL TAKE";
#endif
	}
	else
	{
		// NOT branching (and skips next instruction) //
		
		// skip next instruction
		r->NextPC = r->PC + 8;
		
		// *todo* add an additional cycle for the skipped instruction
		//CycleCount++;
	}
}

static void Recompile::BC0F ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BC0F || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; CPCOND0=" << hex << r->CPCOND0;
#endif

	if ( !r->CPCOND0 )
	{
		// next instruction is in the branch delay slot
		Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		d->cb = r->ProcessBranchDelaySlot_t<OPBC0F>;
		r->Status.DelaySlot_Valid |= 0x2;
		
#if defined INLINE_DEBUG_BC0F || defined INLINE_DEBUG_R5900
		debug << ";  WILL TAKE";
#endif
	}
}

static void Recompile::BC0FL ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BC0FL || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; CPCOND0=" << hex << r->CPCOND0;
#endif

	if ( !r->CPCOND0 )
	{
		// taking branch (after delay slot of course) //
		
		// next instruction is in the branch delay slot
		Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		d->cb = r->ProcessBranchDelaySlot_t<OPBC0FL>;
		r->Status.DelaySlot_Valid |= 0x2;
		
#if defined INLINE_DEBUG_BC0FL || defined INLINE_DEBUG_R5900
		debug << ";  WILL TAKE";
#endif
	}
	else
	{
		// NOT branching (and skips next instruction) //
		
		// skip next instruction
		r->NextPC = r->PC + 8;
		
		// *todo* add an additional cycle for the skipped instruction
		//CycleCount++;
	}
}

static void Recompile::BC1T ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BC1T || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: FCR31 = " << r->CPC1 [ 31 ];
#endif

	if ( r->CPC1 [ 31 ] & 0x00800000 )
	{
		// next instruction is in the branch delay slot
		Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		d->cb = r->ProcessBranchDelaySlot_t<OPBC1T>;
		r->Status.DelaySlot_Valid |= 0x2;
		
#if defined INLINE_DEBUG_BC1T || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU
		debug << ";  WILL TAKE";
#endif
	}
}

static void Recompile::BC1TL ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BC1TL || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: FCR31 = " << r->CPC1 [ 31 ];
#endif

	if ( r->CPC1 [ 31 ] & 0x00800000 )
	{
		// taking branch (after delay slot of course) //
		
		// next instruction is in the branch delay slot
		Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		d->cb = r->ProcessBranchDelaySlot_t<OPBC1TL>;
		r->Status.DelaySlot_Valid |= 0x2;
		
#if defined INLINE_DEBUG_BC1TL || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU
		debug << ";  WILL TAKE";
#endif
	}
	else
	{
		// NOT branching (and skips next instruction) //
		
		// skip next instruction
		r->NextPC = r->PC + 8;
		
		// *todo* add an additional cycle for the skipped instruction
		//CycleCount++;
	}
}

static void Recompile::BC1F ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BC1F || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: FCR31 = " << r->CPC1 [ 31 ];
#endif

	if ( ! ( r->CPC1 [ 31 ] & 0x00800000 ) )
	{
		// next instruction is in the branch delay slot
		Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		d->cb = r->ProcessBranchDelaySlot_t<OPBC1F>;
		r->Status.DelaySlot_Valid |= 0x2;
		
#if defined INLINE_DEBUG_BC1F || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU
		debug << ";  WILL TAKE";
#endif
	}
}

static void Recompile::BC1FL ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BC1FL || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: FCR31 = " << r->CPC1 [ 31 ];
#endif

	if ( ! ( r->CPC1 [ 31 ] & 0x00800000 ) )
	{
		// taking branch (after delay slot of course) //
		
		// next instruction is in the branch delay slot
		Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		d->cb = r->ProcessBranchDelaySlot_t<OPBC1FL>;
		r->Status.DelaySlot_Valid |= 0x2;
		
#if defined INLINE_DEBUG_BC1FL || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU
		debug << ";  WILL TAKE";
#endif
	}
	else
	{
		// NOT branching (and skips next instruction) //
		
		// skip next instruction
		r->NextPC = r->PC + 8;
		
		// *todo* add an additional cycle for the skipped instruction
		//CycleCount++;
	}
}

static void Recompile::BC2T ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BC2T || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	// branch if vu1 is running
	if ( VU1::_VU1->Running )
	{
		// taking branch (after delay slot of course) //
		
		// next instruction is in the branch delay slot
		Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		d->cb = r->ProcessBranchDelaySlot_t<OPBC2T>;
		r->Status.DelaySlot_Valid |= 0x2;
		
#if defined INLINE_DEBUG_BC2T || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
		debug << ";  WILL TAKE";
#endif
	}
	else
	{
		// NOT branching (and skips next instruction) //
		
		// skip next instruction
		r->NextPC = r->PC + 8;
		
		// *todo* add an additional cycle for the skipped instruction
		//CycleCount++;
	}
}

static void Recompile::BC2TL ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BC2TL || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	// branch if vu1 is running
	if ( VU1::_VU1->Running )
	{
		// taking branch (after delay slot of course) //
		
		// next instruction is in the branch delay slot
		Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		d->cb = r->ProcessBranchDelaySlot_t<OPBC2TL>;
		r->Status.DelaySlot_Valid |= 0x2;
		
#if defined INLINE_DEBUG_BC2TL || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
		debug << ";  WILL TAKE";
#endif
	}
	else
	{
		// NOT branching (and skips next instruction) //
		
		// skip next instruction
		r->NextPC = r->PC + 8;
		
		// *todo* add an additional cycle for the skipped instruction
		//CycleCount++;
	}
}

static void Recompile::BC2F ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BC2F || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	// branch if vu1 is NOT running
	if ( !VU1::_VU1->Running )
	{
		// taking branch (after delay slot of course) //
		
		// next instruction is in the branch delay slot
		Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		d->cb = r->ProcessBranchDelaySlot_t<OPBC2F>;
		r->Status.DelaySlot_Valid |= 0x2;
		
#if defined INLINE_DEBUG_BC2F || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
		debug << ";  WILL TAKE";
#endif
	}
	else
	{
		// NOT branching (and skips next instruction) //
		
		// skip next instruction
		r->NextPC = r->PC + 8;
		
		// *todo* add an additional cycle for the skipped instruction
		//CycleCount++;
	}
}

static void Recompile::BC2FL ( Instruction::Format i )
{
#if defined INLINE_DEBUG_BC2FL || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	// branch if vu1 is NOT running
	if ( !VU1::_VU1->Running )
	{
		// taking branch (after delay slot of course) //
		
		// next instruction is in the branch delay slot
		Cpu::DelaySlot *d = & ( r->DelaySlots [ r->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		d->cb = r->ProcessBranchDelaySlot_t<OPBC2FL>;
		r->Status.DelaySlot_Valid |= 0x2;
		
#if defined INLINE_DEBUG_BC2FL || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
		debug << ";  WILL TAKE";
#endif
	}
	else
	{
		// NOT branching (and skips next instruction) //
		
		// skip next instruction
		r->NextPC = r->PC + 8;
		
		// *todo* add an additional cycle for the skipped instruction
		//CycleCount++;
	}
}






static void Recompile::TGEI ( Instruction::Format i )
{
#if defined INLINE_DEBUG_TGEI || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	// trap if rs >= signed imm
	if ( r->GPR [ i.Rs ].sq0 >= (s64) i.sImmediate )
	{
		r->ProcessSynchronousInterrupt ( Cpu::EXC_TRAP );
	}
}

static void Recompile::TGEIU ( Instruction::Format i )
{
#if defined INLINE_DEBUG_TGEIU || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	// trap if rs >= unsigned imm
	if ( r->GPR [ i.Rs ].uq0 >= (u64) i.uImmediate )
	{
		r->ProcessSynchronousInterrupt ( Cpu::EXC_TRAP );
	}
}

static void Recompile::TLTI ( Instruction::Format i )
{
#if defined INLINE_DEBUG_TLTI || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	// trap if rs < signed imm
	if ( r->GPR [ i.Rs ].sq0 < (s64) i.sImmediate )
	{
		r->ProcessSynchronousInterrupt ( Cpu::EXC_TRAP );
	}
}

static void Recompile::TLTIU ( Instruction::Format i )
{
#if defined INLINE_DEBUG_TLTIU || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	// trap if rs < unsigned imm
	if ( r->GPR [ i.Rs ].uq0 < (u64) i.uImmediate )
	{
		r->ProcessSynchronousInterrupt ( Cpu::EXC_TRAP );
	}
}

static void Recompile::TEQI ( Instruction::Format i )
{
#if defined INLINE_DEBUG_TEQI || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	// trap if rs == signed imm
	if ( r->GPR [ i.Rs ].sq0 == (s64) i.sImmediate )
	{
		r->ProcessSynchronousInterrupt ( Cpu::EXC_TRAP );
	}
}

static void Recompile::TNEI ( Instruction::Format i )
{
#if defined INLINE_DEBUG_TNEI || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	// trap if rs != signed imm
	if ( r->GPR [ i.Rs ].sq0 != (s64) i.sImmediate )
	{
		r->ProcessSynchronousInterrupt ( Cpu::EXC_TRAP );
	}
}


static void Recompile::TGE ( Instruction::Format i )
{
#if defined INLINE_DEBUG_TGE || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	// trap if rs >= rt
	if ( r->GPR [ i.Rs ].sq0 >= r->GPR [ i.Rt ].sq0 )
	{
		r->ProcessSynchronousInterrupt ( Cpu::EXC_TRAP );
	}
}

static void Recompile::TGEU ( Instruction::Format i )
{
#if defined INLINE_DEBUG_TGEU || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	// trap if rs >= rt
	if ( r->GPR [ i.Rs ].uq0 >= r->GPR [ i.Rt ].uq0 )
	{
		r->ProcessSynchronousInterrupt ( Cpu::EXC_TRAP );
	}
}

static void Recompile::TLT ( Instruction::Format i )
{
#if defined INLINE_DEBUG_TLT || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	// trap if rs < rt
	if ( r->GPR [ i.Rs ].sq0 < r->GPR [ i.Rt ].sq0 )
	{
		r->ProcessSynchronousInterrupt ( Cpu::EXC_TRAP );
	}
}

static void Recompile::TLTU ( Instruction::Format i )
{
#if defined INLINE_DEBUG_TLTU || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	// trap if rs < rt
	if ( r->GPR [ i.Rs ].uq0 < r->GPR [ i.Rt ].uq0 )
	{
		r->ProcessSynchronousInterrupt ( Cpu::EXC_TRAP );
	}
}

static void Recompile::TEQ ( Instruction::Format i )
{
#if defined INLINE_DEBUG_TEQ || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	// trap if rs == rt
	if ( r->GPR [ i.Rs ].uq0 == r->GPR [ i.Rt ].uq0 )
	{
		r->ProcessSynchronousInterrupt ( Cpu::EXC_TRAP );
	}
}

static void Recompile::TNE ( Instruction::Format i )
{
#if defined INLINE_DEBUG_TNE || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	// trap if rs != rt
	if ( r->GPR [ i.Rs ].uq0 != r->GPR [ i.Rt ].uq0 )
	{
		r->ProcessSynchronousInterrupt ( Cpu::EXC_TRAP );
	}
}


















// * R5900 Parallel (SIMD) instructions * //


static void Recompile::PADSBH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PADSBH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	// first four halfwords subtract, next four add
	r->GPR [ i.Rd ].uh0 = r->GPR [ i.Rs ].uh0 - r->GPR [ i.Rt ].uh0;
	r->GPR [ i.Rd ].uh1 = r->GPR [ i.Rs ].uh1 - r->GPR [ i.Rt ].uh1;
	r->GPR [ i.Rd ].uh2 = r->GPR [ i.Rs ].uh2 - r->GPR [ i.Rt ].uh2;
	r->GPR [ i.Rd ].uh3 = r->GPR [ i.Rs ].uh3 - r->GPR [ i.Rt ].uh3;
	r->GPR [ i.Rd ].uh4 = r->GPR [ i.Rs ].uh4 + r->GPR [ i.Rt ].uh4;
	r->GPR [ i.Rd ].uh5 = r->GPR [ i.Rs ].uh5 + r->GPR [ i.Rt ].uh5;
	r->GPR [ i.Rd ].uh6 = r->GPR [ i.Rs ].uh6 + r->GPR [ i.Rt ].uh6;
	r->GPR [ i.Rd ].uh7 = r->GPR [ i.Rs ].uh7 + r->GPR [ i.Rt ].uh7;
	
#if defined INLINE_DEBUG_PADSBH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PABSH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PABSH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].sh0 = ( r->GPR [ i.Rt ].sh0 >= 0 ) ? r->GPR [ i.Rt ].sh0 : -r->GPR [ i.Rt ].sh0;
	r->GPR [ i.Rd ].sh1 = ( r->GPR [ i.Rt ].sh1 >= 0 ) ? r->GPR [ i.Rt ].sh1 : -r->GPR [ i.Rt ].sh1;
	r->GPR [ i.Rd ].sh2 = ( r->GPR [ i.Rt ].sh2 >= 0 ) ? r->GPR [ i.Rt ].sh2 : -r->GPR [ i.Rt ].sh2;
	r->GPR [ i.Rd ].sh3 = ( r->GPR [ i.Rt ].sh3 >= 0 ) ? r->GPR [ i.Rt ].sh3 : -r->GPR [ i.Rt ].sh3;
	r->GPR [ i.Rd ].sh4 = ( r->GPR [ i.Rt ].sh4 >= 0 ) ? r->GPR [ i.Rt ].sh4 : -r->GPR [ i.Rt ].sh4;
	r->GPR [ i.Rd ].sh5 = ( r->GPR [ i.Rt ].sh5 >= 0 ) ? r->GPR [ i.Rt ].sh5 : -r->GPR [ i.Rt ].sh5;
	r->GPR [ i.Rd ].sh6 = ( r->GPR [ i.Rt ].sh6 >= 0 ) ? r->GPR [ i.Rt ].sh6 : -r->GPR [ i.Rt ].sh6;
	r->GPR [ i.Rd ].sh7 = ( r->GPR [ i.Rt ].sh7 >= 0 ) ? r->GPR [ i.Rt ].sh7 : -r->GPR [ i.Rt ].sh7;
	
#if defined INLINE_DEBUG_PABSH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PABSW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PABSW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].sw0 = ( r->GPR [ i.Rt ].sw0 >= 0 ) ? r->GPR [ i.Rt ].sw0 : -r->GPR [ i.Rt ].sw0;
	r->GPR [ i.Rd ].sw1 = ( r->GPR [ i.Rt ].sw1 >= 0 ) ? r->GPR [ i.Rt ].sw1 : -r->GPR [ i.Rt ].sw1;
	r->GPR [ i.Rd ].sw2 = ( r->GPR [ i.Rt ].sw2 >= 0 ) ? r->GPR [ i.Rt ].sw2 : -r->GPR [ i.Rt ].sw2;
	r->GPR [ i.Rd ].sw3 = ( r->GPR [ i.Rt ].sw3 >= 0 ) ? r->GPR [ i.Rt ].sw3 : -r->GPR [ i.Rt ].sw3;
	
#if defined INLINE_DEBUG_PABSW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PAND ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PAND || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1 << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].uq0 = r->GPR [ i.Rs ].uq0 & r->GPR [ i.Rt ].uq0;
	r->GPR [ i.Rd ].uq1 = r->GPR [ i.Rs ].uq1 & r->GPR [ i.Rt ].uq1;
	
#if defined INLINE_DEBUG_PAND || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PXOR ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PXOR || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1 << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].uq0 = r->GPR [ i.Rs ].uq0 ^ r->GPR [ i.Rt ].uq0;
	r->GPR [ i.Rd ].uq1 = r->GPR [ i.Rs ].uq1 ^ r->GPR [ i.Rt ].uq1;
	
#if defined INLINE_DEBUG_PXOR || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::POR ( Instruction::Format i )
{
#if defined INLINE_DEBUG_POR || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1 << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].uq0 = r->GPR [ i.Rs ].uq0 | r->GPR [ i.Rt ].uq0;
	r->GPR [ i.Rd ].uq1 = r->GPR [ i.Rs ].uq1 | r->GPR [ i.Rt ].uq1;
	
#if defined INLINE_DEBUG_POR || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PNOR ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PNOR || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1 << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].uq0 = ~( r->GPR [ i.Rs ].uq0 | r->GPR [ i.Rt ].uq0 );
	r->GPR [ i.Rd ].uq1 = ~( r->GPR [ i.Rs ].uq1 | r->GPR [ i.Rt ].uq1 );
	
#if defined INLINE_DEBUG_PNOR || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}


static void Recompile::PLZCW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PLZCW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
#endif

	if ( r->GPR [ i.Rs ].sw0 < 0 )
	{
		// if negative, it is actually a leading one count
		r->GPR [ i.Rd ].sw0 = CountLeadingZeros32 ( ~r->GPR [ i.Rs ].sw0 ) - 1;
	}
	else
	{
		// is positive, so do a leading zero count //
		r->GPR [ i.Rd ].sw0 = CountLeadingZeros32 ( r->GPR [ i.Rs ].sw0 ) - 1;
	}
	
	if ( r->GPR [ i.Rs ].sw1 < 0 )
	{
		// if negative, it is actually a leading one count
		r->GPR [ i.Rd ].sw1 = CountLeadingZeros32 ( ~r->GPR [ i.Rs ].sw1 ) - 1;
	}
	else
	{
		// is positive, so do a leading zero count //
		r->GPR [ i.Rd ].sw1 = CountLeadingZeros32 ( r->GPR [ i.Rs ].sw1 ) - 1;
	}
	
#if defined INLINE_DEBUG_PLZCW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}


static void Recompile::PMFHL_LH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PMFHL_LH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " LO=" << r->LO.uq0 << " " << r->LO.uq1;
	debug << hex << " HI=" << r->HI.uq0 << " " << r->HI.uq1;
#endif

	r->GPR [ i.Rd ].uh0 = r->LO.uh0;
	r->GPR [ i.Rd ].uh1 = r->LO.uh2;
	r->GPR [ i.Rd ].uh2 = r->HI.uh0;
	r->GPR [ i.Rd ].uh3 = r->HI.uh2;
	r->GPR [ i.Rd ].uh4 = r->LO.uh4;
	r->GPR [ i.Rd ].uh5 = r->LO.uh6;
	r->GPR [ i.Rd ].uh6 = r->HI.uh4;
	r->GPR [ i.Rd ].uh7 = r->HI.uh6;
	
#if defined INLINE_DEBUG_PMFHL_LH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PMFHL_LW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PMFHL_LW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " LO=" << r->LO.uq0 << " " << r->LO.uq1;
	debug << hex << " HI=" << r->HI.uq0 << " " << r->HI.uq1;
#endif

	r->GPR [ i.Rd ].uw0 = r->LO.uw0;
	r->GPR [ i.Rd ].uw1 = r->HI.uw0;
	r->GPR [ i.Rd ].uw2 = r->LO.uw2;
	r->GPR [ i.Rd ].uw3 = r->HI.uw2;
	
#if defined INLINE_DEBUG_PMFHL_LW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PMFHL_UW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PMFHL_UW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " LO=" << r->LO.uq0 << " " << r->LO.uq1;
	debug << hex << " HI=" << r->HI.uq0 << " " << r->HI.uq1;
#endif

	r->GPR [ i.Rd ].uw0 = r->LO.uw1;
	r->GPR [ i.Rd ].uw1 = r->HI.uw1;
	r->GPR [ i.Rd ].uw2 = r->LO.uw3;
	r->GPR [ i.Rd ].uw3 = r->HI.uw3;
	
#if defined INLINE_DEBUG_PMFHL_UW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PMTHL_LW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PMTHL_LW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
#endif

	r->LO.sw0 = r->GPR [ i.Rs ].sw0;
	r->LO.sw2 = r->GPR [ i.Rs ].sw2;
	r->HI.sw0 = r->GPR [ i.Rs ].sw1;
	r->HI.sw2 = r->GPR [ i.Rs ].sw3;
	
#if defined INLINE_DEBUG_PMTHL_LW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " LO=" << r->LO.uq0 << " " << r->LO.uq1 << " HI=" << r->HI.uq0 << " " << r->HI.uq1;
#endif
}


static void Recompile::PMFHL_SH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PMFHL_SH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	//cout << "\nhps2x64: ERROR: R5900: Instruction not implemented: PMFHL_SH";
	
	r->GPR [ i.Rd ].sh0 = ( ( r->LO.sw0 > 0x7fff ) ? 0x7fff : ( ( r->LO.sw0 < -0x8000 ) ? 0x8000 : r->LO.sw0 ) );
	r->GPR [ i.Rd ].sh1 = ( ( r->LO.sw1 > 0x7fff ) ? 0x7fff : ( ( r->LO.sw1 < -0x8000 ) ? 0x8000 : r->LO.sw1 ) );
	r->GPR [ i.Rd ].sh2 = ( ( r->HI.sw0 > 0x7fff ) ? 0x7fff : ( ( r->HI.sw0 < -0x8000 ) ? 0x8000 : r->HI.sw0 ) );
	r->GPR [ i.Rd ].sh3 = ( ( r->HI.sw1 > 0x7fff ) ? 0x7fff : ( ( r->HI.sw1 < -0x8000 ) ? 0x8000 : r->HI.sw1 ) );
	r->GPR [ i.Rd ].sh4 = ( ( r->LO.sw2 > 0x7fff ) ? 0x7fff : ( ( r->LO.sw2 < -0x8000 ) ? 0x8000 : r->LO.sw2 ) );
	r->GPR [ i.Rd ].sh5 = ( ( r->LO.sw3 > 0x7fff ) ? 0x7fff : ( ( r->LO.sw3 < -0x8000 ) ? 0x8000 : r->LO.sw3 ) );
	r->GPR [ i.Rd ].sh6 = ( ( r->HI.sw2 > 0x7fff ) ? 0x7fff : ( ( r->HI.sw2 < -0x8000 ) ? 0x8000 : r->HI.sw2 ) );
	r->GPR [ i.Rd ].sh7 = ( ( r->HI.sw3 > 0x7fff ) ? 0x7fff : ( ( r->HI.sw3 < -0x8000 ) ? 0x8000 : r->HI.sw3 ) );
}


static void Recompile::PMFHL_SLW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PMFHL_SLW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	//cout << "\nhps2x64: ERROR: R5900: Instruction not implemented: PMFHL_SLW";
	
	s64 sTemp64;
	
	sTemp64 = r->LO.uw0;
	sTemp64 |= ( r->HI.uq0 << 32 );
	r->GPR [ i.Rd ].sq0 = ( ( sTemp64 >= 0x7fffffffLL ) ? 0x7fffffffLL : ( ( sTemp64 <= -0x80000000LL ) ? -0x80000000LL : r->LO.sw0 ) );
	
	sTemp64 = r->LO.uw2;
	sTemp64 |= ( r->HI.uq1 << 32 );
	r->GPR [ i.Rd ].sq1 = ( ( sTemp64 >= 0x7fffffffLL ) ? 0x7fffffffLL : ( ( sTemp64 <= -0x80000000LL ) ? -0x80000000LL : r->LO.sw2 ) );
}



static void Recompile::PSLLH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PSLLH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].uh0 = r->GPR [ i.Rt ].uh0 << i.Shift;
	r->GPR [ i.Rd ].uh1 = r->GPR [ i.Rt ].uh1 << i.Shift;
	r->GPR [ i.Rd ].uh2 = r->GPR [ i.Rt ].uh2 << i.Shift;
	r->GPR [ i.Rd ].uh3 = r->GPR [ i.Rt ].uh3 << i.Shift;
	r->GPR [ i.Rd ].uh4 = r->GPR [ i.Rt ].uh4 << i.Shift;
	r->GPR [ i.Rd ].uh5 = r->GPR [ i.Rt ].uh5 << i.Shift;
	r->GPR [ i.Rd ].uh6 = r->GPR [ i.Rt ].uh6 << i.Shift;
	r->GPR [ i.Rd ].uh7 = r->GPR [ i.Rt ].uh7 << i.Shift;
	
#if defined INLINE_DEBUG_PSLLH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PSLLW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PSLLW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].ux = r->GPR [ i.Rt ].ux << i.Shift;
	r->GPR [ i.Rd ].uy = r->GPR [ i.Rt ].uy << i.Shift;
	r->GPR [ i.Rd ].uz = r->GPR [ i.Rt ].uz << i.Shift;
	r->GPR [ i.Rd ].uw = r->GPR [ i.Rt ].uw << i.Shift;
	
#if defined INLINE_DEBUG_PSLLW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PSRLH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PSRLH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].uh0 = r->GPR [ i.Rt ].uh0 >> i.Shift;
	r->GPR [ i.Rd ].uh1 = r->GPR [ i.Rt ].uh1 >> i.Shift;
	r->GPR [ i.Rd ].uh2 = r->GPR [ i.Rt ].uh2 >> i.Shift;
	r->GPR [ i.Rd ].uh3 = r->GPR [ i.Rt ].uh3 >> i.Shift;
	r->GPR [ i.Rd ].uh4 = r->GPR [ i.Rt ].uh4 >> i.Shift;
	r->GPR [ i.Rd ].uh5 = r->GPR [ i.Rt ].uh5 >> i.Shift;
	r->GPR [ i.Rd ].uh6 = r->GPR [ i.Rt ].uh6 >> i.Shift;
	r->GPR [ i.Rd ].uh7 = r->GPR [ i.Rt ].uh7 >> i.Shift;
	
#if defined INLINE_DEBUG_PSRLH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PSRLW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PSRLW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].ux = r->GPR [ i.Rt ].ux >> i.Shift;
	r->GPR [ i.Rd ].uy = r->GPR [ i.Rt ].uy >> i.Shift;
	r->GPR [ i.Rd ].uz = r->GPR [ i.Rt ].uz >> i.Shift;
	r->GPR [ i.Rd ].uw = r->GPR [ i.Rt ].uw >> i.Shift;
	
#if defined INLINE_DEBUG_PSRLW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}


static void Recompile::PSRAH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PSRAH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].sh0 = r->GPR [ i.Rt ].sh0 >> i.Shift;
	r->GPR [ i.Rd ].sh1 = r->GPR [ i.Rt ].sh1 >> i.Shift;
	r->GPR [ i.Rd ].sh2 = r->GPR [ i.Rt ].sh2 >> i.Shift;
	r->GPR [ i.Rd ].sh3 = r->GPR [ i.Rt ].sh3 >> i.Shift;
	r->GPR [ i.Rd ].sh4 = r->GPR [ i.Rt ].sh4 >> i.Shift;
	r->GPR [ i.Rd ].sh5 = r->GPR [ i.Rt ].sh5 >> i.Shift;
	r->GPR [ i.Rd ].sh6 = r->GPR [ i.Rt ].sh6 >> i.Shift;
	r->GPR [ i.Rd ].sh7 = r->GPR [ i.Rt ].sh7 >> i.Shift;
	
#if defined INLINE_DEBUG_PSRAH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PSRAW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PSRAW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].sx = r->GPR [ i.Rt ].sx >> i.Shift;
	r->GPR [ i.Rd ].sy = r->GPR [ i.Rt ].sy >> i.Shift;
	r->GPR [ i.Rd ].sz = r->GPR [ i.Rt ].sz >> i.Shift;
	r->GPR [ i.Rd ].sw = r->GPR [ i.Rt ].sw >> i.Shift;
	
#if defined INLINE_DEBUG_PSRAW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PSLLVW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PSLLVW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].sq0 = (s32) ( r->GPR [ i.Rt ].uw0 << ( r->GPR [ i.Rs ].uw0 & 0x1f ) );
	r->GPR [ i.Rd ].sq1 = (s32) ( r->GPR [ i.Rt ].uw2 << ( r->GPR [ i.Rs ].uw2 & 0x1f ) );
	
#if defined INLINE_DEBUG_PSLLVW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PSRLVW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PSRLVW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].sq0 = (s32) ( r->GPR [ i.Rt ].uw0 >> ( r->GPR [ i.Rs ].uw0 & 0x1f ) );
	r->GPR [ i.Rd ].sq1 = (s32) ( r->GPR [ i.Rt ].uw2 >> ( r->GPR [ i.Rs ].uw2 & 0x1f ) );
	
#if defined INLINE_DEBUG_PSRLVW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PSRAVW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PSRAVW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].sq0 = (s32) ( r->GPR [ i.Rt ].sw0 >> ( r->GPR [ i.Rs ].sw0 & 0x1f ) );
	r->GPR [ i.Rd ].sq1 = (s32) ( r->GPR [ i.Rt ].sw2 >> ( r->GPR [ i.Rs ].sw2 & 0x1f ) );
	
#if defined INLINE_DEBUG_PSRAVW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}


static void Recompile::PADDB ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PADDB || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].ub0 = r->GPR [ i.Rs ].ub0 + r->GPR [ i.Rt ].ub0;
	r->GPR [ i.Rd ].ub1 = r->GPR [ i.Rs ].ub1 + r->GPR [ i.Rt ].ub1;
	r->GPR [ i.Rd ].ub2 = r->GPR [ i.Rs ].ub2 + r->GPR [ i.Rt ].ub2;
	r->GPR [ i.Rd ].ub3 = r->GPR [ i.Rs ].ub3 + r->GPR [ i.Rt ].ub3;
	r->GPR [ i.Rd ].ub4 = r->GPR [ i.Rs ].ub4 + r->GPR [ i.Rt ].ub4;
	r->GPR [ i.Rd ].ub5 = r->GPR [ i.Rs ].ub5 + r->GPR [ i.Rt ].ub5;
	r->GPR [ i.Rd ].ub6 = r->GPR [ i.Rs ].ub6 + r->GPR [ i.Rt ].ub6;
	r->GPR [ i.Rd ].ub7 = r->GPR [ i.Rs ].ub7 + r->GPR [ i.Rt ].ub7;
	r->GPR [ i.Rd ].ub8 = r->GPR [ i.Rs ].ub8 + r->GPR [ i.Rt ].ub8;
	r->GPR [ i.Rd ].ub9 = r->GPR [ i.Rs ].ub9 + r->GPR [ i.Rt ].ub9;
	r->GPR [ i.Rd ].ub10 = r->GPR [ i.Rs ].ub10 + r->GPR [ i.Rt ].ub10;
	r->GPR [ i.Rd ].ub11 = r->GPR [ i.Rs ].ub11 + r->GPR [ i.Rt ].ub11;
	r->GPR [ i.Rd ].ub12 = r->GPR [ i.Rs ].ub12 + r->GPR [ i.Rt ].ub12;
	r->GPR [ i.Rd ].ub13 = r->GPR [ i.Rs ].ub13 + r->GPR [ i.Rt ].ub13;
	r->GPR [ i.Rd ].ub14 = r->GPR [ i.Rs ].ub14 + r->GPR [ i.Rt ].ub14;
	r->GPR [ i.Rd ].ub15 = r->GPR [ i.Rs ].ub15 + r->GPR [ i.Rt ].ub15;
	
#if defined INLINE_DEBUG_PADDB || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PADDH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PADDH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].uh0 = r->GPR [ i.Rs ].uh0 + r->GPR [ i.Rt ].uh0;
	r->GPR [ i.Rd ].uh1 = r->GPR [ i.Rs ].uh1 + r->GPR [ i.Rt ].uh1;
	r->GPR [ i.Rd ].uh2 = r->GPR [ i.Rs ].uh2 + r->GPR [ i.Rt ].uh2;
	r->GPR [ i.Rd ].uh3 = r->GPR [ i.Rs ].uh3 + r->GPR [ i.Rt ].uh3;
	r->GPR [ i.Rd ].uh4 = r->GPR [ i.Rs ].uh4 + r->GPR [ i.Rt ].uh4;
	r->GPR [ i.Rd ].uh5 = r->GPR [ i.Rs ].uh5 + r->GPR [ i.Rt ].uh5;
	r->GPR [ i.Rd ].uh6 = r->GPR [ i.Rs ].uh6 + r->GPR [ i.Rt ].uh6;
	r->GPR [ i.Rd ].uh7 = r->GPR [ i.Rs ].uh7 + r->GPR [ i.Rt ].uh7;
	
#if defined INLINE_DEBUG_PADDH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PADDW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PADDW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].ux = r->GPR [ i.Rs ].ux + r->GPR [ i.Rt ].ux;
	r->GPR [ i.Rd ].uy = r->GPR [ i.Rs ].uy + r->GPR [ i.Rt ].uy;
	r->GPR [ i.Rd ].uz = r->GPR [ i.Rs ].uz + r->GPR [ i.Rt ].uz;
	r->GPR [ i.Rd ].uw = r->GPR [ i.Rs ].uw + r->GPR [ i.Rt ].uw;
	
#if defined INLINE_DEBUG_PADDW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PSUBB ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PSUBB || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].ub0 = r->GPR [ i.Rs ].ub0 - r->GPR [ i.Rt ].ub0;
	r->GPR [ i.Rd ].ub1 = r->GPR [ i.Rs ].ub1 - r->GPR [ i.Rt ].ub1;
	r->GPR [ i.Rd ].ub2 = r->GPR [ i.Rs ].ub2 - r->GPR [ i.Rt ].ub2;
	r->GPR [ i.Rd ].ub3 = r->GPR [ i.Rs ].ub3 - r->GPR [ i.Rt ].ub3;
	r->GPR [ i.Rd ].ub4 = r->GPR [ i.Rs ].ub4 - r->GPR [ i.Rt ].ub4;
	r->GPR [ i.Rd ].ub5 = r->GPR [ i.Rs ].ub5 - r->GPR [ i.Rt ].ub5;
	r->GPR [ i.Rd ].ub6 = r->GPR [ i.Rs ].ub6 - r->GPR [ i.Rt ].ub6;
	r->GPR [ i.Rd ].ub7 = r->GPR [ i.Rs ].ub7 - r->GPR [ i.Rt ].ub7;
	r->GPR [ i.Rd ].ub8 = r->GPR [ i.Rs ].ub8 - r->GPR [ i.Rt ].ub8;
	r->GPR [ i.Rd ].ub9 = r->GPR [ i.Rs ].ub9 - r->GPR [ i.Rt ].ub9;
	r->GPR [ i.Rd ].ub10 = r->GPR [ i.Rs ].ub10 - r->GPR [ i.Rt ].ub10;
	r->GPR [ i.Rd ].ub11 = r->GPR [ i.Rs ].ub11 - r->GPR [ i.Rt ].ub11;
	r->GPR [ i.Rd ].ub12 = r->GPR [ i.Rs ].ub12 - r->GPR [ i.Rt ].ub12;
	r->GPR [ i.Rd ].ub13 = r->GPR [ i.Rs ].ub13 - r->GPR [ i.Rt ].ub13;
	r->GPR [ i.Rd ].ub14 = r->GPR [ i.Rs ].ub14 - r->GPR [ i.Rt ].ub14;
	r->GPR [ i.Rd ].ub15 = r->GPR [ i.Rs ].ub15 - r->GPR [ i.Rt ].ub15;
	
#if defined INLINE_DEBUG_PSUBB || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PSUBH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PSUBH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].uh0 = r->GPR [ i.Rs ].uh0 - r->GPR [ i.Rt ].uh0;
	r->GPR [ i.Rd ].uh1 = r->GPR [ i.Rs ].uh1 - r->GPR [ i.Rt ].uh1;
	r->GPR [ i.Rd ].uh2 = r->GPR [ i.Rs ].uh2 - r->GPR [ i.Rt ].uh2;
	r->GPR [ i.Rd ].uh3 = r->GPR [ i.Rs ].uh3 - r->GPR [ i.Rt ].uh3;
	r->GPR [ i.Rd ].uh4 = r->GPR [ i.Rs ].uh4 - r->GPR [ i.Rt ].uh4;
	r->GPR [ i.Rd ].uh5 = r->GPR [ i.Rs ].uh5 - r->GPR [ i.Rt ].uh5;
	r->GPR [ i.Rd ].uh6 = r->GPR [ i.Rs ].uh6 - r->GPR [ i.Rt ].uh6;
	r->GPR [ i.Rd ].uh7 = r->GPR [ i.Rs ].uh7 - r->GPR [ i.Rt ].uh7;
	
#if defined INLINE_DEBUG_PSUBH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PSUBW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PSUBW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].ux = r->GPR [ i.Rs ].ux - r->GPR [ i.Rt ].ux;
	r->GPR [ i.Rd ].uy = r->GPR [ i.Rs ].uy - r->GPR [ i.Rt ].uy;
	r->GPR [ i.Rd ].uz = r->GPR [ i.Rs ].uz - r->GPR [ i.Rt ].uz;
	r->GPR [ i.Rd ].uw = r->GPR [ i.Rs ].uw - r->GPR [ i.Rt ].uw;
	
#if defined INLINE_DEBUG_PSUBW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}


static void Recompile::PADDSB ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PADDSB || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	//cout << "\nhps2x64: ERROR: R5900: Instruction not implemented: PADDSB";
	
	s32 sResult32;
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb0 ) + ( (s32) r->GPR [ i.Rt ].sb0 );
	r->GPR [ i.Rd ].sb0 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb1 ) + ( (s32) r->GPR [ i.Rt ].sb1 );
	r->GPR [ i.Rd ].sb1 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb2 ) + ( (s32) r->GPR [ i.Rt ].sb2 );
	r->GPR [ i.Rd ].sb2 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb3 ) + ( (s32) r->GPR [ i.Rt ].sb3 );
	r->GPR [ i.Rd ].sb3 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb4 ) + ( (s32) r->GPR [ i.Rt ].sb4 );
	r->GPR [ i.Rd ].sb4 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb5 ) + ( (s32) r->GPR [ i.Rt ].sb5 );
	r->GPR [ i.Rd ].sb5 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb6 ) + ( (s32) r->GPR [ i.Rt ].sb6 );
	r->GPR [ i.Rd ].sb6 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb7 ) + ( (s32) r->GPR [ i.Rt ].sb7 );
	r->GPR [ i.Rd ].sb7 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb8 ) + ( (s32) r->GPR [ i.Rt ].sb8 );
	r->GPR [ i.Rd ].sb8 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb9 ) + ( (s32) r->GPR [ i.Rt ].sb9 );
	r->GPR [ i.Rd ].sb9 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb10 ) + ( (s32) r->GPR [ i.Rt ].sb10 );
	r->GPR [ i.Rd ].sb10 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb11 ) + ( (s32) r->GPR [ i.Rt ].sb11 );
	r->GPR [ i.Rd ].sb11 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb12 ) + ( (s32) r->GPR [ i.Rt ].sb12 );
	r->GPR [ i.Rd ].sb12 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb13 ) + ( (s32) r->GPR [ i.Rt ].sb13 );
	r->GPR [ i.Rd ].sb13 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb14 ) + ( (s32) r->GPR [ i.Rt ].sb14 );
	r->GPR [ i.Rd ].sb14 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb15 ) + ( (s32) r->GPR [ i.Rt ].sb15 );
	r->GPR [ i.Rd ].sb15 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
}

static void Recompile::PADDSH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PADDSH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	//cout << "\nhps2x64: ERROR: R5900: Instruction not implemented: PADDSH";
	
	s32 sResult32;
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sh0 ) + ( (s32) r->GPR [ i.Rt ].sh0 );
	r->GPR [ i.Rd ].sh0 = ( ( sResult32 > 0x7fff ) ? 0x7fff : ( ( sResult32 < -0x8000 ) ? -0x8000 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sh1 ) + ( (s32) r->GPR [ i.Rt ].sh1 );
	r->GPR [ i.Rd ].sh1 = ( ( sResult32 > 0x7fff ) ? 0x7fff : ( ( sResult32 < -0x8000 ) ? -0x8000 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sh2 ) + ( (s32) r->GPR [ i.Rt ].sh2 );
	r->GPR [ i.Rd ].sh2 = ( ( sResult32 > 0x7fff ) ? 0x7fff : ( ( sResult32 < -0x8000 ) ? -0x8000 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sh3 ) + ( (s32) r->GPR [ i.Rt ].sh3 );
	r->GPR [ i.Rd ].sh3 = ( ( sResult32 > 0x7fff ) ? 0x7fff : ( ( sResult32 < -0x8000 ) ? -0x8000 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sh4 ) + ( (s32) r->GPR [ i.Rt ].sh4 );
	r->GPR [ i.Rd ].sh4 = ( ( sResult32 > 0x7fff ) ? 0x7fff : ( ( sResult32 < -0x8000 ) ? -0x8000 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sh5 ) + ( (s32) r->GPR [ i.Rt ].sh5 );
	r->GPR [ i.Rd ].sh5 = ( ( sResult32 > 0x7fff ) ? 0x7fff : ( ( sResult32 < -0x8000 ) ? -0x8000 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sh6 ) + ( (s32) r->GPR [ i.Rt ].sh6 );
	r->GPR [ i.Rd ].sh6 = ( ( sResult32 > 0x7fff ) ? 0x7fff : ( ( sResult32 < -0x8000 ) ? -0x8000 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sh7 ) + ( (s32) r->GPR [ i.Rt ].sh7 );
	r->GPR [ i.Rd ].sh7 = ( ( sResult32 > 0x7fff ) ? 0x7fff : ( ( sResult32 < -0x8000 ) ? -0x8000 : sResult32 ) );
}

static void Recompile::PADDSW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PADDSW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	//cout << "\nhps2x64: ERROR: R5900: Instruction not implemented: PADDSW";
	
	s64 sResult64;
	
	sResult64 = ( (s64) r->GPR [ i.Rs ].sw0 ) + ( (s64) r->GPR [ i.Rt ].sw0 );
	r->GPR [ i.Rd ].sw0 = ( ( sResult64 > 0x7fffffffLL ) ? 0x7fffffff : ( ( sResult64 < -0x80000000LL ) ? -0x80000000 : sResult64 ) );
	
	sResult64 = ( (s64) r->GPR [ i.Rs ].sw1 ) + ( (s64) r->GPR [ i.Rt ].sw1 );
	r->GPR [ i.Rd ].sw1 = ( ( sResult64 > 0x7fffffffLL ) ? 0x7fffffff : ( ( sResult64 < -0x80000000LL ) ? -0x80000000 : sResult64 ) );
	
	sResult64 = ( (s64) r->GPR [ i.Rs ].sw2 ) + ( (s64) r->GPR [ i.Rt ].sw2 );
	r->GPR [ i.Rd ].sw2 = ( ( sResult64 > 0x7fffffffLL ) ? 0x7fffffff : ( ( sResult64 < -0x80000000LL ) ? -0x80000000 : sResult64 ) );
	
	sResult64 = ( (s64) r->GPR [ i.Rs ].sw3 ) + ( (s64) r->GPR [ i.Rt ].sw3 );
	r->GPR [ i.Rd ].sw3 = ( ( sResult64 > 0x7fffffffLL ) ? 0x7fffffff : ( ( sResult64 < -0x80000000LL ) ? -0x80000000 : sResult64 ) );
	
#if defined INLINE_DEBUG_PADDSW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}


static void Recompile::PSUBSB ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PSUBSB || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	//cout << "\nhps2x64: ERROR: R5900: Instruction not implemented: PSUBSB";
	
	s32 sResult32;
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb0 ) - ( (s32) r->GPR [ i.Rt ].sb0 );
	r->GPR [ i.Rd ].sb0 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb1 ) - ( (s32) r->GPR [ i.Rt ].sb1 );
	r->GPR [ i.Rd ].sb1 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb2 ) - ( (s32) r->GPR [ i.Rt ].sb2 );
	r->GPR [ i.Rd ].sb2 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb3 ) - ( (s32) r->GPR [ i.Rt ].sb3 );
	r->GPR [ i.Rd ].sb3 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb4 ) - ( (s32) r->GPR [ i.Rt ].sb4 );
	r->GPR [ i.Rd ].sb4 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb5 ) - ( (s32) r->GPR [ i.Rt ].sb5 );
	r->GPR [ i.Rd ].sb5 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb6 ) - ( (s32) r->GPR [ i.Rt ].sb6 );
	r->GPR [ i.Rd ].sb6 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb7 ) - ( (s32) r->GPR [ i.Rt ].sb7 );
	r->GPR [ i.Rd ].sb7 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb8 ) - ( (s32) r->GPR [ i.Rt ].sb8 );
	r->GPR [ i.Rd ].sb8 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb9 ) - ( (s32) r->GPR [ i.Rt ].sb9 );
	r->GPR [ i.Rd ].sb9 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb10 ) - ( (s32) r->GPR [ i.Rt ].sb10 );
	r->GPR [ i.Rd ].sb10 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb11 ) - ( (s32) r->GPR [ i.Rt ].sb11 );
	r->GPR [ i.Rd ].sb11 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb12 ) - ( (s32) r->GPR [ i.Rt ].sb12 );
	r->GPR [ i.Rd ].sb12 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb13 ) - ( (s32) r->GPR [ i.Rt ].sb13 );
	r->GPR [ i.Rd ].sb13 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb14 ) - ( (s32) r->GPR [ i.Rt ].sb14 );
	r->GPR [ i.Rd ].sb14 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sb15 ) - ( (s32) r->GPR [ i.Rt ].sb15 );
	r->GPR [ i.Rd ].sb15 = ( ( sResult32 > 0x7f ) ? 0x7f : ( ( sResult32 < -0x80 ) ? -0x80 : sResult32 ) );
}


static void Recompile::PSUBSH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PSUBSH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	//cout << "\nhps2x64: ERROR: R5900: Instruction not implemented: PSUBSH";
	
	s32 sResult32;
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sh0 ) - ( (s32) r->GPR [ i.Rt ].sh0 );
	r->GPR [ i.Rd ].sh0 = ( ( sResult32 > 0x7fff ) ? 0x7fff : ( ( sResult32 < -0x8000 ) ? -0x8000 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sh1 ) - ( (s32) r->GPR [ i.Rt ].sh1 );
	r->GPR [ i.Rd ].sh1 = ( ( sResult32 > 0x7fff ) ? 0x7fff : ( ( sResult32 < -0x8000 ) ? -0x8000 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sh2 ) - ( (s32) r->GPR [ i.Rt ].sh2 );
	r->GPR [ i.Rd ].sh2 = ( ( sResult32 > 0x7fff ) ? 0x7fff : ( ( sResult32 < -0x8000 ) ? -0x8000 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sh3 ) - ( (s32) r->GPR [ i.Rt ].sh3 );
	r->GPR [ i.Rd ].sh3 = ( ( sResult32 > 0x7fff ) ? 0x7fff : ( ( sResult32 < -0x8000 ) ? -0x8000 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sh4 ) - ( (s32) r->GPR [ i.Rt ].sh4 );
	r->GPR [ i.Rd ].sh4 = ( ( sResult32 > 0x7fff ) ? 0x7fff : ( ( sResult32 < -0x8000 ) ? -0x8000 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sh5 ) - ( (s32) r->GPR [ i.Rt ].sh5 );
	r->GPR [ i.Rd ].sh5 = ( ( sResult32 > 0x7fff ) ? 0x7fff : ( ( sResult32 < -0x8000 ) ? -0x8000 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sh6 ) - ( (s32) r->GPR [ i.Rt ].sh6 );
	r->GPR [ i.Rd ].sh6 = ( ( sResult32 > 0x7fff ) ? 0x7fff : ( ( sResult32 < -0x8000 ) ? -0x8000 : sResult32 ) );
	
	sResult32 = ( (s32) r->GPR [ i.Rs ].sh7 ) - ( (s32) r->GPR [ i.Rt ].sh7 );
	r->GPR [ i.Rd ].sh7 = ( ( sResult32 > 0x7fff ) ? 0x7fff : ( ( sResult32 < -0x8000 ) ? -0x8000 : sResult32 ) );
}


static void Recompile::PSUBSW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PSUBSW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	//cout << "\nhps2x64: ERROR: R5900: Instruction not implemented: PSUBSW";
	
	s64 sResult64;
	
	sResult64 = ( (s64) r->GPR [ i.Rs ].sw0 ) - ( (s64) r->GPR [ i.Rt ].sw0 );
	r->GPR [ i.Rd ].sw0 = ( ( sResult64 > 0x7fffffffLL ) ? 0x7fffffff : ( ( sResult64 < -0x80000000LL ) ? -0x80000000 : sResult64 ) );
	
	sResult64 = ( (s64) r->GPR [ i.Rs ].sw1 ) - ( (s64) r->GPR [ i.Rt ].sw1 );
	r->GPR [ i.Rd ].sw1 = ( ( sResult64 > 0x7fffffffLL ) ? 0x7fffffff : ( ( sResult64 < -0x80000000LL ) ? -0x80000000 : sResult64 ) );
	
	sResult64 = ( (s64) r->GPR [ i.Rs ].sw2 ) - ( (s64) r->GPR [ i.Rt ].sw2 );
	r->GPR [ i.Rd ].sw2 = ( ( sResult64 > 0x7fffffffLL ) ? 0x7fffffff : ( ( sResult64 < -0x80000000LL ) ? -0x80000000 : sResult64 ) );
	
	sResult64 = ( (s64) r->GPR [ i.Rs ].sw3 ) - ( (s64) r->GPR [ i.Rt ].sw3 );
	r->GPR [ i.Rd ].sw3 = ( ( sResult64 > 0x7fffffffLL ) ? 0x7fffffff : ( ( sResult64 < -0x80000000LL ) ? -0x80000000 : sResult64 ) );
}


static void Recompile::PADDUB ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PADDUB || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].ub0 = ( ( ( (u64) r->GPR [ i.Rs ].ub0 ) + ( (u64) r->GPR [ i.Rt ].ub0 ) ) > 0xffULL ? 0xff : ( r->GPR [ i.Rs ].ub0 + r->GPR [ i.Rt ].ub0 ) );
	r->GPR [ i.Rd ].ub1 = ( ( ( (u64) r->GPR [ i.Rs ].ub1 ) + ( (u64) r->GPR [ i.Rt ].ub1 ) ) > 0xffULL ? 0xff : ( r->GPR [ i.Rs ].ub1 + r->GPR [ i.Rt ].ub1 ) );
	r->GPR [ i.Rd ].ub2 = ( ( ( (u64) r->GPR [ i.Rs ].ub2 ) + ( (u64) r->GPR [ i.Rt ].ub2 ) ) > 0xffULL ? 0xff : ( r->GPR [ i.Rs ].ub2 + r->GPR [ i.Rt ].ub2 ) );
	r->GPR [ i.Rd ].ub3 = ( ( ( (u64) r->GPR [ i.Rs ].ub3 ) + ( (u64) r->GPR [ i.Rt ].ub3 ) ) > 0xffULL ? 0xff : ( r->GPR [ i.Rs ].ub3 + r->GPR [ i.Rt ].ub3 ) );
	r->GPR [ i.Rd ].ub4 = ( ( ( (u64) r->GPR [ i.Rs ].ub4 ) + ( (u64) r->GPR [ i.Rt ].ub4 ) ) > 0xffULL ? 0xff : ( r->GPR [ i.Rs ].ub4 + r->GPR [ i.Rt ].ub4 ) );
	r->GPR [ i.Rd ].ub5 = ( ( ( (u64) r->GPR [ i.Rs ].ub5 ) + ( (u64) r->GPR [ i.Rt ].ub5 ) ) > 0xffULL ? 0xff : ( r->GPR [ i.Rs ].ub5 + r->GPR [ i.Rt ].ub5 ) );
	r->GPR [ i.Rd ].ub6 = ( ( ( (u64) r->GPR [ i.Rs ].ub6 ) + ( (u64) r->GPR [ i.Rt ].ub6 ) ) > 0xffULL ? 0xff : ( r->GPR [ i.Rs ].ub6 + r->GPR [ i.Rt ].ub6 ) );
	r->GPR [ i.Rd ].ub7 = ( ( ( (u64) r->GPR [ i.Rs ].ub7 ) + ( (u64) r->GPR [ i.Rt ].ub7 ) ) > 0xffULL ? 0xff : ( r->GPR [ i.Rs ].ub7 + r->GPR [ i.Rt ].ub7 ) );
	r->GPR [ i.Rd ].ub8 = ( ( ( (u64) r->GPR [ i.Rs ].ub8 ) + ( (u64) r->GPR [ i.Rt ].ub8 ) ) > 0xffULL ? 0xff : ( r->GPR [ i.Rs ].ub8 + r->GPR [ i.Rt ].ub8 ) );
	r->GPR [ i.Rd ].ub9 = ( ( ( (u64) r->GPR [ i.Rs ].ub9 ) + ( (u64) r->GPR [ i.Rt ].ub9 ) ) > 0xffULL ? 0xff : ( r->GPR [ i.Rs ].ub9 + r->GPR [ i.Rt ].ub9 ) );
	r->GPR [ i.Rd ].ub10 = ( ( ( (u64) r->GPR [ i.Rs ].ub10 ) + ( (u64) r->GPR [ i.Rt ].ub10 ) ) > 0xffULL ? 0xff : ( r->GPR [ i.Rs ].ub10 + r->GPR [ i.Rt ].ub10 ) );
	r->GPR [ i.Rd ].ub11 = ( ( ( (u64) r->GPR [ i.Rs ].ub11 ) + ( (u64) r->GPR [ i.Rt ].ub11 ) ) > 0xffULL ? 0xff : ( r->GPR [ i.Rs ].ub11 + r->GPR [ i.Rt ].ub11 ) );
	r->GPR [ i.Rd ].ub12 = ( ( ( (u64) r->GPR [ i.Rs ].ub12 ) + ( (u64) r->GPR [ i.Rt ].ub12 ) ) > 0xffULL ? 0xff : ( r->GPR [ i.Rs ].ub12 + r->GPR [ i.Rt ].ub12 ) );
	r->GPR [ i.Rd ].ub13 = ( ( ( (u64) r->GPR [ i.Rs ].ub13 ) + ( (u64) r->GPR [ i.Rt ].ub13 ) ) > 0xffULL ? 0xff : ( r->GPR [ i.Rs ].ub13 + r->GPR [ i.Rt ].ub13 ) );
	r->GPR [ i.Rd ].ub14 = ( ( ( (u64) r->GPR [ i.Rs ].ub14 ) + ( (u64) r->GPR [ i.Rt ].ub14 ) ) > 0xffULL ? 0xff : ( r->GPR [ i.Rs ].ub14 + r->GPR [ i.Rt ].ub14 ) );
	r->GPR [ i.Rd ].ub15 = ( ( ( (u64) r->GPR [ i.Rs ].ub15 ) + ( (u64) r->GPR [ i.Rt ].ub15 ) ) > 0xffULL ? 0xff : ( r->GPR [ i.Rs ].ub15 + r->GPR [ i.Rt ].ub15 ) );
	
#if defined INLINE_DEBUG_PADDUB || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PADDUH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PADDUH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].uh0 = ( ( ( (u64) r->GPR [ i.Rs ].uh0 ) + ( (u64) r->GPR [ i.Rt ].uh0 ) ) > 0xffffULL ? 0xffff : ( r->GPR [ i.Rs ].uh0 + r->GPR [ i.Rt ].uh0 ) );
	r->GPR [ i.Rd ].uh1 = ( ( ( (u64) r->GPR [ i.Rs ].uh1 ) + ( (u64) r->GPR [ i.Rt ].uh1 ) ) > 0xffffULL ? 0xffff : ( r->GPR [ i.Rs ].uh1 + r->GPR [ i.Rt ].uh1 ) );
	r->GPR [ i.Rd ].uh2 = ( ( ( (u64) r->GPR [ i.Rs ].uh2 ) + ( (u64) r->GPR [ i.Rt ].uh2 ) ) > 0xffffULL ? 0xffff : ( r->GPR [ i.Rs ].uh2 + r->GPR [ i.Rt ].uh2 ) );
	r->GPR [ i.Rd ].uh3 = ( ( ( (u64) r->GPR [ i.Rs ].uh3 ) + ( (u64) r->GPR [ i.Rt ].uh3 ) ) > 0xffffULL ? 0xffff : ( r->GPR [ i.Rs ].uh3 + r->GPR [ i.Rt ].uh3 ) );
	r->GPR [ i.Rd ].uh4 = ( ( ( (u64) r->GPR [ i.Rs ].uh4 ) + ( (u64) r->GPR [ i.Rt ].uh4 ) ) > 0xffffULL ? 0xffff : ( r->GPR [ i.Rs ].uh4 + r->GPR [ i.Rt ].uh4 ) );
	r->GPR [ i.Rd ].uh5 = ( ( ( (u64) r->GPR [ i.Rs ].uh5 ) + ( (u64) r->GPR [ i.Rt ].uh5 ) ) > 0xffffULL ? 0xffff : ( r->GPR [ i.Rs ].uh5 + r->GPR [ i.Rt ].uh5 ) );
	r->GPR [ i.Rd ].uh6 = ( ( ( (u64) r->GPR [ i.Rs ].uh6 ) + ( (u64) r->GPR [ i.Rt ].uh6 ) ) > 0xffffULL ? 0xffff : ( r->GPR [ i.Rs ].uh6 + r->GPR [ i.Rt ].uh6 ) );
	r->GPR [ i.Rd ].uh7 = ( ( ( (u64) r->GPR [ i.Rs ].uh7 ) + ( (u64) r->GPR [ i.Rt ].uh7 ) ) > 0xffffULL ? 0xffff : ( r->GPR [ i.Rs ].uh7 + r->GPR [ i.Rt ].uh7 ) );
	
#if defined INLINE_DEBUG_PADDUH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PADDUW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PADDUW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	// rd = rs + rt
	r->GPR [ i.Rd ].uw0 = ( ( ( (u64) r->GPR [ i.Rs ].uw0 ) + ( (u64) r->GPR [ i.Rt ].uw0 ) ) > 0xffffffffULL ? 0xffffffff : ( r->GPR [ i.Rs ].uw0 + r->GPR [ i.Rt ].uw0 ) );
	r->GPR [ i.Rd ].uw1 = ( ( ( (u64) r->GPR [ i.Rs ].uw1 ) + ( (u64) r->GPR [ i.Rt ].uw1 ) ) > 0xffffffffULL ? 0xffffffff : ( r->GPR [ i.Rs ].uw1 + r->GPR [ i.Rt ].uw1 ) );
	r->GPR [ i.Rd ].uw2 = ( ( ( (u64) r->GPR [ i.Rs ].uw2 ) + ( (u64) r->GPR [ i.Rt ].uw2 ) ) > 0xffffffffULL ? 0xffffffff : ( r->GPR [ i.Rs ].uw2 + r->GPR [ i.Rt ].uw2 ) );
	r->GPR [ i.Rd ].uw3 = ( ( ( (u64) r->GPR [ i.Rs ].uw3 ) + ( (u64) r->GPR [ i.Rt ].uw3 ) ) > 0xffffffffULL ? 0xffffffff : ( r->GPR [ i.Rs ].uw3 + r->GPR [ i.Rt ].uw3 ) );
	
#if defined INLINE_DEBUG_PADDUW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}


static void Recompile::PSUBUB ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PSUBUB || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	//cout << "\nhps2x64: ERROR: R5900: Instruction not implemented: PSUBUB";
	
	u32 uResult32;
	
	uResult32 = ( (u32) r->GPR [ i.Rs ].ub0 ) - ( (u32) r->GPR [ i.Rt ].ub0 );
	r->GPR [ i.Rd ].ub0 = ( ( (s32) uResult32 ) < 0 ) ? 0 : uResult32;
	
	uResult32 = ( (u32) r->GPR [ i.Rs ].ub1 ) - ( (u32) r->GPR [ i.Rt ].ub1 );
	r->GPR [ i.Rd ].ub1 = ( ( (s32) uResult32 ) < 0 ) ? 0 : uResult32;
	
	uResult32 = ( (u32) r->GPR [ i.Rs ].ub2 ) - ( (u32) r->GPR [ i.Rt ].ub2 );
	r->GPR [ i.Rd ].ub2 = ( ( (s32) uResult32 ) < 0 ) ? 0 : uResult32;
	
	uResult32 = ( (u32) r->GPR [ i.Rs ].ub3 ) - ( (u32) r->GPR [ i.Rt ].ub3 );
	r->GPR [ i.Rd ].ub3 = ( ( (s32) uResult32 ) < 0 ) ? 0 : uResult32;
	
	uResult32 = ( (u32) r->GPR [ i.Rs ].ub4 ) - ( (u32) r->GPR [ i.Rt ].ub4 );
	r->GPR [ i.Rd ].ub4 = ( ( (s32) uResult32 ) < 0 ) ? 0 : uResult32;
	
	uResult32 = ( (u32) r->GPR [ i.Rs ].ub5 ) - ( (u32) r->GPR [ i.Rt ].ub5 );
	r->GPR [ i.Rd ].ub5 = ( ( (s32) uResult32 ) < 0 ) ? 0 : uResult32;
	
	uResult32 = ( (u32) r->GPR [ i.Rs ].ub6 ) - ( (u32) r->GPR [ i.Rt ].ub6 );
	r->GPR [ i.Rd ].ub6 = ( ( (s32) uResult32 ) < 0 ) ? 0 : uResult32;
	
	uResult32 = ( (u32) r->GPR [ i.Rs ].ub7 ) - ( (u32) r->GPR [ i.Rt ].ub7 );
	r->GPR [ i.Rd ].ub7 = ( ( (s32) uResult32 ) < 0 ) ? 0 : uResult32;
	
	uResult32 = ( (u32) r->GPR [ i.Rs ].ub8 ) - ( (u32) r->GPR [ i.Rt ].ub8 );
	r->GPR [ i.Rd ].ub8 = ( ( (s32) uResult32 ) < 0 ) ? 0 : uResult32;
	
	uResult32 = ( (u32) r->GPR [ i.Rs ].ub9 ) - ( (u32) r->GPR [ i.Rt ].ub9 );
	r->GPR [ i.Rd ].ub9 = ( ( (s32) uResult32 ) < 0 ) ? 0 : uResult32;
	
	uResult32 = ( (u32) r->GPR [ i.Rs ].ub10 ) - ( (u32) r->GPR [ i.Rt ].ub10 );
	r->GPR [ i.Rd ].ub10 = ( ( (s32) uResult32 ) < 0 ) ? 0 : uResult32;
	
	uResult32 = ( (u32) r->GPR [ i.Rs ].ub11 ) - ( (u32) r->GPR [ i.Rt ].ub11 );
	r->GPR [ i.Rd ].ub11 = ( ( (s32) uResult32 ) < 0 ) ? 0 : uResult32;
	
	uResult32 = ( (u32) r->GPR [ i.Rs ].ub12 ) - ( (u32) r->GPR [ i.Rt ].ub12 );
	r->GPR [ i.Rd ].ub12 = ( ( (s32) uResult32 ) < 0 ) ? 0 : uResult32;
	
	uResult32 = ( (u32) r->GPR [ i.Rs ].ub13 ) - ( (u32) r->GPR [ i.Rt ].ub13 );
	r->GPR [ i.Rd ].ub13 = ( ( (s32) uResult32 ) < 0 ) ? 0 : uResult32;
	
	uResult32 = ( (u32) r->GPR [ i.Rs ].ub14 ) - ( (u32) r->GPR [ i.Rt ].ub14 );
	r->GPR [ i.Rd ].ub14 = ( ( (s32) uResult32 ) < 0 ) ? 0 : uResult32;
	
	uResult32 = ( (u32) r->GPR [ i.Rs ].ub15 ) - ( (u32) r->GPR [ i.Rt ].ub15 );
	r->GPR [ i.Rd ].ub15 = ( ( (s32) uResult32 ) < 0 ) ? 0 : uResult32;

}

static void Recompile::PSUBUH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PSUBUH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	//cout << "\nhps2x64: ERROR: R5900: Instruction not implemented: PSUBUH";
	
	u32 uResult32;
	
	uResult32 = ( (u32) r->GPR [ i.Rs ].uh0 ) - ( (u32) r->GPR [ i.Rt ].uh0 );
	r->GPR [ i.Rd ].uh0 = ( ( (s32) uResult32 ) < 0 ) ? 0 : uResult32;
	
	uResult32 = ( (u32) r->GPR [ i.Rs ].uh1 ) - ( (u32) r->GPR [ i.Rt ].uh1 );
	r->GPR [ i.Rd ].uh1 = ( ( (s32) uResult32 ) < 0 ) ? 0 : uResult32;
	
	uResult32 = ( (u32) r->GPR [ i.Rs ].uh2 ) - ( (u32) r->GPR [ i.Rt ].uh2 );
	r->GPR [ i.Rd ].uh2 = ( ( (s32) uResult32 ) < 0 ) ? 0 : uResult32;
	
	uResult32 = ( (u32) r->GPR [ i.Rs ].uh3 ) - ( (u32) r->GPR [ i.Rt ].uh3 );
	r->GPR [ i.Rd ].uh3 = ( ( (s32) uResult32 ) < 0 ) ? 0 : uResult32;
	
	uResult32 = ( (u32) r->GPR [ i.Rs ].uh4 ) - ( (u32) r->GPR [ i.Rt ].uh4 );
	r->GPR [ i.Rd ].uh4 = ( ( (s32) uResult32 ) < 0 ) ? 0 : uResult32;
	
	uResult32 = ( (u32) r->GPR [ i.Rs ].uh5 ) - ( (u32) r->GPR [ i.Rt ].uh5 );
	r->GPR [ i.Rd ].uh5 = ( ( (s32) uResult32 ) < 0 ) ? 0 : uResult32;
	
	uResult32 = ( (u32) r->GPR [ i.Rs ].uh6 ) - ( (u32) r->GPR [ i.Rt ].uh6 );
	r->GPR [ i.Rd ].uh6 = ( ( (s32) uResult32 ) < 0 ) ? 0 : uResult32;
	
	uResult32 = ( (u32) r->GPR [ i.Rs ].uh7 ) - ( (u32) r->GPR [ i.Rt ].uh7 );
	r->GPR [ i.Rd ].uh7 = ( ( (s32) uResult32 ) < 0 ) ? 0 : uResult32;
}

static void Recompile::PSUBUW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PSUBUW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	//cout << "\nhps2x64: ERROR: R5900: Instruction not implemented: PSUBUW";
	
	u64 uResult64;
	
	uResult64 = ( (u64) r->GPR [ i.Rs ].uw0 ) - ( (u64) r->GPR [ i.Rt ].uw0 );
	r->GPR [ i.Rd ].uw0 = ( ( (s64) uResult64 ) < 0 ) ? 0 : uResult64;
	
	uResult64 = ( (u64) r->GPR [ i.Rs ].uw1 ) - ( (u64) r->GPR [ i.Rt ].uw1 );
	r->GPR [ i.Rd ].uw1 = ( ( (s64) uResult64 ) < 0 ) ? 0 : uResult64;
	
	uResult64 = ( (u64) r->GPR [ i.Rs ].uw2 ) - ( (u64) r->GPR [ i.Rt ].uw2 );
	r->GPR [ i.Rd ].uw2 = ( ( (s64) uResult64 ) < 0 ) ? 0 : uResult64;
	
	uResult64 = ( (u64) r->GPR [ i.Rs ].uw3 ) - ( (u64) r->GPR [ i.Rt ].uw3 );
	r->GPR [ i.Rd ].uw3 = ( ( (s64) uResult64 ) < 0 ) ? 0 : uResult64;
}



static void Recompile::PMAXH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PMAXH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].sh0 = ( r->GPR [ i.Rs ].sh0 > r->GPR [ i.Rt ].sh0 ) ? r->GPR [ i.Rs ].sh0 : r->GPR [ i.Rt ].sh0;
	r->GPR [ i.Rd ].sh1 = ( r->GPR [ i.Rs ].sh1 > r->GPR [ i.Rt ].sh1 ) ? r->GPR [ i.Rs ].sh1 : r->GPR [ i.Rt ].sh1;
	r->GPR [ i.Rd ].sh2 = ( r->GPR [ i.Rs ].sh2 > r->GPR [ i.Rt ].sh2 ) ? r->GPR [ i.Rs ].sh2 : r->GPR [ i.Rt ].sh2;
	r->GPR [ i.Rd ].sh3 = ( r->GPR [ i.Rs ].sh3 > r->GPR [ i.Rt ].sh3 ) ? r->GPR [ i.Rs ].sh3 : r->GPR [ i.Rt ].sh3;
	r->GPR [ i.Rd ].sh4 = ( r->GPR [ i.Rs ].sh4 > r->GPR [ i.Rt ].sh4 ) ? r->GPR [ i.Rs ].sh4 : r->GPR [ i.Rt ].sh4;
	r->GPR [ i.Rd ].sh5 = ( r->GPR [ i.Rs ].sh5 > r->GPR [ i.Rt ].sh5 ) ? r->GPR [ i.Rs ].sh5 : r->GPR [ i.Rt ].sh5;
	r->GPR [ i.Rd ].sh6 = ( r->GPR [ i.Rs ].sh6 > r->GPR [ i.Rt ].sh6 ) ? r->GPR [ i.Rs ].sh6 : r->GPR [ i.Rt ].sh6;
	r->GPR [ i.Rd ].sh7 = ( r->GPR [ i.Rs ].sh7 > r->GPR [ i.Rt ].sh7 ) ? r->GPR [ i.Rs ].sh7 : r->GPR [ i.Rt ].sh7;
	
#if defined INLINE_DEBUG_PMAXH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PMAXW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PMAXW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].sw0 = ( r->GPR [ i.Rs ].sw0 > r->GPR [ i.Rt ].sw0 ) ? r->GPR [ i.Rs ].sw0 : r->GPR [ i.Rt ].sw0;
	r->GPR [ i.Rd ].sw1 = ( r->GPR [ i.Rs ].sw1 > r->GPR [ i.Rt ].sw1 ) ? r->GPR [ i.Rs ].sw1 : r->GPR [ i.Rt ].sw1;
	r->GPR [ i.Rd ].sw2 = ( r->GPR [ i.Rs ].sw2 > r->GPR [ i.Rt ].sw2 ) ? r->GPR [ i.Rs ].sw2 : r->GPR [ i.Rt ].sw2;
	r->GPR [ i.Rd ].sw3 = ( r->GPR [ i.Rs ].sw3 > r->GPR [ i.Rt ].sw3 ) ? r->GPR [ i.Rs ].sw3 : r->GPR [ i.Rt ].sw3;
	
#if defined INLINE_DEBUG_PMAXW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PMINH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PMINH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].sh0 = ( r->GPR [ i.Rs ].sh0 < r->GPR [ i.Rt ].sh0 ) ? r->GPR [ i.Rs ].sh0 : r->GPR [ i.Rt ].sh0;
	r->GPR [ i.Rd ].sh1 = ( r->GPR [ i.Rs ].sh1 < r->GPR [ i.Rt ].sh1 ) ? r->GPR [ i.Rs ].sh1 : r->GPR [ i.Rt ].sh1;
	r->GPR [ i.Rd ].sh2 = ( r->GPR [ i.Rs ].sh2 < r->GPR [ i.Rt ].sh2 ) ? r->GPR [ i.Rs ].sh2 : r->GPR [ i.Rt ].sh2;
	r->GPR [ i.Rd ].sh3 = ( r->GPR [ i.Rs ].sh3 < r->GPR [ i.Rt ].sh3 ) ? r->GPR [ i.Rs ].sh3 : r->GPR [ i.Rt ].sh3;
	r->GPR [ i.Rd ].sh4 = ( r->GPR [ i.Rs ].sh4 < r->GPR [ i.Rt ].sh4 ) ? r->GPR [ i.Rs ].sh4 : r->GPR [ i.Rt ].sh4;
	r->GPR [ i.Rd ].sh5 = ( r->GPR [ i.Rs ].sh5 < r->GPR [ i.Rt ].sh5 ) ? r->GPR [ i.Rs ].sh5 : r->GPR [ i.Rt ].sh5;
	r->GPR [ i.Rd ].sh6 = ( r->GPR [ i.Rs ].sh6 < r->GPR [ i.Rt ].sh6 ) ? r->GPR [ i.Rs ].sh6 : r->GPR [ i.Rt ].sh6;
	r->GPR [ i.Rd ].sh7 = ( r->GPR [ i.Rs ].sh7 < r->GPR [ i.Rt ].sh7 ) ? r->GPR [ i.Rs ].sh7 : r->GPR [ i.Rt ].sh7;
	
#if defined INLINE_DEBUG_PMINH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PMINW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PMINW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].sw0 = ( r->GPR [ i.Rs ].sw0 < r->GPR [ i.Rt ].sw0 ) ? r->GPR [ i.Rs ].sw0 : r->GPR [ i.Rt ].sw0;
	r->GPR [ i.Rd ].sw1 = ( r->GPR [ i.Rs ].sw1 < r->GPR [ i.Rt ].sw1 ) ? r->GPR [ i.Rs ].sw1 : r->GPR [ i.Rt ].sw1;
	r->GPR [ i.Rd ].sw2 = ( r->GPR [ i.Rs ].sw2 < r->GPR [ i.Rt ].sw2 ) ? r->GPR [ i.Rs ].sw2 : r->GPR [ i.Rt ].sw2;
	r->GPR [ i.Rd ].sw3 = ( r->GPR [ i.Rs ].sw3 < r->GPR [ i.Rt ].sw3 ) ? r->GPR [ i.Rs ].sw3 : r->GPR [ i.Rt ].sw3;
	
#if defined INLINE_DEBUG_PMINW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}




static void Recompile::PPACB ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PPACB || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	// note: must use this order
	r->GPR [ i.Rd ].ub1 = r->GPR [ i.Rt ].ub2;
	r->GPR [ i.Rd ].ub3 = r->GPR [ i.Rt ].ub6;
	r->GPR [ i.Rd ].ub5 = r->GPR [ i.Rt ].ub10;
	r->GPR [ i.Rd ].ub7 = r->GPR [ i.Rt ].ub14;
	r->GPR [ i.Rd ].ub9 = r->GPR [ i.Rs ].ub2;
	r->GPR [ i.Rd ].ub11 = r->GPR [ i.Rs ].ub6;
	r->GPR [ i.Rd ].ub13 = r->GPR [ i.Rs ].ub10;
	r->GPR [ i.Rd ].ub15 = r->GPR [ i.Rs ].ub14;
	
	r->GPR [ i.Rd ].ub2 = r->GPR [ i.Rt ].ub4;
	r->GPR [ i.Rd ].ub6 = r->GPR [ i.Rt ].ub12;
	r->GPR [ i.Rd ].ub10 = r->GPR [ i.Rs ].ub4;
	r->GPR [ i.Rd ].ub14 = r->GPR [ i.Rs ].ub12;
	
	r->GPR [ i.Rd ].ub12 = r->GPR [ i.Rs ].ub8;
	r->GPR [ i.Rd ].ub4 = r->GPR [ i.Rt ].ub8;
	r->GPR [ i.Rd ].ub8 = r->GPR [ i.Rs ].ub0;
	r->GPR [ i.Rd ].ub0 = r->GPR [ i.Rt ].ub0;
	
	
#if defined INLINE_DEBUG_PPACB || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PPACH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PPACH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	// note: must use this order
	
	// write into odd indexes first
	r->GPR [ i.Rd ].uh1 = r->GPR [ i.Rt ].uh2;
	r->GPR [ i.Rd ].uh3 = r->GPR [ i.Rt ].uh6;
	r->GPR [ i.Rd ].uh5 = r->GPR [ i.Rs ].uh2;
	r->GPR [ i.Rd ].uh7 = r->GPR [ i.Rs ].uh6;
	
	// h2 and h6 have both been written from both rs and rt
	r->GPR [ i.Rd ].uh2 = r->GPR [ i.Rt ].uh4;
	r->GPR [ i.Rd ].uh6 = r->GPR [ i.Rs ].uh4;
	
	// can only store into h0 LAST
	r->GPR [ i.Rd ].uh4 = r->GPR [ i.Rs ].uh0;
	r->GPR [ i.Rd ].uh0 = r->GPR [ i.Rt ].uh0;
	
#if defined INLINE_DEBUG_PPACH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PPACW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PPACW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	// note: must use this order
	
	// write into odd indexes first
	r->GPR [ i.Rd ].uw1 = r->GPR [ i.Rt ].uw2;
	r->GPR [ i.Rd ].uw3 = r->GPR [ i.Rs ].uw2;
	
	// can only store into h0 LAST
	r->GPR [ i.Rd ].uw2 = r->GPR [ i.Rs ].uw0;
	r->GPR [ i.Rd ].uw0 = r->GPR [ i.Rt ].uw0;
	
#if defined INLINE_DEBUG_PPACW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}


static void Recompile::PEXT5 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PEXT5 || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].uq0 = ( ( r->GPR [ i.Rt ].uq0 & 0x1f0000001fULL ) << 3 ) | ( ( r->GPR [ i.Rt ].uq0 & 0x3e0000003e0ULL ) << 6 ) | ( ( r->GPR [ i.Rt ].uq0 & 0x7c0000007c00ULL ) << 9 ) | ( ( r->GPR [ i.Rt ].uq0 & 0x800000008000ULL ) << 16 );
	r->GPR [ i.Rd ].uq1 = ( ( r->GPR [ i.Rt ].uq1 & 0x1f0000001fULL ) << 3 ) | ( ( r->GPR [ i.Rt ].uq1 & 0x3e0000003e0ULL ) << 6 ) | ( ( r->GPR [ i.Rt ].uq1 & 0x7c0000007c00ULL ) << 9 ) | ( ( r->GPR [ i.Rt ].uq1 & 0x800000008000ULL ) << 16 );
	
#if defined INLINE_DEBUG_PEXT5 || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PPAC5 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PPAC5 || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	u64 temp;
	temp = ( ( r->GPR [ i.Rt ].uq0 & 0xf8000000f8ULL ) >> 3 ) | ( ( r->GPR [ i.Rt ].uq0 & 0xf8000000f800ULL ) >> 6 ) | ( ( r->GPR [ i.Rt ].uq0 & 0xf8000000f80000ULL ) >> 9 ) | ( ( r->GPR [ i.Rt ].uq0 & 0x8000000080000000ULL ) >> 16 );
	r->GPR [ i.Rd ].uh0 = (u16) temp;
	r->GPR [ i.Rd ].uh2 = (u16) ( temp >> 32 );
	temp = ( ( r->GPR [ i.Rt ].uq1 & 0xf8000000f8ULL ) >> 3 ) | ( ( r->GPR [ i.Rt ].uq1 & 0xf8000000f800ULL ) >> 6 ) | ( ( r->GPR [ i.Rt ].uq1 & 0xf8000000f80000ULL ) >> 9 ) | ( ( r->GPR [ i.Rt ].uq1 & 0x8000000080000000ULL ) >> 16 );
	r->GPR [ i.Rd ].uh4 = (u16) temp;
	r->GPR [ i.Rd ].uh6 = (u16) ( temp >> 32 );
	
	// the halfwords 1,3,5,7 are set to zero
	r->GPR [ i.Rd ].uh1 = 0;
	r->GPR [ i.Rd ].uh3 = 0;
	r->GPR [ i.Rd ].uh5 = 0;
	r->GPR [ i.Rd ].uh7 = 0;
	
#if defined INLINE_DEBUG_PPAC5 || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}


static void Recompile::PCGTB ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PCGTB || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].sb0 = ( r->GPR [ i.Rs ].sb0 > r->GPR [ i.Rt ].sb0 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb1 = ( r->GPR [ i.Rs ].sb1 > r->GPR [ i.Rt ].sb1 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb2 = ( r->GPR [ i.Rs ].sb2 > r->GPR [ i.Rt ].sb2 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb3 = ( r->GPR [ i.Rs ].sb3 > r->GPR [ i.Rt ].sb3 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb4 = ( r->GPR [ i.Rs ].sb4 > r->GPR [ i.Rt ].sb4 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb5 = ( r->GPR [ i.Rs ].sb5 > r->GPR [ i.Rt ].sb5 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb6 = ( r->GPR [ i.Rs ].sb6 > r->GPR [ i.Rt ].sb6 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb7 = ( r->GPR [ i.Rs ].sb7 > r->GPR [ i.Rt ].sb7 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb8 = ( r->GPR [ i.Rs ].sb8 > r->GPR [ i.Rt ].sb8 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb9 = ( r->GPR [ i.Rs ].sb9 > r->GPR [ i.Rt ].sb9 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb10 = ( r->GPR [ i.Rs ].sb10 > r->GPR [ i.Rt ].sb10 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb11 = ( r->GPR [ i.Rs ].sb11 > r->GPR [ i.Rt ].sb11 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb12 = ( r->GPR [ i.Rs ].sb12 > r->GPR [ i.Rt ].sb12 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb13 = ( r->GPR [ i.Rs ].sb13 > r->GPR [ i.Rt ].sb13 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb14 = ( r->GPR [ i.Rs ].sb14 > r->GPR [ i.Rt ].sb14 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb15 = ( r->GPR [ i.Rs ].sb15 > r->GPR [ i.Rt ].sb15 ) ? 0xff : 0;
	
#if defined INLINE_DEBUG_PCGTB || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PCGTH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PCGTH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].sh0 = ( r->GPR [ i.Rs ].sh0 > r->GPR [ i.Rt ].sh0 ) ? 0xffff : 0;
	r->GPR [ i.Rd ].sh1 = ( r->GPR [ i.Rs ].sh1 > r->GPR [ i.Rt ].sh1 ) ? 0xffff : 0;
	r->GPR [ i.Rd ].sh2 = ( r->GPR [ i.Rs ].sh2 > r->GPR [ i.Rt ].sh2 ) ? 0xffff : 0;
	r->GPR [ i.Rd ].sh3 = ( r->GPR [ i.Rs ].sh3 > r->GPR [ i.Rt ].sh3 ) ? 0xffff : 0;
	r->GPR [ i.Rd ].sh4 = ( r->GPR [ i.Rs ].sh4 > r->GPR [ i.Rt ].sh4 ) ? 0xffff : 0;
	r->GPR [ i.Rd ].sh5 = ( r->GPR [ i.Rs ].sh5 > r->GPR [ i.Rt ].sh5 ) ? 0xffff : 0;
	r->GPR [ i.Rd ].sh6 = ( r->GPR [ i.Rs ].sh6 > r->GPR [ i.Rt ].sh6 ) ? 0xffff : 0;
	r->GPR [ i.Rd ].sh7 = ( r->GPR [ i.Rs ].sh7 > r->GPR [ i.Rt ].sh7 ) ? 0xffff : 0;
	
#if defined INLINE_DEBUG_PCGTH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PCGTW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PCGTW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].sw0 = ( r->GPR [ i.Rs ].sw0 > r->GPR [ i.Rt ].sw0 ) ? 0xffffffff : 0;
	r->GPR [ i.Rd ].sw1 = ( r->GPR [ i.Rs ].sw1 > r->GPR [ i.Rt ].sw1 ) ? 0xffffffff : 0;
	r->GPR [ i.Rd ].sw2 = ( r->GPR [ i.Rs ].sw2 > r->GPR [ i.Rt ].sw2 ) ? 0xffffffff : 0;
	r->GPR [ i.Rd ].sw3 = ( r->GPR [ i.Rs ].sw3 > r->GPR [ i.Rt ].sw3 ) ? 0xffffffff : 0;
	
#if defined INLINE_DEBUG_PCGTW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}


static void Recompile::PCEQB ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PCEQB || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].sb0 = ( r->GPR [ i.Rs ].sb0 == r->GPR [ i.Rt ].sb0 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb1 = ( r->GPR [ i.Rs ].sb1 == r->GPR [ i.Rt ].sb1 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb2 = ( r->GPR [ i.Rs ].sb2 == r->GPR [ i.Rt ].sb2 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb3 = ( r->GPR [ i.Rs ].sb3 == r->GPR [ i.Rt ].sb3 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb4 = ( r->GPR [ i.Rs ].sb4 == r->GPR [ i.Rt ].sb4 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb5 = ( r->GPR [ i.Rs ].sb5 == r->GPR [ i.Rt ].sb5 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb6 = ( r->GPR [ i.Rs ].sb6 == r->GPR [ i.Rt ].sb6 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb7 = ( r->GPR [ i.Rs ].sb7 == r->GPR [ i.Rt ].sb7 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb8 = ( r->GPR [ i.Rs ].sb8 == r->GPR [ i.Rt ].sb8 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb9 = ( r->GPR [ i.Rs ].sb9 == r->GPR [ i.Rt ].sb9 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb10 = ( r->GPR [ i.Rs ].sb10 == r->GPR [ i.Rt ].sb10 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb11 = ( r->GPR [ i.Rs ].sb11 == r->GPR [ i.Rt ].sb11 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb12 = ( r->GPR [ i.Rs ].sb12 == r->GPR [ i.Rt ].sb12 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb13 = ( r->GPR [ i.Rs ].sb13 == r->GPR [ i.Rt ].sb13 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb14 = ( r->GPR [ i.Rs ].sb14 == r->GPR [ i.Rt ].sb14 ) ? 0xff : 0;
	r->GPR [ i.Rd ].sb15 = ( r->GPR [ i.Rs ].sb15 == r->GPR [ i.Rt ].sb15 ) ? 0xff : 0;
	
#if defined INLINE_DEBUG_PCEQB || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PCEQH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PCEQH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].sh0 = ( r->GPR [ i.Rs ].sh0 == r->GPR [ i.Rt ].sh0 ) ? 0xffff : 0;
	r->GPR [ i.Rd ].sh1 = ( r->GPR [ i.Rs ].sh1 == r->GPR [ i.Rt ].sh1 ) ? 0xffff : 0;
	r->GPR [ i.Rd ].sh2 = ( r->GPR [ i.Rs ].sh2 == r->GPR [ i.Rt ].sh2 ) ? 0xffff : 0;
	r->GPR [ i.Rd ].sh3 = ( r->GPR [ i.Rs ].sh3 == r->GPR [ i.Rt ].sh3 ) ? 0xffff : 0;
	r->GPR [ i.Rd ].sh4 = ( r->GPR [ i.Rs ].sh4 == r->GPR [ i.Rt ].sh4 ) ? 0xffff : 0;
	r->GPR [ i.Rd ].sh5 = ( r->GPR [ i.Rs ].sh5 == r->GPR [ i.Rt ].sh5 ) ? 0xffff : 0;
	r->GPR [ i.Rd ].sh6 = ( r->GPR [ i.Rs ].sh6 == r->GPR [ i.Rt ].sh6 ) ? 0xffff : 0;
	r->GPR [ i.Rd ].sh7 = ( r->GPR [ i.Rs ].sh7 == r->GPR [ i.Rt ].sh7 ) ? 0xffff : 0;
	
#if defined INLINE_DEBUG_PCEQH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}


static void Recompile::PCEQW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PCEQW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].sw0 = ( r->GPR [ i.Rs ].sw0 == r->GPR [ i.Rt ].sw0 ) ? 0xffffffff : 0;
	r->GPR [ i.Rd ].sw1 = ( r->GPR [ i.Rs ].sw1 == r->GPR [ i.Rt ].sw1 ) ? 0xffffffff : 0;
	r->GPR [ i.Rd ].sw2 = ( r->GPR [ i.Rs ].sw2 == r->GPR [ i.Rt ].sw2 ) ? 0xffffffff : 0;
	r->GPR [ i.Rd ].sw3 = ( r->GPR [ i.Rs ].sw3 == r->GPR [ i.Rt ].sw3 ) ? 0xffffffff : 0;
	
#if defined INLINE_DEBUG_PCEQW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}




static void Recompile::PEXTLB ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PEXTLB || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	// note: must do these in reverse order or else data can get overwritten
	r->GPR [ i.Rd ].uh7 = ( ( ( (u16) r->GPR [ i.Rs ].ub7 ) << 8 ) | ( (u16) r->GPR [ i.Rt ].ub7 ) );
	r->GPR [ i.Rd ].uh6 = ( ( ( (u16) r->GPR [ i.Rs ].ub6 ) << 8 ) | ( (u16) r->GPR [ i.Rt ].ub6 ) );
	r->GPR [ i.Rd ].uh5 = ( ( ( (u16) r->GPR [ i.Rs ].ub5 ) << 8 ) | ( (u16) r->GPR [ i.Rt ].ub5 ) );
	r->GPR [ i.Rd ].uh4 = ( ( ( (u16) r->GPR [ i.Rs ].ub4 ) << 8 ) | ( (u16) r->GPR [ i.Rt ].ub4 ) );
	r->GPR [ i.Rd ].uh3 = ( ( ( (u16) r->GPR [ i.Rs ].ub3 ) << 8 ) | ( (u16) r->GPR [ i.Rt ].ub3 ) );
	r->GPR [ i.Rd ].uh2 = ( ( ( (u16) r->GPR [ i.Rs ].ub2 ) << 8 ) | ( (u16) r->GPR [ i.Rt ].ub2 ) );
	r->GPR [ i.Rd ].uh1 = ( ( ( (u16) r->GPR [ i.Rs ].ub1 ) << 8 ) | ( (u16) r->GPR [ i.Rt ].ub1 ) );
	r->GPR [ i.Rd ].uh0 = ( ( ( (u16) r->GPR [ i.Rs ].ub0 ) << 8 ) | ( (u16) r->GPR [ i.Rt ].ub0 ) );
	
#if defined INLINE_DEBUG_PEXTLB || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PEXTLH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PEXTLH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	// note: must do these in reverse order or else data can get overwritten
	r->GPR [ i.Rd ].uw3 = ( ( ( (u32) r->GPR [ i.Rs ].uh3 ) << 16 ) | ( (u32) r->GPR [ i.Rt ].uh3 ) );
	r->GPR [ i.Rd ].uw2 = ( ( ( (u32) r->GPR [ i.Rs ].uh2 ) << 16 ) | ( (u32) r->GPR [ i.Rt ].uh2 ) );
	r->GPR [ i.Rd ].uw1 = ( ( ( (u32) r->GPR [ i.Rs ].uh1 ) << 16 ) | ( (u32) r->GPR [ i.Rt ].uh1 ) );
	r->GPR [ i.Rd ].uw0 = ( ( ( (u32) r->GPR [ i.Rs ].uh0 ) << 16 ) | ( (u32) r->GPR [ i.Rt ].uh0 ) );
	
#if defined INLINE_DEBUG_PEXTLH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PEXTLW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PEXTLW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	// PEXTLW rd, rs, rt
	// note: must do uq1 first or else data can get overwritten
	r->GPR [ i.Rd ].uq1 = ( ( ( (u64) r->GPR [ i.Rs ].uw1 ) << 32 ) | ( (u64) r->GPR [ i.Rt ].uw1 ) );
	r->GPR [ i.Rd ].uq0 = ( ( ( (u64) r->GPR [ i.Rs ].uw0 ) << 32 ) | ( (u64) r->GPR [ i.Rt ].uw0 ) );
	
#if defined INLINE_DEBUG_PEXTLW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PEXTUB ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PEXTUB || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].uh0 = ( ( ( (u16) r->GPR [ i.Rs ].ub8 ) << 8 ) | ( (u16) r->GPR [ i.Rt ].ub8 ) );
	r->GPR [ i.Rd ].uh1 = ( ( ( (u16) r->GPR [ i.Rs ].ub9 ) << 8 ) | ( (u16) r->GPR [ i.Rt ].ub9 ) );
	r->GPR [ i.Rd ].uh2 = ( ( ( (u16) r->GPR [ i.Rs ].ub10 ) << 8 ) | ( (u16) r->GPR [ i.Rt ].ub10 ) );
	r->GPR [ i.Rd ].uh3 = ( ( ( (u16) r->GPR [ i.Rs ].ub11 ) << 8 ) | ( (u16) r->GPR [ i.Rt ].ub11 ) );
	r->GPR [ i.Rd ].uh4 = ( ( ( (u16) r->GPR [ i.Rs ].ub12 ) << 8 ) | ( (u16) r->GPR [ i.Rt ].ub12 ) );
	r->GPR [ i.Rd ].uh5 = ( ( ( (u16) r->GPR [ i.Rs ].ub13 ) << 8 ) | ( (u16) r->GPR [ i.Rt ].ub13 ) );
	r->GPR [ i.Rd ].uh6 = ( ( ( (u16) r->GPR [ i.Rs ].ub14 ) << 8 ) | ( (u16) r->GPR [ i.Rt ].ub14 ) );
	r->GPR [ i.Rd ].uh7 = ( ( ( (u16) r->GPR [ i.Rs ].ub15 ) << 8 ) | ( (u16) r->GPR [ i.Rt ].ub15 ) );
	
#if defined INLINE_DEBUG_PEXTUB || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PEXTUH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PEXTUH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].uw0 = ( ( ( (u32) r->GPR [ i.Rs ].uh4 ) << 16 ) | ( (u32) r->GPR [ i.Rt ].uh4 ) );
	r->GPR [ i.Rd ].uw1 = ( ( ( (u32) r->GPR [ i.Rs ].uh5 ) << 16 ) | ( (u32) r->GPR [ i.Rt ].uh5 ) );
	r->GPR [ i.Rd ].uw2 = ( ( ( (u32) r->GPR [ i.Rs ].uh6 ) << 16 ) | ( (u32) r->GPR [ i.Rt ].uh6 ) );
	r->GPR [ i.Rd ].uw3 = ( ( ( (u32) r->GPR [ i.Rs ].uh7 ) << 16 ) | ( (u32) r->GPR [ i.Rt ].uh7 ) );
	
#if defined INLINE_DEBUG_PEXTUH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PEXTUW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PEXTUW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	r->GPR [ i.Rd ].uq0 = ( ( ( (u64) r->GPR [ i.Rs ].uw2 ) << 32 ) | ( (u64) r->GPR [ i.Rt ].uw2 ) );
	r->GPR [ i.Rd ].uq1 = ( ( ( (u64) r->GPR [ i.Rs ].uw3 ) << 32 ) | ( (u64) r->GPR [ i.Rt ].uw3 ) );
	
#if defined INLINE_DEBUG_PEXTUW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}








static void Recompile::PMFLO ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PMFLO || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " LO=" << r->LO.uq0 << " " << r->LO.uq1;
#endif

	r->GPR [ i.Rd ].uq0 = r->LO.uq0;
	r->GPR [ i.Rd ].uq1 = r->LO.uq1;
	
#if defined INLINE_DEBUG_PMFLO || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PMFHI ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PMFHI || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " HI=" << r->HI.uq0 << " " << r->HI.uq1;
#endif

	r->GPR [ i.Rd ].uq0 = r->HI.uq0;
	r->GPR [ i.Rd ].uq1 = r->HI.uq1;
	
#if defined INLINE_DEBUG_PMFHI || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}


static void Recompile::PINTH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PINTH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	u16 temp;

	// note: must use this order/method
	r->GPR [ i.Rd ].uh0 = r->GPR [ i.Rt ].uh0;
	r->GPR [ i.Rd ].uh7 = r->GPR [ i.Rs ].uh7;
	
	temp = r->GPR [ i.Rs ].uh4;
	r->GPR [ i.Rd ].uh4 = r->GPR [ i.Rt ].uh2;
	r->GPR [ i.Rd ].uh2 = r->GPR [ i.Rt ].uh1;
	r->GPR [ i.Rd ].uh1 = temp;
	
	temp = r->GPR [ i.Rs ].uh5;
	r->GPR [ i.Rd ].uh5 = r->GPR [ i.Rs ].uh6;
	r->GPR [ i.Rd ].uh6 = r->GPR [ i.Rt ].uh3;
	r->GPR [ i.Rd ].uh3 = temp;
	
#if defined INLINE_DEBUG_PINTH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PINTEH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PINTEH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	// note: these must be done in reverse order or else
	r->GPR [ i.Rd ].uh7 = r->GPR [ i.Rs ].uh6;
	r->GPR [ i.Rd ].uh6 = r->GPR [ i.Rt ].uh6;
	r->GPR [ i.Rd ].uh5 = r->GPR [ i.Rs ].uh4;
	r->GPR [ i.Rd ].uh4 = r->GPR [ i.Rt ].uh4;
	r->GPR [ i.Rd ].uh3 = r->GPR [ i.Rs ].uh2;
	r->GPR [ i.Rd ].uh2 = r->GPR [ i.Rt ].uh2;
	r->GPR [ i.Rd ].uh1 = r->GPR [ i.Rs ].uh0;
	r->GPR [ i.Rd ].uh0 = r->GPR [ i.Rt ].uh0;
	
#if defined INLINE_DEBUG_PINTEH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}



// multimedia multiply //


static void Recompile::PMADDH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PMADDH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	//cout << "\nhps2x64: ERROR: R5900: Instruction not implemented: PMADDH";

	// check if mul/div unit is in use
	if ( r->MulDiv_BusyUntil_Cycle > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle;
	}
	if ( r->MulDiv_BusyUntil_Cycle1 > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle1;
	}
	
	r->LO.sw0 += ( (s32) r->GPR [ i.Rs ].sh0 ) * ( (s32) r->GPR [ i.Rt ].sh0 );
	r->LO.sw1 += ( (s32) r->GPR [ i.Rs ].sh1 ) * ( (s32) r->GPR [ i.Rt ].sh1 );
	r->HI.sw0 += ( (s32) r->GPR [ i.Rs ].sh2 ) * ( (s32) r->GPR [ i.Rt ].sh2 );
	r->HI.sw1 += ( (s32) r->GPR [ i.Rs ].sh3 ) * ( (s32) r->GPR [ i.Rt ].sh3 );
	r->LO.sw2 += ( (s32) r->GPR [ i.Rs ].sh4 ) * ( (s32) r->GPR [ i.Rt ].sh4 );
	r->LO.sw3 += ( (s32) r->GPR [ i.Rs ].sh5 ) * ( (s32) r->GPR [ i.Rt ].sh5 );
	r->HI.sw2 += ( (s32) r->GPR [ i.Rs ].sh6 ) * ( (s32) r->GPR [ i.Rt ].sh6 );
	r->HI.sw3 += ( (s32) r->GPR [ i.Rs ].sh7 ) * ( (s32) r->GPR [ i.Rt ].sh7 );
	
	r->GPR [ i.Rd ].sw0 = r->LO.sw0;
	r->GPR [ i.Rd ].sw1 = r->HI.sw0;
	r->GPR [ i.Rd ].sw2 = r->LO.sw2;
	r->GPR [ i.Rd ].sw3 = r->HI.sw2;
}

static void Recompile::PMADDW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PMADDW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	//cout << "\nhps2x64: ERROR: R5900: Instruction not implemented: PMADDW";
	
	s64 sTemp64;
	
	// check if mul/div unit is in use
	if ( r->MulDiv_BusyUntil_Cycle > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle;
	}
	if ( r->MulDiv_BusyUntil_Cycle1 > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle1;
	}
	
	sTemp64 = ( (u64) r->LO.uw0 );
	sTemp64 |= ( r->HI.uq0 << 32 );
	sTemp64 += ( (s64) r->GPR [ i.Rs ].sw0 ) * ( (s64) r->GPR [ i.Rt ].sw0 );
	r->LO.sq0 = (s32) sTemp64;
	r->HI.sq0 = ( sTemp64 >> 32 );
	r->GPR [ i.Rd ].sq0 = sTemp64;
	
	sTemp64 = ( (u64) r->LO.uw2 );
	sTemp64 |= ( r->HI.uq1 << 32 );
	sTemp64 += ( (s64) r->GPR [ i.Rs ].sw2 ) * ( (s64) r->GPR [ i.Rt ].sw2 );
	r->LO.sq1 = (s32) sTemp64;
	r->HI.sq1 = ( sTemp64 >> 32 );
	r->GPR [ i.Rd ].sq1 = sTemp64;
}

static void Recompile::PMADDUW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PMADDUW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	cout << "\nhps2x64: ERROR: R5900: Instruction not implemented: PMADDUW";
	
	u64 uTemp64;
	
	// check if mul/div unit is in use
	if ( r->MulDiv_BusyUntil_Cycle > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle;
	}
	if ( r->MulDiv_BusyUntil_Cycle1 > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle1;
	}
	
	uTemp64 = ( (u64) r->LO.uw0 );
	uTemp64 |= ( r->HI.uq0 << 32 );
	uTemp64 += ( (u64) r->GPR [ i.Rs ].uw0 ) * ( (u64) r->GPR [ i.Rt ].uw0 );
	r->LO.sq0 = (s32) uTemp64;
	r->HI.sq0 = (s32) ( uTemp64 >> 32 );
	r->GPR [ i.Rd ].uq0 = uTemp64;
	
	uTemp64 = ( (u64) r->LO.uw2 );
	uTemp64 |= ( r->HI.uq1 << 32 );
	uTemp64 += ( (u64) r->GPR [ i.Rs ].uw2 ) * ( (u64) r->GPR [ i.Rt ].uw2 );
	r->LO.sq1 = (s32) uTemp64;
	r->HI.sq1 = (s32) ( uTemp64 >> 32 );
	r->GPR [ i.Rd ].uq1 = uTemp64;
}


static void Recompile::PMSUBH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PMSUBH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	//cout << "\nhps2x64: ERROR: R5900: Instruction not implemented: PMSUBH";
	
	// check if mul/div unit is in use
	if ( r->MulDiv_BusyUntil_Cycle > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle;
	}
	if ( r->MulDiv_BusyUntil_Cycle1 > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle1;
	}
	
	r->LO.sw0 -= ( (s32) r->GPR [ i.Rs ].sh0 ) * ( (s32) r->GPR [ i.Rt ].sh0 );
	r->LO.sw1 -= ( (s32) r->GPR [ i.Rs ].sh1 ) * ( (s32) r->GPR [ i.Rt ].sh1 );
	r->HI.sw0 -= ( (s32) r->GPR [ i.Rs ].sh2 ) * ( (s32) r->GPR [ i.Rt ].sh2 );
	r->HI.sw1 -= ( (s32) r->GPR [ i.Rs ].sh3 ) * ( (s32) r->GPR [ i.Rt ].sh3 );
	r->LO.sw2 -= ( (s32) r->GPR [ i.Rs ].sh4 ) * ( (s32) r->GPR [ i.Rt ].sh4 );
	r->LO.sw3 -= ( (s32) r->GPR [ i.Rs ].sh5 ) * ( (s32) r->GPR [ i.Rt ].sh5 );
	r->HI.sw2 -= ( (s32) r->GPR [ i.Rs ].sh6 ) * ( (s32) r->GPR [ i.Rt ].sh6 );
	r->HI.sw3 -= ( (s32) r->GPR [ i.Rs ].sh7 ) * ( (s32) r->GPR [ i.Rt ].sh7 );
	
	r->GPR [ i.Rd ].sw0 = r->LO.sw0;
	r->GPR [ i.Rd ].sw1 = r->HI.sw0;
	r->GPR [ i.Rd ].sw2 = r->LO.sw2;
	r->GPR [ i.Rd ].sw3 = r->HI.sw2;
}



static void Recompile::PMSUBW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PMSUBW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	//cout << "\nhps2x64: ERROR: R5900: Instruction not implemented: PMSUBW";
	
	s64 sTemp64;
	
	// check if mul/div unit is in use
	if ( r->MulDiv_BusyUntil_Cycle > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle;
	}
	if ( r->MulDiv_BusyUntil_Cycle1 > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle1;
	}
	
	sTemp64 = ( (u64) r->LO.uw0 );
	sTemp64 |= ( r->HI.uq0 << 32 );
	sTemp64 -= ( (s64) r->GPR [ i.Rs ].sw0 ) * ( (s64) r->GPR [ i.Rt ].sw0 );
	r->LO.sq0 = (s32) sTemp64;
	r->HI.sq0 = ( sTemp64 >> 32 );
	r->GPR [ i.Rd ].sq0 = sTemp64;
	
	sTemp64 = ( (u64) r->LO.uw2 );
	sTemp64 |= ( r->HI.uq1 << 32 );
	sTemp64 -= ( (s64) r->GPR [ i.Rs ].sw2 ) * ( (s64) r->GPR [ i.Rt ].sw2 );
	r->LO.sq1 = (s32) sTemp64;
	r->HI.sq1 = ( sTemp64 >> 32 );
	r->GPR [ i.Rd ].sq1 = sTemp64;
}

static void Recompile::PMULTH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PMULTH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	// check if mul/div unit is in use
	if ( r->MulDiv_BusyUntil_Cycle > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle;
	}
	if ( r->MulDiv_BusyUntil_Cycle1 > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle1;
	}
	
	// rd = 0, 2, 4, 6
	// lo = 0, 1, 4, 5
	// hi = 2, 3, 6, 7
	
	r->GPR [ i.Rd ].sw0 = ( (s32) r->GPR [ i.Rs ].sh0 ) * ( (s32) r->GPR [ i.Rt ].sh0 );
	r->GPR [ i.Rd ].sw1 = ( (s32) r->GPR [ i.Rs ].sh2 ) * ( (s32) r->GPR [ i.Rt ].sh2 );
	r->GPR [ i.Rd ].sw2 = ( (s32) r->GPR [ i.Rs ].sh4 ) * ( (s32) r->GPR [ i.Rt ].sh4 );
	r->GPR [ i.Rd ].sw3 = ( (s32) r->GPR [ i.Rs ].sh6 ) * ( (s32) r->GPR [ i.Rt ].sh6 );
	
	r->LO.sw0 = r->GPR [ i.Rd ].sw0;
	r->LO.sw1 = ( (s32) r->GPR [ i.Rs ].sh1 ) * ( (s32) r->GPR [ i.Rt ].sh1 );
	r->LO.sw2 = r->GPR [ i.Rd ].sw2;
	r->LO.sw3 = ( (s32) r->GPR [ i.Rs ].sh5 ) * ( (s32) r->GPR [ i.Rt ].sh5 );
	
	r->HI.sw0 = r->GPR [ i.Rd ].sw1;
	r->HI.sw1 = ( (s32) r->GPR [ i.Rs ].sh3 ) * ( (s32) r->GPR [ i.Rt ].sh3 );
	r->HI.sw2 = r->GPR [ i.Rd ].sw3;
	r->HI.sw3 = ( (s32) r->GPR [ i.Rs ].sh7 ) * ( (s32) r->GPR [ i.Rt ].sh7 );
	
#if defined INLINE_DEBUG_PMULTH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PMULTW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PMULTW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	// check if mul/div unit is in use
	if ( r->MulDiv_BusyUntil_Cycle > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle;
	}
	if ( r->MulDiv_BusyUntil_Cycle1 > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle1;
	}
	
	r->GPR [ i.Rd ].sq0 = ( (s64) r->GPR [ i.Rs ].sw0 ) * ( (s64) r->GPR [ i.Rt ].sw0 );
	r->GPR [ i.Rd ].sq1 = ( (s64) r->GPR [ i.Rs ].sw2 ) * ( (s64) r->GPR [ i.Rt ].sw2 );
	
	r->LO.sq0 = (s32) ( r->GPR [ i.Rd ].sq0 );
	r->LO.sq1 = (s32) ( r->GPR [ i.Rd ].sq1 );
	r->HI.sq0 = ( r->GPR [ i.Rd ].sq0 >> 32 );
	r->HI.sq1 = ( r->GPR [ i.Rd ].sq1 >> 32 );
	
#if defined INLINE_DEBUG_PMULTW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PMULTUW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PMULTUW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	// check if mul/div unit is in use
	if ( r->MulDiv_BusyUntil_Cycle > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle;
	}
	if ( r->MulDiv_BusyUntil_Cycle1 > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle1;
	}
	
	r->GPR [ i.Rd ].uq0 = ( (u64) r->GPR [ i.Rs ].uw0 ) * ( (u64) r->GPR [ i.Rt ].uw0 );
	r->GPR [ i.Rd ].uq1 = ( (u64) r->GPR [ i.Rs ].uw2 ) * ( (u64) r->GPR [ i.Rt ].uw2 );
	
	r->LO.sq0 = (s32) ( r->GPR [ i.Rd ].sq0 );
	r->LO.sq1 = (s32) ( r->GPR [ i.Rd ].sq1 );
	r->HI.sq0 = ( r->GPR [ i.Rd ].sq0 >> 32 );
	r->HI.sq1 = ( r->GPR [ i.Rd ].sq1 >> 32 );
	
#if defined INLINE_DEBUG_PMULTUW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}






static void Recompile::PHMADH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PHMADH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	//cout << "\nhps2x64: ERROR: R5900: Instruction not implemented: PHMADH";
	
	// check if mul/div unit is in use
	if ( r->MulDiv_BusyUntil_Cycle > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle;
	}
	if ( r->MulDiv_BusyUntil_Cycle1 > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle1;
	}
	
	r->LO.sw0 = ( ( (s32) r->GPR [ i.Rs ].sh1 ) * ( (s32) r->GPR [ i.Rt ].sh1 ) ) + ( ( (s32) r->GPR [ i.Rs ].sh0 ) * ( (s32) r->GPR [ i.Rt ].sh0 ) );
	r->HI.sw0 = ( ( (s32) r->GPR [ i.Rs ].sh3 ) * ( (s32) r->GPR [ i.Rt ].sh3 ) ) + ( ( (s32) r->GPR [ i.Rs ].sh2 ) * ( (s32) r->GPR [ i.Rt ].sh2 ) );
	r->LO.sw2 = ( ( (s32) r->GPR [ i.Rs ].sh5 ) * ( (s32) r->GPR [ i.Rt ].sh5 ) ) + ( ( (s32) r->GPR [ i.Rs ].sh4 ) * ( (s32) r->GPR [ i.Rt ].sh4 ) );
	r->HI.sw2 = ( ( (s32) r->GPR [ i.Rs ].sh7 ) * ( (s32) r->GPR [ i.Rt ].sh7 ) ) + ( ( (s32) r->GPR [ i.Rs ].sh6 ) * ( (s32) r->GPR [ i.Rt ].sh6 ) );
	
	r->GPR [ i.Rd ].sw0 = r->LO.sw0;
	r->GPR [ i.Rd ].sw1 = r->HI.sw0;
	r->GPR [ i.Rd ].sw2 = r->LO.sw2;
	r->GPR [ i.Rd ].sw3 = r->HI.sw2;
}



static void Recompile::PHMSBH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PHMSBH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	//cout << "\nhps2x64: ERROR: R5900: Instruction not implemented: PHMSBH";
	
	// check if mul/div unit is in use
	if ( r->MulDiv_BusyUntil_Cycle > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle;
	}
	if ( r->MulDiv_BusyUntil_Cycle1 > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle1;
	}
	
	r->LO.sw0 = ( ( (s32) r->GPR [ i.Rs ].sh1 ) * ( (s32) r->GPR [ i.Rt ].sh1 ) ) - ( ( (s32) r->GPR [ i.Rs ].sh0 ) * ( (s32) r->GPR [ i.Rt ].sh0 ) );
	r->HI.sw0 = ( ( (s32) r->GPR [ i.Rs ].sh3 ) * ( (s32) r->GPR [ i.Rt ].sh3 ) ) - ( ( (s32) r->GPR [ i.Rs ].sh2 ) * ( (s32) r->GPR [ i.Rt ].sh2 ) );
	r->LO.sw2 = ( ( (s32) r->GPR [ i.Rs ].sh5 ) * ( (s32) r->GPR [ i.Rt ].sh5 ) ) - ( ( (s32) r->GPR [ i.Rs ].sh4 ) * ( (s32) r->GPR [ i.Rt ].sh4 ) );
	r->HI.sw2 = ( ( (s32) r->GPR [ i.Rs ].sh7 ) * ( (s32) r->GPR [ i.Rt ].sh7 ) ) - ( ( (s32) r->GPR [ i.Rs ].sh6 ) * ( (s32) r->GPR [ i.Rt ].sh6 ) );
	
	r->GPR [ i.Rd ].sw0 = r->LO.sw0;
	r->GPR [ i.Rd ].sw1 = r->HI.sw0;
	r->GPR [ i.Rd ].sw2 = r->LO.sw2;
	r->GPR [ i.Rd ].sw3 = r->HI.sw2;
}



// multimedia divide //

static void Recompile::PDIVW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PDIVW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	// 37 cycles
	// divide by two until r5900 is running at proper speed
	static const int c_iDivideCycles = 37 / 2;

	// check if mul/div unit is in use
	if ( r->MulDiv_BusyUntil_Cycle > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle;
	}
	if ( r->MulDiv_BusyUntil_Cycle1 > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle1;
	}
	
	// set until when mul/div unit will be in use for each pipeline
	r->MulDiv_BusyUntil_Cycle = r->CycleCount + c_iDivideCycles;
	r->MulDiv_BusyUntil_Cycle1 = r->MulDiv_BusyUntil_Cycle;
	
	r->LO.sq0 = (s32) ( r->GPR [ i.Rs ].sw0 / r->GPR [ i.Rt ].sw0 );
	r->LO.sq1 = (s32) ( r->GPR [ i.Rs ].sw2 / r->GPR [ i.Rt ].sw2 );
	
	r->HI.sq0 = (s32) ( r->GPR [ i.Rs ].sw0 % r->GPR [ i.Rt ].sw0 );
	r->HI.sq1 = (s32) ( r->GPR [ i.Rs ].sw2 % r->GPR [ i.Rt ].sw2 );
	
#if defined INLINE_DEBUG_PDIVW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " LO=" << r->LO.uq0 << " " << r->LO.uq1 << " HI=" << r->HI.uq0 << " " << r->HI.uq1;
#endif
}

static void Recompile::PDIVUW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PDIVUW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	// 37 cycles
	// divide by two until r5900 is running at proper speed
	static const int c_iDivideCycles = 37 / 2;

	// check if mul/div unit is in use
	if ( r->MulDiv_BusyUntil_Cycle > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle;
	}
	if ( r->MulDiv_BusyUntil_Cycle1 > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle1;
	}
	
	// set until when mul/div unit will be in use for each pipeline
	r->MulDiv_BusyUntil_Cycle = r->CycleCount + c_iDivideCycles;
	r->MulDiv_BusyUntil_Cycle1 = r->MulDiv_BusyUntil_Cycle;
	
	r->LO.sq0 = (s32) ( r->GPR [ i.Rs ].uw0 / r->GPR [ i.Rt ].uw0 );
	r->LO.sq1 = (s32) ( r->GPR [ i.Rs ].uw2 / r->GPR [ i.Rt ].uw2 );
	
	r->HI.sq0 = (s32) ( r->GPR [ i.Rs ].uw0 % r->GPR [ i.Rt ].uw0 );
	r->HI.sq1 = (s32) ( r->GPR [ i.Rs ].uw2 % r->GPR [ i.Rt ].uw2 );
	
#if defined INLINE_DEBUG_PDIVUW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " LO=" << r->LO.uq0 << " " << r->LO.uq1 << " HI=" << r->HI.uq0 << " " << r->HI.uq1;
#endif
}

static void Recompile::PDIVBW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PDIVBW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	// 37 cycles
	// divide by two until r5900 is running at proper speed
	static const int c_iDivideCycles = 37 / 2;

	// check if mul/div unit is in use
	if ( r->MulDiv_BusyUntil_Cycle > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle;
	}
	if ( r->MulDiv_BusyUntil_Cycle1 > r->CycleCount )
	{
		r->CycleCount = r->MulDiv_BusyUntil_Cycle1;
	}
	
	// set until when mul/div unit will be in use for each pipeline
	r->MulDiv_BusyUntil_Cycle = r->CycleCount + c_iDivideCycles;
	r->MulDiv_BusyUntil_Cycle1 = r->MulDiv_BusyUntil_Cycle;
	
	r->LO.sw0 = ( r->GPR [ i.Rs ].sw0 / ( (s32) r->GPR [ i.Rt ].sh0 ) );
	r->LO.sw1 = ( r->GPR [ i.Rs ].sw1 / ( (s32) r->GPR [ i.Rt ].sh0 ) );
	r->LO.sw2 = ( r->GPR [ i.Rs ].sw2 / ( (s32) r->GPR [ i.Rt ].sh0 ) );
	r->LO.sw3 = ( r->GPR [ i.Rs ].sw3 / ( (s32) r->GPR [ i.Rt ].sh0 ) );
	
	r->HI.sw0 = (s16) ( r->GPR [ i.Rs ].sw0 % ( (s32) r->GPR [ i.Rt ].sh0 ) );
	r->HI.sw1 = (s16) ( r->GPR [ i.Rs ].sw1 % ( (s32) r->GPR [ i.Rt ].sh0 ) );
	r->HI.sw2 = (s16) ( r->GPR [ i.Rs ].sw2 % ( (s32) r->GPR [ i.Rt ].sh0 ) );
	r->HI.sw3 = (s16) ( r->GPR [ i.Rs ].sw3 % ( (s32) r->GPR [ i.Rt ].sh0 ) );
	
#if defined INLINE_DEBUG_PDIVBW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " LO=" << r->LO.uq0 << " " << r->LO.uq1 << " HI=" << r->HI.uq0 << " " << r->HI.uq1;
#endif
}




static void Recompile::PREVH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PREVH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif	

	u16 temp;

	// note: must use this order/method
	temp = r->GPR [ i.Rt ].uh3;
	r->GPR [ i.Rd ].uh3 = r->GPR [ i.Rt ].uh0;
	r->GPR [ i.Rd ].uh0 = temp;
	
	temp = r->GPR [ i.Rt ].uh2;
	r->GPR [ i.Rd ].uh2 = r->GPR [ i.Rt ].uh1;
	r->GPR [ i.Rd ].uh1 = temp;
	
	temp = r->GPR [ i.Rt ].uh7;
	r->GPR [ i.Rd ].uh7 = r->GPR [ i.Rt ].uh4;
	r->GPR [ i.Rd ].uh4 = temp;
	
	temp = r->GPR [ i.Rt ].uh6;
	r->GPR [ i.Rd ].uh6 = r->GPR [ i.Rt ].uh5;
	r->GPR [ i.Rd ].uh5 = temp;
	
#if defined INLINE_DEBUG_PREVH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}




static void Recompile::PEXEH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PEXEH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	u16 temp;

	// note: must use this order/method
	r->GPR [ i.Rd ].uh1 = r->GPR [ i.Rt ].uh1;
	r->GPR [ i.Rd ].uh3 = r->GPR [ i.Rt ].uh3;
	r->GPR [ i.Rd ].uh5 = r->GPR [ i.Rt ].uh5;
	r->GPR [ i.Rd ].uh7 = r->GPR [ i.Rt ].uh7;
	
	temp = r->GPR [ i.Rt ].uh2;
	r->GPR [ i.Rd ].uh2 = r->GPR [ i.Rt ].uh0;
	r->GPR [ i.Rd ].uh0 = temp;
	
	temp = r->GPR [ i.Rt ].uh6;
	r->GPR [ i.Rd ].uh6 = r->GPR [ i.Rt ].uh4;
	r->GPR [ i.Rd ].uh4 = temp;
	
#if defined INLINE_DEBUG_PEXEH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PEXEW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PEXEW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	u32 temp;

	// note: must use this order/method
	r->GPR [ i.Rd ].uw1 = r->GPR [ i.Rt ].uw1;
	r->GPR [ i.Rd ].uw3 = r->GPR [ i.Rt ].uw3;
	
	temp = r->GPR [ i.Rt ].uw2;
	r->GPR [ i.Rd ].uw2 = r->GPR [ i.Rt ].uw0;
	r->GPR [ i.Rd ].uw0 = temp;
	
#if defined INLINE_DEBUG_PEXEW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PROT3W ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PROT3W || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	u32 temp;

	// note: must use this order/method
	r->GPR [ i.Rd ].uw3 = r->GPR [ i.Rt ].uw3;
	
	temp = r->GPR [ i.Rt ].uw2;
	r->GPR [ i.Rd ].uw2 = r->GPR [ i.Rt ].uw0;
	r->GPR [ i.Rd ].uw0 = r->GPR [ i.Rt ].uw1;
	r->GPR [ i.Rd ].uw1 = temp;
	
#if defined INLINE_DEBUG_PROT3W || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}



static void Recompile::PMTHI ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PMTHI || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif

	// note: PTMHI instruction uses Rs, not Rd
	r->HI.uq0 = r->GPR [ i.Rs ].uq0;
	r->HI.uq1 = r->GPR [ i.Rs ].uq1;
	
#if defined INLINE_DEBUG_PMTHI || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " HI=" << r->HI.uq0 << " " << r->HI.uq1;
#endif
}

static void Recompile::PMTLO ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PMTLO || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif

	// note: PTMLO instruction uses Rs, not Rd
	r->LO.uq0 = r->GPR [ i.Rs ].uq0;
	r->LO.uq1 = r->GPR [ i.Rs ].uq1;
	
#if defined INLINE_DEBUG_PMTLO || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " LO=" << r->LO.uq0 << " " << r->LO.uq1;
#endif
}



static void Recompile::PCPYLD ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PCPYLD || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	// PCPYLD rd, rs, rt
	// note: must use this order
	r->GPR [ i.Rd ].uq1 = r->GPR [ i.Rs ].uq0;
	r->GPR [ i.Rd ].uq0 = r->GPR [ i.Rt ].uq0;
	
#if defined INLINE_DEBUG_PCPYLD || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PCPYUD ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PCPYUD || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	// PCPYUD rd, rs, rt
	// note: must use this order
	r->GPR [ i.Rd ].uq0 = r->GPR [ i.Rs ].uq1;
	r->GPR [ i.Rd ].uq1 = r->GPR [ i.Rt ].uq1;
	
#if defined INLINE_DEBUG_PCPYUD || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PCPYH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PCPYH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	// note: must use this order
	r->GPR [ i.Rd ].uh7 = r->GPR [ i.Rt ].uh4;
	r->GPR [ i.Rd ].uh6 = r->GPR [ i.Rt ].uh4;
	r->GPR [ i.Rd ].uh5 = r->GPR [ i.Rt ].uh4;
	r->GPR [ i.Rd ].uh4 = r->GPR [ i.Rt ].uh4;
	
	r->GPR [ i.Rd ].uh3 = r->GPR [ i.Rt ].uh0;
	r->GPR [ i.Rd ].uh2 = r->GPR [ i.Rt ].uh0;
	r->GPR [ i.Rd ].uh1 = r->GPR [ i.Rt ].uh0;
	r->GPR [ i.Rd ].uh0 = r->GPR [ i.Rt ].uh0;
	
#if defined INLINE_DEBUG_PCPYH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}


static void Recompile::PEXCH ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PEXCH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	u16 temp;

	// note: must use this order/method
	r->GPR [ i.Rd ].uh0 = r->GPR [ i.Rt ].uh0;
	r->GPR [ i.Rd ].uh3 = r->GPR [ i.Rt ].uh3;
	
	temp = r->GPR [ i.Rt ].uh2;
	r->GPR [ i.Rd ].uh2 = r->GPR [ i.Rt ].uh1;
	r->GPR [ i.Rd ].uh1 = temp;
	
	r->GPR [ i.Rd ].uh4 = r->GPR [ i.Rt ].uh4;
	r->GPR [ i.Rd ].uh7 = r->GPR [ i.Rt ].uh7;
	
	temp = r->GPR [ i.Rt ].uh6;
	r->GPR [ i.Rd ].uh6 = r->GPR [ i.Rt ].uh5;
	r->GPR [ i.Rd ].uh5 = temp;
	
#if defined INLINE_DEBUG_PEXCH || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::PEXCW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PEXCW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
#endif

	u32 temp;

	// note: must use this order/method
	r->GPR [ i.Rd ].uw0 = r->GPR [ i.Rt ].uw0;
	r->GPR [ i.Rd ].uw3 = r->GPR [ i.Rt ].uw3;
	
	temp = r->GPR [ i.Rt ].uw2;
	r->GPR [ i.Rd ].uw2 = r->GPR [ i.Rt ].uw1;
	r->GPR [ i.Rd ].uw1 = temp;
	
#if defined INLINE_DEBUG_PEXCW || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}

static void Recompile::QFSRV ( Instruction::Format i )
{
#if defined INLINE_DEBUG_QFSRV || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Rs=" << r->GPR [ i.Rs ].uq0 << " " << r->GPR [ i.Rs ].uq1;
	debug << hex << " Rt=" << r->GPR [ i.Rt ].uq0 << " " << r->GPR [ i.Rt ].uq1;
	debug << hex << " SA=" << r->SA;
#endif

	unsigned long ulRdIndex, ulSrcIndex, ulShiftAmount, ulShiftLeft, ulShiftRight;
	unsigned long long Rs0, Rt0, Rs1, Rt1;

	//cout << "\nhps2x64: ERROR: R5900: Instruction not implemented: QFSRV";
	
	// QFSRV rd, rs, rt
	
	// get the shift amount
	ulShiftAmount = r->SA & 0xf;
	
	// need the number of bits to shift, so number of bytes to shift times 8
	ulShiftAmount <<= 3;
	ulShiftRight = ulShiftAmount & 63;
	ulShiftLeft = 64 - ulShiftRight;
	
	// intialize where to copy into RD
	//ulRdIndex = 0;
	
	// these could potentially get overwritten
	Rs0 = r->GPR [ i.Rs ].uq0;
	Rs1 = r->GPR [ i.Rs ].uq1;
	Rt0 = r->GPR [ i.Rt ].uq0;
	Rt1 = r->GPR [ i.Rt ].uq1;
	
	if ( ulShiftAmount < 64 )
	{
		//r->GPR [ i.Rd ].uq0 = r->GPR [ i.Rt ].uq0 >> ulShiftRight;
		//r->GPR [ i.Rd ].uq1 = r->GPR [ i.Rt ].uq1 >> ulShiftRight;
		r->GPR [ i.Rd ].uq0 = Rt0 >> ulShiftRight;
		r->GPR [ i.Rd ].uq1 = Rt1 >> ulShiftRight;
		
		// if ulShiftLeft is 64, well.. you can't shift by 64 because it is same as shift by zero?
		if ( ulShiftRight )
		{
			//r->GPR [ i.Rd ].uq0 |= r->GPR [ i.Rt ].uq1 << ulShiftLeft;
			//r->GPR [ i.Rd ].uq1 |= r->GPR [ i.Rs ].uq0 << ulShiftLeft;
			r->GPR [ i.Rd ].uq0 |= Rt1 << ulShiftLeft;
			r->GPR [ i.Rd ].uq1 |= Rs0 << ulShiftLeft;
		}
	}
	else
	{
		//r->GPR [ i.Rd ].uq0 = r->GPR [ i.Rt ].uq1 >> ulShiftRight;
		//r->GPR [ i.Rd ].uq1 = r->GPR [ i.Rs ].uq0 >> ulShiftRight;
		r->GPR [ i.Rd ].uq0 = Rt1 >> ulShiftRight;
		r->GPR [ i.Rd ].uq1 = Rs0 >> ulShiftRight;
		
		// if ulShiftLeft is 64, well.. you can't shift by 64 because it is same as shift by zero?
		if ( ulShiftRight )
		{
			//r->GPR [ i.Rd ].uq0 |= r->GPR [ i.Rs ].uq0 << ulShiftLeft;
			//r->GPR [ i.Rd ].uq1 |= r->GPR [ i.Rs ].uq1 << ulShiftLeft;
			r->GPR [ i.Rd ].uq0 |= Rs0 << ulShiftLeft;
			r->GPR [ i.Rd ].uq1 |= Rs1 << ulShiftLeft;
		}
	}
	
	/*
	// copy RT into RD starting at index specified in SA
	for ( ulSrcIndex = ulShiftAmount; ulSrcIndex < 16; ulSrcIndex++ )
	{
		r->GPR [ i.Rd ].vub [ ulRdIndex++ ] = r->GPR [ i.Rt ].vub [ ulSrcIndex ];
	}
	
	// copy RS into RD taking over where RT left off
	for ( ulSrcIndex = 0; ulSrcIndex < ulShiftAmount; ulSrcIndex++ )
	{
		r->GPR [ i.Rd ].vub [ ulRdIndex++ ] = r->GPR [ i.Rs ].vub [ ulSrcIndex ];
	}
	*/
	
#if defined INLINE_DEBUG_QFSRV || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_INTEGER_VECTOR // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << hex << " Output:" << " Rd=" << r->GPR [ i.Rd ].uq0 << " " << r->GPR [ i.Rd ].uq1;
#endif
}





// * R5900 COP0 instructions * //


static void Recompile::EI ( Instruction::Format i )
{
#if defined INLINE_DEBUG_EI || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	if ( r->CPR0.Status.EDI || r->CPR0.Status.EXL || r->CPR0.Status.ERL || !r->CPR0.Status.KSU )
	{
		r->CPR0.Status.EIE = 1;
	}
}

static void Recompile::DI ( Instruction::Format i )
{
#if defined INLINE_DEBUG_DI || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	if ( r->CPR0.Status.EDI || r->CPR0.Status.EXL || r->CPR0.Status.ERL || !r->CPR0.Status.KSU )
	{
		r->CPR0.Status.EIE = 0;
	}

}

static void Recompile::CFC0 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_CFC0 || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	r->GPR [ i.Rt ].sq0 = (s32) r->CPC0 [ i.Rd ];

}

static void Recompile::CTC0 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_CTC0 || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	r->CPC0 [ i.Rd ] = r->GPR [ i.Rt ].sw0;
}




static void Recompile::SYNC ( Instruction::Format i )
{
#if defined INLINE_DEBUG_SYNC || defined INLINE_DEBUG_R5900
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

}


static void Recompile::CACHE ( Instruction::Format i )
{
#if defined INLINE_DEBUG_CACHE || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

}

static void Recompile::PREF ( Instruction::Format i )
{
#if defined INLINE_DEBUG_PREF || defined INLINE_DEBUG_R5900 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

}

static void Recompile::TLBR ( Instruction::Format i )
{
#if defined INLINE_DEBUG_TLBR || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

}

static void Recompile::TLBWI ( Instruction::Format i )
{
#if defined INLINE_DEBUG_TLBWI || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

}

static void Recompile::TLBWR ( Instruction::Format i )
{
#if defined INLINE_DEBUG_TLBWR || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

}

static void Recompile::TLBP ( Instruction::Format i )
{
#if defined INLINE_DEBUG_TLBP || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

}

static void Recompile::ERET ( Instruction::Format i )
{
#if defined INLINE_DEBUG_ERET || defined INLINE_DEBUG_R5900
	//if ( r->DebugNextERET )
	//{
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	//}
#endif

	if ( r->CPR0.Status.ERL )
	{
		r->NextPC = r->CPR0.ErrorEPC;
		r->CPR0.Status.ERL = 0;
		
#if defined INLINE_DEBUG_ERET || defined INLINE_DEBUG_R5900
	//if ( r->DebugNextERET )
	//{
	debug << "; Status.ERL=1;";
	debug << "; ErrorEPC=" << r->CPR0.ErrorEPC;
	debug << "; NextPC=" << r->NextPC;
	debug << "\r\nR29=" << r->GPR [ 29 ].uw0 << " R31=" << r->GPR [ 31 ].uw0 << " 0x3201d0=" << r->Bus->MainMemory.b32 [ 0x3201d0 >> 2 ];
	r->DebugNextERET = 0;
	//}
#endif
	}
	else
	{
		r->NextPC = r->CPR0.EPC;
		r->CPR0.Status.EXL = 0;
		
#if defined INLINE_DEBUG_ERET || defined INLINE_DEBUG_R5900
	//if ( r->DebugNextERET )
	//{
	debug << "; Status.ERL=0;";
	debug << "; EPC=" << r->CPR0.EPC;
	debug << "; NextPC=" << r->NextPC;
	debug << "\r\nR29=" << r->GPR [ 29 ].uw0 << " R31=" << r->GPR [ 31 ].uw0 << " 0x3201d0=" << r->Bus->MainMemory.b32 [ 0x3201d0 >> 2 ];
	r->DebugNextERET = 0;
	//}
#endif
	}
	
	// interrupt status changed
	r->UpdateInterrupt ();
	
}

// R5900 does not have RFE instruction //
//static void Recompile::RFE ( Instruction::Format i )
//{
//	strInstString << "RFE";
//	AddInstArgs ( strInstString, instruction, FTRFE );
//}


static void Recompile::DERET ( Instruction::Format i )
{
#if defined INLINE_DEBUG_DERET || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

}

static void Recompile::WAIT ( Instruction::Format i )
{
#if defined INLINE_DEBUG_WAIT || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

}





// * COP1 (floating point) instructions * //


static void Recompile::MFC1 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MFC1 || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs=" << r->CPR1 [ i.Fs ].u;
#endif

	// no delay slot on R5900?
	r->GPR [ i.Rt ].sq0 = (s32) r->CPR1 [ i.Rd ].s;
	
#if defined INLINE_DEBUG_MFC1 || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU
	debug << " Output: Rt=" << r->GPR [ i.Rt ].sq0;
#endif
}

static void Recompile::MTC1 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MTC1 || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Rt=" << r->GPR [ i.Rt ].sw0;
#endif

	// no delay slot on R5900?
	r->CPR1 [ i.Rd ].s = r->GPR [ i.Rt ].sw0;
	
#if defined INLINE_DEBUG_MTC1 || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU
	debug << " Output: Fs=" << r->CPR1 [ i.Fs ].u;
#endif
}

static void Recompile::CFC1 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_CFC1 || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " CFs=" << r->CPC1 [ i.Rd ];
#endif

	// no delay slot on R5900?
	//r->GPR [ i.Rt ].sq0 = (s32) r->CPC1 [ i.Rd ];
	r->GPR [ i.Rt ].sq0 = (s32) r->Read_CFC1 ( i.Rd );
	
#if defined INLINE_DEBUG_CFC1 || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU
	debug << " Output: Rt=" << r->GPR [ i.Rt ].sq0;
#endif
}

static void Recompile::CTC1 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_CTC1 || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Rt=" << r->GPR [ i.Rt ].sw0;
#endif

	// no delay slot on R5900?
	//r->CPC1 [ i.Rd ] = r->GPR [ i.Rt ].sw0;
	r->Write_CTC1 ( i.Rd, r->GPR [ i.Rt ].sw0 );
	
#if defined INLINE_DEBUG_CTC1 || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU
	debug << " Output: CFs=" << r->CPC1 [ i.Rd ];
#endif
}


static void Recompile::LWC1 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_LWC1 || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: base = " << r->GPR [ i.Base ].u;
#endif

	// LWC1 rt, offset(base)
	
	u32 LoadAddress;
	
	// set load to happen after delay slot
	LoadAddress = r->GPR [ i.Base ].sw0 + i.sOffset;
	
#if defined INLINE_DEBUG_LWC1 || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU
	debug << " LoadAddress=" << LoadAddress;
#endif

	// *** testing *** alert if load is from unaligned address
	if ( LoadAddress & 0x3 )
	{
		cout << "\nhps2x64 ALERT: LoadAddress is unaligned for LWC1 @ cycle=" << dec << r->CycleCount << " PC=" << hex << r->PC << " Address=" << LoadAddress << "\n";
		
		// *** testing ***
		r->ProcessSynchronousInterrupt ( Cpu::EXC_ADEL );
		return;
	}
	
	
	// ***todo*** perform signed load of word
	//r->CPR1 [ i.Rt ].s = (s32) r->Bus->Read ( LoadAddress, 0xffffffffULL );
	r->CPR1 [ i.Rt ].s = (s32) r->Bus->Read_t<0xffffffff> ( LoadAddress );
	
	
	
	// used for debugging
	r->Last_ReadAddress = LoadAddress;
	r->Last_ReadWriteAddress = LoadAddress;

#ifdef INLINE_DEBUG_TRACE
	TRACE_VALUE ( r->GPR [ i.Rt ].uw0 )
#endif
	
#if defined INLINE_DEBUG_LWC1 || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU
	debug << " Output: C1=" << r->CPR1 [ i.Rt ].u << " " << r->CPR1 [ i.Rt ].f;
#endif
}

static void Recompile::SWC1 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_SWC1 || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "; Input: rt = " << r->CPR1 [ i.Rt ].u << " " << r->CPR1 [ i.Rt ].f << "; base = " << r->GPR [ i.Base ].u;
#endif

	// SWC1 rt, offset(base)
	u32 StoreAddress;
	
	// check if storing to data cache
	//StoreAddress = r->GPR [ i.Base ].s + i.sOffset;
	StoreAddress = r->GPR [ i.Base ].sw0 + i.sOffset;
	
#if defined INLINE_DEBUG_SWC1 || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU
	debug << " StoreAddress=" << StoreAddress;
#endif

	// *** testing *** alert if load is from unaligned address
	if ( StoreAddress & 0x3 )
	{
		cout << "\nhps2x64 ALERT: StoreAddress is unaligned for SWC1 @ cycle=" << dec << r->CycleCount << " PC=" << hex << r->PC << " Address=" << StoreAddress << "\n";
		
#if defined INLINE_DEBUG_SWC1 || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU
		debug << "\r\nhps2x64 ALERT: StoreAddress is unaligned for SWC1 @ cycle=" << dec << r->CycleCount << " PC=" << hex << r->PC << " Address=" << StoreAddress << "\r\n";
#endif

		// *** testing ***
		r->ProcessSynchronousInterrupt ( Cpu::EXC_ADES );
		return;
	}
	
	// clear top 3 bits since there is no data cache for caching stores
	// don't clear top 3 bits since scratchpad is at 0x70000000
	//StoreAddress &= 0x1fffffff;
	
	
	// ***todo*** perform store of word
	//r->Bus->Write ( StoreAddress, r->CPR1 [ i.Rt ].u, 0xffffffffULL );
	r->Bus->Write_t<0xffffffff> ( StoreAddress, r->CPR1 [ i.Rt ].u );
	
	

	// used for debugging
	r->Last_WriteAddress = StoreAddress;
	r->Last_ReadWriteAddress = StoreAddress;
	
#ifdef INLINE_DEBUG_TRACE
	TRACE_VALUE ( r->CPR1 [ i.Rt ].u )
#endif
}





static void Recompile::ABS_S ( Instruction::Format i )
{
#if defined INLINE_DEBUG_ABS_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs=" << hex << r->CPR1 [ i.Fs ].u << " " << r->CPR1 [ i.Fs ].f;
#endif

	r->CPR1 [ i.Fd ].u = r->CPR1 [ i.Fs ].u & 0x7fffffff;
	
	// flags affected:
	// clears flags o,u (bits 14,15)
	r->CPC1 [ 31 ] &= ~0x0000c000;

#if defined INLINE_DEBUG_ABS_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << hex << r->CPR1 [ i.Fd ].u << " " << r->CPR1 [ i.Fd ].f;
#endif
}


static void Recompile::ADD_S ( Instruction::Format i )
{
#if defined INLINE_DEBUG_ADD_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs=" << hex << r->CPR1 [ i.Fs ].u << " " << r->CPR1 [ i.Fs ].f;
	debug << " Ft=" << hex << r->CPR1 [ i.Ft ].u << " " << r->CPR1 [ i.Ft ].f;
#endif

	//u32 OverflowFlag, UnderflowFlag, OverflowSticky, UnderflowSticky, DummyFlag, FlagSet;
	s16 StatusFlag = 0, DummyMACFlag;
	u32 FlagSet;

	// fd = fs + ft
	r->CPR1 [ i.Fd ].f = PS2_Float_Add ( r->CPR1 [ i.Fs ].f, r->CPR1 [ i.Ft ].f, 0, & StatusFlag, & DummyMACFlag );
										
	// clear bits 14, 15 in flag register
	r->CPC1 [ 31 ] &= ~0x0000c000;
	
	// get flags to set
	FlagSet = StatusFlag & 0xc;
	FlagSet = ( FlagSet << 12 ) | ( FlagSet << 1 );

	// overflow flag is bit 15
	// underflow flag is bit 14
	// sticky overflow flag is bit 4
	// sticky underflow flag is bit 3
	r->CPC1 [ 31 ] |= FlagSet;

#if defined INLINE_DEBUG_ADD_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << hex << r->CPR1 [ i.Fd ].u << " " << r->CPR1 [ i.Fd ].f;
	debug << " FlagSet=" << hex << FlagSet;
#endif
}


static void Recompile::ADDA_S ( Instruction::Format i )
{
#if defined INLINE_DEBUG_ADDA_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs=" << hex << r->CPR1 [ i.Fs ].u << " " << r->CPR1 [ i.Fs ].f;
	debug << " Ft=" << hex << r->CPR1 [ i.Ft ].u << " " << r->CPR1 [ i.Ft ].f;
#endif

	//u32 OverflowFlag, UnderflowFlag, OverflowSticky, UnderflowSticky, DummyFlag, FlagSet;
	s16 StatusFlag = 0, DummyMACFlag;
	u32 FlagSet;
	
	// ACC = fs + ft
	//r->dACC.f = PS2_Float_AddA ( r->CPR1 [ i.Fs ].f, r->CPR1 [ i.Ft ].f, 0, & StatusFlag, & DummyMACFlag );
	r->dACC.f = PS2_Float_Add ( r->CPR1 [ i.Fs ].f, r->CPR1 [ i.Ft ].f, 0, & StatusFlag, & DummyMACFlag );
	
	// clear bits 14, 15 in flag register
	r->CPC1 [ 31 ] &= ~0x0000c000;
	
	// get flags to set
	FlagSet = StatusFlag & 0xc;
	FlagSet = ( FlagSet << 12 ) | ( FlagSet << 1 );

	// overflow flag is bit 15
	// underflow flag is bit 14
	// sticky overflow flag is bit 4
	// sticky underflow flag is bit 3
	r->CPC1 [ 31 ] |= FlagSet;

#if defined INLINE_DEBUG_ADDA_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC=" << hex << r->dACC.l << " " << r->dACC.f;
	debug << " FlagSet=" << hex << FlagSet;
#endif
}



static void Recompile::CVT_S_W ( Instruction::Format i )
{
#if defined INLINE_DEBUG_CVT_S_W || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs=" << hex << r->CPR1 [ i.Fs ].u << " " << r->CPR1 [ i.Fs ].f;
#endif

	// fd = FLOAT ( fs )
	r->CPR1 [ i.Fd ].f = (float) r->CPR1 [ i.Fs ].s;
	
#if defined INLINE_DEBUG_CVT_S_W || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << hex << r->CPR1 [ i.Fd ].u << " " << r->CPR1 [ i.Fd ].f;
#endif
}


static void Recompile::SUB_S ( Instruction::Format i )
{
#if defined INLINE_DEBUG_SUB_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs=" << hex << r->CPR1 [ i.Fs ].u << " " << r->CPR1 [ i.Fs ].f;
	debug << " Ft=" << hex << r->CPR1 [ i.Ft ].u << " " << r->CPR1 [ i.Ft ].f;
#endif

	//u32 OverflowFlag, UnderflowFlag, OverflowSticky, UnderflowSticky, DummyFlag, FlagSet;
	s16 StatusFlag = 0, DummyMACFlag;
	u32 FlagSet;
	
	// fd = fs - ft
	r->CPR1 [ i.Fd ].f = PS2_Float_Sub ( r->CPR1 [ i.Fs ].f, r->CPR1 [ i.Ft ].f, 0, & StatusFlag, & DummyMACFlag );
										
	// clear bits 14, 15 in flag register
	r->CPC1 [ 31 ] &= ~0x0000c000;
	
	// get flags to set
	FlagSet = StatusFlag & 0xc;
	FlagSet = ( FlagSet << 12 ) | ( FlagSet << 1 );

	// overflow flag is bit 15
	// underflow flag is bit 14
	// sticky overflow flag is bit 4
	// sticky underflow flag is bit 3
	r->CPC1 [ 31 ] |= FlagSet;

#if defined INLINE_DEBUG_SUB_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << hex << r->CPR1 [ i.Fd ].u << " " << r->CPR1 [ i.Fd ].f;
	debug << " FlagSet=" << hex << FlagSet;
#endif
}

static void Recompile::MUL_S ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MUL_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs=" << hex << r->CPR1 [ i.Fs ].u << " " << r->CPR1 [ i.Fs ].f;
	debug << " Ft=" << hex << r->CPR1 [ i.Ft ].u << " " << r->CPR1 [ i.Ft ].f;
#endif

	//u32 OverflowFlag, UnderflowFlag, OverflowSticky, UnderflowSticky, DummyFlag, FlagSet;
	s16 StatusFlag = 0, DummyMACFlag;
	u32 FlagSet;
	
	// fd = fs * ft
	//r->CPR1 [ i.Fd ].f = r->CPR1 [ i.Fs ].f * r->CPR1 [ i.Ft ].f;
	r->CPR1 [ i.Fd ].f = PS2_Float_Mul ( r->CPR1 [ i.Fs ].f, r->CPR1 [ i.Ft ].f, 0, & StatusFlag, & DummyMACFlag );
	
	// clear bits 14, 15 in flag register
	r->CPC1 [ 31 ] &= ~0x0000c000;
	
	// get flags to set
	FlagSet = StatusFlag & 0xc;
	FlagSet = ( FlagSet << 12 ) | ( FlagSet << 1 );

	// overflow flag is bit 15
	// underflow flag is bit 14
	// sticky overflow flag is bit 4
	// sticky underflow flag is bit 3
	r->CPC1 [ 31 ] |= FlagSet;

#if defined INLINE_DEBUG_MUL_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << hex << r->CPR1 [ i.Fd ].u << " " << r->CPR1 [ i.Fd ].f;
	debug << " FlagSet=" << hex << FlagSet;
#endif
}

static void Recompile::MULA_S ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MULA_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs=" << hex << r->CPR1 [ i.Fs ].u << " " << r->CPR1 [ i.Fs ].f;
	debug << " Ft=" << hex << r->CPR1 [ i.Ft ].u << " " << r->CPR1 [ i.Ft ].f;
	debug << " ACC=" << hex << r->dACC.l << " " << r->dACC.f;
#endif

	//u32 OverflowFlag, UnderflowFlag, OverflowSticky, UnderflowSticky, DummyFlag, FlagSet;
	s16 StatusFlag = 0, DummyMACFlag;
	u32 FlagSet;
	
	// ACC = fs * ft
	//r->dACC.f = PS2_Float_MulA ( r->CPR1 [ i.Fs ].f, r->CPR1 [ i.Ft ].f, 0, & StatusFlag, & DummyMACFlag );
	r->dACC.f = PS2_Float_Mul ( r->CPR1 [ i.Fs ].f, r->CPR1 [ i.Ft ].f, 0, & StatusFlag, & DummyMACFlag );
	
	// clear bits 14, 15 in flag register
	r->CPC1 [ 31 ] &= ~0x0000c000;
	
	// get flags to set
	FlagSet = StatusFlag & 0xc;
	FlagSet = ( FlagSet << 12 ) | ( FlagSet << 1 );

	// overflow flag is bit 15
	// underflow flag is bit 14
	// sticky overflow flag is bit 4
	// sticky underflow flag is bit 3
	r->CPC1 [ 31 ] |= FlagSet;

#if defined INLINE_DEBUG_MULA_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC=" << hex << r->dACC.l << " " << r->dACC.f;
	debug << " FlagSet=" << hex << FlagSet;
#endif
}


static void Recompile::DIV_S ( Instruction::Format i )
{
#if defined INLINE_DEBUG_DIV_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs=" << hex << r->CPR1 [ i.Fs ].u << " " << r->CPR1 [ i.Fs ].f;
	debug << " Ft=" << hex << r->CPR1 [ i.Ft ].u << " " << r->CPR1 [ i.Ft ].f;
#endif

	s16 StatusFlag = 0;
	u32 FlagSet;

	// fd = fs / ft
	//r->CPR1 [ i.Fd ].f = r->CPR1 [ i.Fs ].f / r->CPR1 [ i.Ft ].f;
	r->CPR1 [ i.Fd ].f = PS2_Float_Div ( r->CPR1 [ i.Fs ].f, r->CPR1 [ i.Ft ].f, & StatusFlag );
	
	// clear non-sticky invalid/divide flags (bits 16,17)
	r->CPC1 [ 31 ] &= ~0x00030000;
	
	// ***TODO*** set flags
	// sticky divide flag is bit 5
	// sticky invalid flag is bit 6
	// divide flag is bit 16
	// invalid flag is bit 17
	
	// swap bits..
	FlagSet = ( StatusFlag & 0x10 ) | ( ( StatusFlag & 0x20 ) >> 2 );
	FlagSet = ( FlagSet << 13 ) | ( FlagSet << 2 );
	
	// set flags
	r->CPC1 [ 31 ] |= FlagSet;

#if defined INLINE_DEBUG_DIV_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << hex << r->CPR1 [ i.Fd ].u << " " << r->CPR1 [ i.Fd ].f;
	debug << " FlagSet=" << hex << FlagSet;
#endif
}

static void Recompile::SQRT_S ( Instruction::Format i )
{
#if defined INLINE_DEBUG_SQRT_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Ft=" << hex << r->CPR1 [ i.Ft ].u << " " << r->CPR1 [ i.Ft ].f;
#endif

	s16 StatusFlag = 0;
	u32 FlagSet;

	// fd = sqrt ( ft )
	r->CPR1 [ i.Fd ].f = PS2_Float_Sqrt ( r->CPR1 [ i.Ft ].f, & StatusFlag );
	
	// clear the affected non-sticky flags (bits 16,17)
	r->CPC1 [ 31 ] &= ~0x00030000;
	
	// ***TODO*** set flags
	// get invalid flag
	FlagSet = StatusFlag & 0x10;
	FlagSet = ( FlagSet << 13 ) | ( FlagSet << 2 );
	
	// set the flags
	r->CPC1 [ 31 ] |= FlagSet;
	
#if defined INLINE_DEBUG_SQRT_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << hex << r->CPR1 [ i.Fd ].u << " " << r->CPR1 [ i.Fd ].f;
	debug << " FlagSet=" << hex << FlagSet;
#endif
}


static void Recompile::RSQRT_S ( Instruction::Format i )
{
#if defined INLINE_DEBUG_RSQRT_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs=" << hex << r->CPR1 [ i.Fs ].u << " " << r->CPR1 [ i.Fs ].f;
	debug << " Ft=" << hex << r->CPR1 [ i.Ft ].u << " " << r->CPR1 [ i.Ft ].f;
#endif

	s16 StatusFlag = 0;
	u32 FlagSet;
	
	r->CPR1 [ i.Fd ].f = PS2_Float_RSqrt ( r->CPR1 [ i.Fs ].f, r->CPR1 [ i.Ft ].f, & StatusFlag );
	
	// clear the affected non-sticky flags (bits 16,17)
	r->CPC1 [ 31 ] &= ~0x00030000;
	
	// ***todo*** flags
	// swap bits..
	FlagSet = ( StatusFlag & 0x10 ) | ( ( StatusFlag & 0x20 ) >> 2 );
	FlagSet = ( FlagSet << 13 ) | ( FlagSet << 2 );
	
	// set flags
	r->CPC1 [ 31 ] |= FlagSet;
	
#if defined INLINE_DEBUG_RSQRT_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << hex << r->CPR1 [ i.Fd ].u << " " << r->CPR1 [ i.Fd ].f;
	debug << " FlagSet=" << hex << FlagSet;
#endif
}




static void Recompile::MOV_S ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MOV_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs=" << hex << r->CPR1 [ i.Fs ].u << " " << r->CPR1 [ i.Fs ].f;
#endif

	r->CPR1 [ i.Fd ].u = r->CPR1 [ i.Fs ].u;
	
	// flags affected: none

#if defined INLINE_DEBUG_MOV_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << hex << r->CPR1 [ i.Fd ].u << " " << r->CPR1 [ i.Fd ].f;
#endif
}

static void Recompile::NEG_S ( Instruction::Format i )
{
#if defined INLINE_DEBUG_NEG_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs=" << hex << r->CPR1 [ i.Fs ].u << " " << r->CPR1 [ i.Fs ].f;
#endif

	r->CPR1 [ i.Fd ].u = r->CPR1 [ i.Fs ].u ^ 0x80000000;
	
	// flags affected:
	// clears flags o,u (bits 14,15)
	r->CPC1 [ 31 ] &= ~0x0000c000;

#if defined INLINE_DEBUG_NEG_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << hex << r->CPR1 [ i.Fd ].u << " " << r->CPR1 [ i.Fd ].f;
#endif
}



static void Recompile::SUBA_S ( Instruction::Format i )
{
#if defined INLINE_DEBUG_SUBA_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs=" << hex << r->CPR1 [ i.Fs ].u << " " << r->CPR1 [ i.Fs ].f;
	debug << " Ft=" << hex << r->CPR1 [ i.Ft ].u << " " << r->CPR1 [ i.Ft ].f;
	debug << " ACC=" << hex << r->dACC.l << " " << r->dACC.f;
#endif

	//u32 OverflowFlag, UnderflowFlag, OverflowSticky, UnderflowSticky, DummyFlag, FlagSet;
	s16 StatusFlag = 0, DummyMACFlag;
	u32 FlagSet;
	
	//r->dACC.f = PS2_Float_SubA ( r->CPR1 [ i.Fs ].f, r->CPR1 [ i.Ft ].f, 0, & StatusFlag, & DummyMACFlag );
	r->dACC.f = PS2_Float_Sub ( r->CPR1 [ i.Fs ].f, r->CPR1 [ i.Ft ].f, 0, & StatusFlag, & DummyMACFlag );
	
	// clear bits 14, 15 in flag register
	r->CPC1 [ 31 ] &= ~0x0000c000;
	
	// get flags to set
	FlagSet = StatusFlag & 0xc;
	FlagSet = ( FlagSet << 12 ) | ( FlagSet << 1 );

	// overflow flag is bit 15
	// underflow flag is bit 14
	// sticky overflow flag is bit 4
	// sticky underflow flag is bit 3
	r->CPC1 [ 31 ] |= FlagSet;
	
#if defined INLINE_DEBUG_SUBA_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " ACC=" << hex << r->dACC.l << " " << r->dACC.f;
	debug << " FlagSet=" << hex << FlagSet;
#endif
}

static void Recompile::MADD_S ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MADD_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs=" << hex << r->CPR1 [ i.Fs ].u << " " << r->CPR1 [ i.Fs ].f;
	debug << " Ft=" << hex << r->CPR1 [ i.Ft ].u << " " << r->CPR1 [ i.Ft ].f;
	debug << " ACC=" << hex << r->dACC.l << " " << r->dACC.f;
#endif

	//u32 OverflowFlag, UnderflowFlag, OverflowSticky, UnderflowSticky, DummyFlag, FlagSet;
	s16 StatusFlag = 0, DummyMACFlag;
	u32 FlagSet;
	
	float fTemp;

	// fd = fs * ft + ACC
	//fTemp = r->CPR1 [ i.Fs ].f * r->CPR1 [ i.Ft ].f;
	//r->CPR1 [ i.Fd ].f = fTemp + r->ACC.f;
	//r->CPR1 [ i.Fd ].f = PS2_Float_Madd ( r->dACC.f, r->CPR1 [ i.Fs ].f, r->CPR1 [ i.Ft ].f, 0, & StatusFlag, & DummyMACFlag );
	r->CPR1 [ i.Fd ].f = PS2_Float_Madd ( r->dACC.f, r->CPR1 [ i.Fd ].f, r->CPR1 [ i.Fs ].f, r->CPR1 [ i.Ft ].f, 0, & StatusFlag, & DummyMACFlag );
	
	// clear bits 14, 15 in flag register
	r->CPC1 [ 31 ] &= ~0x0000c000;
	
	// get flags to set
	FlagSet = StatusFlag & 0xc;
	FlagSet = ( FlagSet << 12 ) | ( FlagSet << 1 );

	// overflow flag is bit 15
	// underflow flag is bit 14
	// sticky overflow flag is bit 4
	// sticky underflow flag is bit 3
	r->CPC1 [ 31 ] |= FlagSet;

#if defined INLINE_DEBUG_MADD_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << hex << r->CPR1 [ i.Fd ].u << " " << r->CPR1 [ i.Fd ].f;
	debug << " FlagSet=" << hex << FlagSet;
#endif
}

static void Recompile::MSUB_S ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MSUB_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs=" << hex << r->CPR1 [ i.Fs ].u << " " << r->CPR1 [ i.Fs ].f;
	debug << " Ft=" << hex << r->CPR1 [ i.Ft ].u << " " << r->CPR1 [ i.Ft ].f;
	debug << " ACC=" << hex << r->dACC.l << " " << r->dACC.f;
#endif

	//u32 OverflowFlag, UnderflowFlag, OverflowSticky, UnderflowSticky, DummyFlag, FlagSet;
	s16 StatusFlag = 0, DummyMACFlag;
	u32 FlagSet;
	
	//r->CPR1 [ i.Fd ].f = PS2_Float_Msub ( r->dACC.f, r->CPR1 [ i.Fs ].f, r->CPR1 [ i.Ft ].f, 0, & StatusFlag, & DummyMACFlag );
	r->CPR1 [ i.Fd ].f = PS2_Float_Msub ( r->dACC.f, r->CPR1 [ i.Fd ].f, r->CPR1 [ i.Fs ].f, r->CPR1 [ i.Ft ].f, 0, & StatusFlag, & DummyMACFlag );
	
	// clear bits 14, 15 in flag register
	r->CPC1 [ 31 ] &= ~0x0000c000;
	
	// get flags to set
	FlagSet = StatusFlag & 0xc;
	FlagSet = ( FlagSet << 12 ) | ( FlagSet << 1 );

	// overflow flag is bit 15
	// underflow flag is bit 14
	// sticky overflow flag is bit 4
	// sticky underflow flag is bit 3
	r->CPC1 [ 31 ] |= FlagSet;
	
#if defined INLINE_DEBUG_MSUB_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << hex << r->CPR1 [ i.Fd ].u << " " << r->CPR1 [ i.Fd ].f;
	debug << " FlagSet=" << hex << FlagSet;
#endif
}

static void Recompile::MSUBA_S ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MSUBA_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs=" << hex << r->CPR1 [ i.Fs ].u << " " << r->CPR1 [ i.Fs ].f;
	debug << " Ft=" << hex << r->CPR1 [ i.Ft ].u << " " << r->CPR1 [ i.Ft ].f;
	debug << " ACC=" << hex << r->dACC.l << " " << r->dACC.f;
#endif

	//u32 OverflowFlag, UnderflowFlag, OverflowSticky, UnderflowSticky, DummyFlag, FlagSet;
	s16 StatusFlag = 0, DummyMACFlag;
	u32 FlagSet;
	
	//r->dACC.f = PS2_Float_MsubA ( r->dACC.f, r->CPR1 [ i.Fs ].f, r->CPR1 [ i.Ft ].f, 0, & StatusFlag, & DummyMACFlag );
	r->dACC.f = PS2_Float_Msub ( r->dACC.f, r->CPR1 [ i.Fd ].f, r->CPR1 [ i.Fs ].f, r->CPR1 [ i.Ft ].f, 0, & StatusFlag, & DummyMACFlag );
	
	// clear bits 14, 15 in flag register
	r->CPC1 [ 31 ] &= ~0x0000c000;
	
	// get flags to set
	FlagSet = StatusFlag & 0xc;
	FlagSet = ( FlagSet << 12 ) | ( FlagSet << 1 );

	// overflow flag is bit 15
	// underflow flag is bit 14
	// sticky overflow flag is bit 4
	// sticky underflow flag is bit 3
	r->CPC1 [ 31 ] |= FlagSet;
	
#if defined INLINE_DEBUG_MSUBA_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " ACC=" << hex << r->dACC.l << " " << r->dACC.f;
	debug << " FlagSet=" << hex << FlagSet;
#endif
}

static void Recompile::MADDA_S ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MADDA_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs=" << hex << r->CPR1 [ i.Fs ].u << " " << r->CPR1 [ i.Fs ].f;
	debug << " Ft=" << hex << r->CPR1 [ i.Ft ].u << " " << r->CPR1 [ i.Ft ].f;
	debug << " ACC=" << hex << r->dACC.l << " " << r->dACC.f;
#endif

	//u32 OverflowFlag, UnderflowFlag, OverflowSticky, UnderflowSticky, DummyFlag, FlagSet;
	s16 StatusFlag = 0, DummyMACFlag;
	u32 FlagSet;
	
	//r->dACC.f = PS2_Float_MaddA ( r->dACC.f, r->CPR1 [ i.Fs ].f, r->CPR1 [ i.Ft ].f, 0, & StatusFlag, & DummyMACFlag );
	r->dACC.f = PS2_Float_Madd ( r->dACC.f, r->CPR1 [ i.Fd ].f, r->CPR1 [ i.Fs ].f, r->CPR1 [ i.Ft ].f, 0, & StatusFlag, & DummyMACFlag );
										
	// clear bits 14, 15 in flag register
	r->CPC1 [ 31 ] &= ~0x0000c000;
	
	// get flags to set
	FlagSet = StatusFlag & 0xc;
	FlagSet = ( FlagSet << 12 ) | ( FlagSet << 1 );

	// overflow flag is bit 15
	// underflow flag is bit 14
	// sticky overflow flag is bit 4
	// sticky underflow flag is bit 3
	r->CPC1 [ 31 ] |= FlagSet;
	
#if defined INLINE_DEBUG_MADDA_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " ACC=" << hex << r->dACC.l << " " << r->dACC.f;
	debug << " FlagSet=" << hex << FlagSet;
#endif
}

static void Recompile::CVT_W_S ( Instruction::Format i )
{
#if defined INLINE_DEBUG_CVT_W_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs=" << hex << r->CPR1 [ i.Fs ].u << " " << r->CPR1 [ i.Fs ].f;
#endif

	// fd = INT ( fs )
	/*
	if ( ( r->CPR1 [ i.Fs ].u & 0x7f800000 ) <= 0x4e800000 )
	{
		r->CPR1 [ i.Fd ].s = (s32) r->CPR1 [ i.Fs ].f;
	}
	else if ( r->CPR1 [ i.Fs ].u & 0x80000000 )
	{
		// set to negative integer max
		r->CPR1 [ i.Fd ].u = 0x80000000;
	}
	else
	{
		// set to positive integer max
		r->CPR1 [ i.Fd ].u = 0x7fffffff;
	}
	*/
	
	r->CPR1 [ i.Fd ].u = PS2_Float_ToInteger ( r->CPR1 [ i.Fs ].f );
	
#if defined INLINE_DEBUG_CVT_W_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << hex << r->CPR1 [ i.Fd ].u << " " << r->CPR1 [ i.Fd ].f;
#endif
}

static void Recompile::MAX_S ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MAX_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs=" << hex << r->CPR1 [ i.Fs ].u << " " << r->CPR1 [ i.Fs ].f;
	debug << " Ft=" << hex << r->CPR1 [ i.Ft ].u << " " << r->CPR1 [ i.Ft ].f;
#endif

	// fd = MAX ( fs, ft )
	//r->CPR1 [ i.Fd ].f = ( ( r->CPR1 [ i.Fs ].f >= r->CPR1 [ i.Ft ].f ) ? r->CPR1 [ i.Fs ].f : r->CPR1 [ i.Ft ].f );
	r->CPR1 [ i.Fd ].f = PS2_Float_Max ( r->CPR1 [ i.Fs ].f, r->CPR1 [ i.Ft ].f );

	// flags affected:
	// clears flags o,u (bits 14,15)
	r->CPC1 [ 31 ] &= ~0x0000c000;
	
#if defined INLINE_DEBUG_MAX_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << hex << r->CPR1 [ i.Fd ].u << " " << r->CPR1 [ i.Fd ].f;
#endif
}

static void Recompile::MIN_S ( Instruction::Format i )
{
#if defined INLINE_DEBUG_MIN_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs=" << hex << r->CPR1 [ i.Fs ].u << " " << r->CPR1 [ i.Fs ].f;
	debug << " Ft=" << hex << r->CPR1 [ i.Ft ].u << " " << r->CPR1 [ i.Ft ].f;
#endif

	// fd = MIN ( fs, ft )
	//r->CPR1 [ i.Fd ].f = ( ( r->CPR1 [ i.Fs ].f <= r->CPR1 [ i.Ft ].f ) ? r->CPR1 [ i.Fs ].f : r->CPR1 [ i.Ft ].f );
	r->CPR1 [ i.Fd ].f = PS2_Float_Min ( r->CPR1 [ i.Fs ].f, r->CPR1 [ i.Ft ].f );

	// flags affected:
	// clears flags o,u (bits 14,15)
	r->CPC1 [ 31 ] &= ~0x0000c000;
	
#if defined INLINE_DEBUG_MIN_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << hex << r->CPR1 [ i.Fd ].u << " " << r->CPR1 [ i.Fd ].f;
#endif
}

static void Recompile::C_F_S ( Instruction::Format i )
{
#if defined INLINE_DEBUG_C_F_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	// clears bit 23 in FCR31
	r->CPC1 [ 31 ] &= ~0x00800000;
	
#if defined INLINE_DEBUG_C_F_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: FCR31=" << hex << r->CPC1 [ 31 ];
#endif
}

static void Recompile::C_EQ_S ( Instruction::Format i )
{
#if defined INLINE_DEBUG_C_EQ_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs=" << hex << r->CPR1 [ i.Fs ].u << " " << r->CPR1 [ i.Fs ].f;
	debug << " Ft=" << hex << r->CPR1 [ i.Ft ].u << " " << r->CPR1 [ i.Ft ].f;
#endif

	float fs, ft;
	
	fs = r->CPR1 [ i.Fs ].f;
	ft = r->CPR1 [ i.Ft ].f;

	PS2Float::ClampValue2_f ( fs, ft );
	
	if ( fs == ft )
	{
#if defined INLINE_DEBUG_C_EQ_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU
	debug << " EQUAL";
#endif

		r->CPC1 [ 31 ] |= 0x00800000;
	}
	else
	{
#if defined INLINE_DEBUG_C_EQ_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU
	debug << " NOTEQUAL";
#endif

		r->CPC1 [ 31 ] &= ~0x00800000;
	}
	
#if defined INLINE_DEBUG_C_EQ_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: FCR31=" << hex << r->CPC1 [ 31 ];
#endif
}

static void Recompile::C_LT_S ( Instruction::Format i )
{
#if defined INLINE_DEBUG_C_LT_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs=" << hex << r->CPR1 [ i.Fs ].u << " " << r->CPR1 [ i.Fs ].f;
	debug << " Ft=" << hex << r->CPR1 [ i.Ft ].u << " " << r->CPR1 [ i.Ft ].f;
#endif

	float fs, ft;
	
	fs = r->CPR1 [ i.Fs ].f;
	ft = r->CPR1 [ i.Ft ].f;

	PS2Float::ClampValue2_f ( fs, ft );
	
	// Cond = fs < ft
	// ***todo*** handle non-ieee values for this too
	if ( fs < ft )
	{
#if defined INLINE_DEBUG_C_LT_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU
	debug << " LESS";
#endif

		r->CPC1 [ 31 ] |= 0x00800000;
	}
	else
	{
#if defined INLINE_DEBUG_C_LT_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU
	debug << " NOTLESS";
#endif

		r->CPC1 [ 31 ] &= ~0x00800000;
	}
	
#if defined INLINE_DEBUG_C_LT_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: FCR31=" << hex << r->CPC1 [ 31 ];
#endif
}

static void Recompile::C_LE_S ( Instruction::Format i )
{
#if defined INLINE_DEBUG_C_LE_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs=" << hex << r->CPR1 [ i.Fs ].u << " " << r->CPR1 [ i.Fs ].f;
	debug << " Ft=" << hex << r->CPR1 [ i.Ft ].u << " " << r->CPR1 [ i.Ft ].f;
#endif

	float fs, ft;
	
	fs = r->CPR1 [ i.Fs ].f;
	ft = r->CPR1 [ i.Ft ].f;

	PS2Float::ClampValue2_f ( fs, ft );
	
	if ( fs <= ft )
	{
#if defined INLINE_DEBUG_C_LE_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU
	debug << " LESSEQ";
#endif

		r->CPC1 [ 31 ] |= 0x00800000;
	}
	else
	{
#if defined INLINE_DEBUG_C_LE_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU
	debug << " NOTLESSEQ";
#endif

		r->CPC1 [ 31 ] &= ~0x00800000;
	}
	
#if defined INLINE_DEBUG_C_LE_S || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: FCR31=" << hex << r->CPC1 [ 31 ];
#endif
}



// * COP2 (VU0) instrutions * //



// PS2 has LQC2/SQC2 instead of LWC2/SWC2 //
static void Recompile::LQC2 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_LQC2 || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Base=" << r->GPR [ i.Base ].sw0;
#endif

	// LQC2 ft, offset(base)
	
	u32 LoadAddress;
	u64* Data;
	
	// set load to happen after delay slot
	//LoadAddress = r->GPR [ i.Base ].s + i.sOffset;
	LoadAddress = r->GPR [ i.Base ].sw0 + i.sOffset;
	
#if defined INLINE_DEBUG_LQC2 || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " LoadAddress=" << LoadAddress;
#endif

	// *** testing *** alert if load is from unaligned address
	if ( LoadAddress & 0xf )
	{
#if defined INLINE_DEBUG_LQC2 || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
		debug << " UNALIGNED";
#endif

		cout << "\nhps2x64 ALERT: LoadAddress is unaligned for LQC2 @ cycle=" << dec << r->CycleCount << " PC=" << hex << r->PC << " Address=" << LoadAddress << "\n";
		
		// *** testing ***
		r->ProcessSynchronousInterrupt ( Cpu::EXC_ADEL );
		return;
	}
	
	// bottom four bits of Address are cleared
	//LoadAddress &= ~0xf;
	
	// ***todo*** perform signed load of word
	//Data = (u64*) r->Bus->Read ( LoadAddress, 0 );
	//r->GPR [ i.Rt ].uLo = Data [ 1 ];
	//r->GPR [ i.Rt ].uHi = Data [ 0 ];
	//Data = (u64*) r->Bus->Read ( LoadAddress, 0 );
	Data = (u64*) r->Bus->Read_t<0> ( LoadAddress );

	VU0::_VU0->vf [ i.Ft ].uq0 = Data [ 0 ];
	VU0::_VU0->vf [ i.Ft ].uq1 = Data [ 1 ];
	
	
	// used for debugging
	r->Last_ReadAddress = LoadAddress;
	r->Last_ReadWriteAddress = LoadAddress;
	
#if defined INLINE_DEBUG_LQC2 || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output:" << " ft=" << VU0::_VU0->vf [ i.Ft ].sq0 << " " << VU0::_VU0->vf [ i.Ft ].sq1;
#endif
}

static void Recompile::SQC2 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_SQC2 || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Base=" << r->GPR [ i.Base ].sw0;
	debug << " ft=" << VU0::_VU0->vf [ i.Ft ].sq0 << " " << VU0::_VU0->vf [ i.Ft ].sq1;
#endif

	// SQC2 ft, offset(base)
	u32 StoreAddress;
	
	// check if storing to data cache
	//StoreAddress = r->GPR [ i.Base ].s + i.sOffset;
	StoreAddress = r->GPR [ i.Base ].sw0 + i.sOffset;
	
#if defined INLINE_DEBUG_SQC2 || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " StoreAddress=" << StoreAddress;
#endif

	// *** testing *** alert if load is from unaligned address
	if ( StoreAddress & 0xf )
	{
#if defined INLINE_DEBUG_SQC2 || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
		debug << " UNALIGNED";
#endif

		cout << "\nhps2x64 ALERT: StoreAddress is unaligned for SQC2 @ cycle=" << dec << r->CycleCount << " PC=" << hex << r->PC << " Address=" << StoreAddress << "\n";
		
		// *** testing ***
		r->ProcessSynchronousInterrupt ( Cpu::EXC_ADES );
		return;
	}
	
	// clear top 3 bits since there is no data cache for caching stores
	// don't clear top 3 bits since scratchpad is at 0x70000000
	//StoreAddress &= 0x1fffffff;
	
	// bottom four bits of Address are cleared
	//StoreAddress &= ~0xf;
	
	// ***todo*** perform store of word
	// *note* probably want to pass a pointer to hi part, since that is in lower area of memory
	//r->Bus->Write ( StoreAddress, & ( VU0::_VU0->vf [ i.Ft ].uw0 ), 0 );
	r->Bus->Write_t<0> ( StoreAddress, (u64) & ( VU0::_VU0->vf [ i.Ft ].uw0 ) );
	

	// used for debugging
	r->Last_WriteAddress = StoreAddress;
	r->Last_ReadWriteAddress = StoreAddress;
}


static void Recompile::QMFC2_NI ( Instruction::Format i )
{
#if defined INLINE_DEBUG_QMFC2_NI || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Rd/Fs=" << VU0::_VU0->vf [ i.Rd ].sq0 << " " << VU0::_VU0->vf [ i.Rd ].sq1;
#endif

	// QMFC2.NI rt, fd -> fd is actually rd
	// NI -> no interlocking. does not wait for previous VCALLMS to complete

	//r->GPR [ i.Rt ].sq0 = r->CPR2 [ i.Fd ].sq0;
	//r->GPR [ i.Rt ].sq1 = r->CPR2 [ i.Fd ].sq1;
	
	r->GPR [ i.Rt ].sq0 = VU0::_VU0->vf [ i.Rd ].sq0;
	r->GPR [ i.Rt ].sq1 = VU0::_VU0->vf [ i.Rd ].sq1;
	
#if defined INLINE_DEBUG_QMFC2_NI || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output:" << " Rt=" << r->GPR [ i.Rt ].sq0 << " " << r->GPR [ i.Rt ].sq1;
#endif
}

static void Recompile::QMFC2_I ( Instruction::Format i )
{
#if defined INLINE_DEBUG_QMFC2_I || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Rd/Fs=" << VU0::_VU0->vf [ i.Rd ].sq0 << " " << VU0::_VU0->vf [ i.Rd ].sq1;
#endif

	// QMFC2.I rt, fd
	// I -> interlocking. waits for previous VCALLMS to complete
	// ***todo*** implement interlocking

	//r->GPR [ i.Rt ].sq0 = r->CPR2 [ i.Fd ].sq0;
	//r->GPR [ i.Rt ].sq1 = r->CPR2 [ i.Fd ].sq1;
	
	if ( VU0::_VU0->VifRegs.STAT.VEW )
	{
		// vu#0 is running //
		
		// don't go anywhere until it is done for now
		r->NextPC = r->PC;
	}
	else
	{
		r->GPR [ i.Rt ].sq0 = VU0::_VU0->vf [ i.Rd ].sq0;
		r->GPR [ i.Rt ].sq1 = VU0::_VU0->vf [ i.Rd ].sq1;
	}
	
#if defined INLINE_DEBUG_QMFC2_I || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output:" << " Rt=" << r->GPR [ i.Rt ].sq0 << " " << r->GPR [ i.Rt ].sq1;
#endif
}

static void Recompile::QMTC2_NI ( Instruction::Format i )
{
#if defined INLINE_DEBUG_QMTC2_NI || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Rt=" << r->GPR [ i.Rt ].uw0 << " " << r->GPR [ i.Rt ].uw1 << " " << r->GPR [ i.Rt ].uw2 << " " << r->GPR [ i.Rt ].uw3;
#endif

	// QMTC2.NI rt, fd
	// NI -> no interlocking. does not wait for previous VCALLMS to complete

	//r->CPR2 [ i.Rt ].sq0 = r->GPR [ i.Fd ].sq0;
	//r->CPR2 [ i.Rt ].sq1 = r->GPR [ i.Fd ].sq1;
	VU0::_VU0->vf [ i.Rd ].sq0 = r->GPR [ i.Rt ].sq0;
	VU0::_VU0->vf [ i.Rd ].sq1 = r->GPR [ i.Rt ].sq1;
	
#if defined INLINE_DEBUG_QMTC2_NI || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output:" << " Rd/Fs=" << VU0::_VU0->vf [ i.Rd ].sq0 << " " << VU0::_VU0->vf [ i.Rd ].sq1;
#endif
}

static void Recompile::QMTC2_I ( Instruction::Format i )
{
#if defined INLINE_DEBUG_QMTC2_I || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_VU0 //	 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Rt=" << r->GPR [ i.Rt ].uw0 << " " << r->GPR [ i.Rt ].uw1 << " " << r->GPR [ i.Rt ].uw2 << " " << r->GPR [ i.Rt ].uw3;
#endif

	// QMTC2.I rt, fd
	// I -> interlocking. waits for previous VCALLMS to complete
	// ***todo*** implement interlocking

	//r->CPR2 [ i.Rt ].sq0 = r->GPR [ i.Rd ].sq0;
	//r->CPR2 [ i.Rt ].sq1 = r->GPR [ i.Rd ].sq1;
	
	// for now, just ignore the interlock
	// all it does is stop the write if m bit is set
	//if ( VU0::_VU0->VifRegs.STAT.VEW )
	//{
		// vu#0 is running //
		
		// don't go anywhere until it is done for now
	//	r->NextPC = r->PC;
	//}
	//else
	//{
		VU0::_VU0->vf [ i.Rd ].sq0 = r->GPR [ i.Rt ].sq0;
		VU0::_VU0->vf [ i.Rd ].sq1 = r->GPR [ i.Rt ].sq1;
	//}
	
#if defined INLINE_DEBUG_QMTC2_I || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output:" << " Rd/Fs=" << VU0::_VU0->vf [ i.Rd ].sq0 << " " << VU0::_VU0->vf [ i.Rd ].sq1;
#endif
}


static void Recompile::COP2 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_COP2 || defined INLINE_DEBUG_R5900 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	cout << "\nhps2x64: ALERT: 'COP2' Instruction ?? \n";

}




// VABS //

static void Recompile::VABS ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VABS || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::ABS ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
	// does not affect any flags
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}


// VADD //

static void Recompile::VADD ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VADD || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::ADD ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VADDi ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VADDi || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::ADDi ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
}

static void Recompile::VADDq ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VADDq || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::ADDq ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VADDBCX ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VADDBCX || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::ADDBCX ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VADDBCY ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VADDBCY || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::ADDBCY ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VADDBCZ ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VADDBCZ || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::ADDBCZ ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VADDBCW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VADDBCW || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::ADDBCW ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}


// VADDA //

static void Recompile::VADDA ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VADDA || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::ADDA ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VADDAi ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VADDAi || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::ADDAi ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VADDAq ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VADDAq || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::ADDAq ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VADDABCX ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VADDABCX || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::ADDABCX ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VADDABCY ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VADDABCY || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::ADDABCY ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VADDABCZ ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VADDABCZ || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::ADDABCZ ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VADDABCW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VADDABCW || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::ADDABCW ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}





// VSUB //

static void Recompile::VSUB ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VSUB || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::SUB ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VSUBi ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VSUBi || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::SUBi ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VSUBq ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VSUBq || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::SUBq ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VSUBBCX ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VSUBBCX || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::SUBBCX ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VSUBBCY ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VSUBBCY || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::SUBBCY ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VSUBBCZ ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VSUBBCZ || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::SUBBCZ ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VSUBBCW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VSUBBCW || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::SUBBCW ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}




// VMADD //

static void Recompile::VMADD ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMADD || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MADD ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMADDi ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMADDi || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MADDi ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMADDq ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMADDq || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MADDq ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMADDBCX ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMADDBCX || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MADDBCX ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMADDBCY ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMADDBCY || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MADDBCY ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMADDBCZ ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMADDBCZ || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MADDBCZ ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMADDBCW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMADDBCW || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MADDBCW ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}




// VMSUB //

static void Recompile::VMSUB ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMSUB || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MSUB ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMSUBi ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMSUBi || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MSUBi ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMSUBq ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMSUBq || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MSUBq ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMSUBBCX ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMSUBBCX || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MSUBBCX ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMSUBBCY ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMSUBBCY || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MSUBBCY ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMSUBBCZ ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMSUBBCZ || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MSUBBCZ ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMSUBBCW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMSUBBCW || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MSUBBCW ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}




// VMAX //

static void Recompile::VMAX ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMAX || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MAX ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VMAXi ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMAXi || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MAXi ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VMAXBCX ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMAXBCX || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MAXBCX ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VMAXBCY ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMAXBCY || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MAXBCY ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VMAXBCZ ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMAXBCZ || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MAXBCZ ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VMAXBCW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMAXBCW || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MAXBCW ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}




// VMINI //

static void Recompile::VMINI ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMINI || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MINI ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VMINIi ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMINi || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MINIi ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VMINIBCX ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMINIBCX || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MINIBCX ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VMINIBCY ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMINIBCY || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MINIBCY ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VMINIBCZ ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMINIBCZ || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MINIBCZ ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VMINIBCW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMINIBCW || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MINIBCW ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}




// VMUL //

static void Recompile::VMUL ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMUL || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MUL ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMULi ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMULi || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MULi ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMULq ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMULq || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MULq ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMULBCX ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMULBCX || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MULBCX ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMULBCY ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMULBCY || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MULBCY ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMULBCZ ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMULBCZ || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MULBCZ ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMULBCW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMULBCW || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MULBCW ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}






static void Recompile::VOPMSUB ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VOPMSUB || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::OPMSUB ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VIADD ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VIADD || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	i.Value = 0x80000000 | ( i.Value & 0x01ffffff );
	Vu::Instruction::Recompile::IADD ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VISUB ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VISUB || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	i.Value = 0x80000000 | ( i.Value & 0x01ffffff );
	Vu::Instruction::Recompile::ISUB ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VIADDI ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VIADDI || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	i.Value = 0x80000000 | ( i.Value & 0x01ffffff );
	Vu::Instruction::Recompile::IADDI ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VIAND ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VIAND || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	i.Value = 0x80000000 | ( i.Value & 0x01ffffff );
	Vu::Instruction::Recompile::IAND ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VIOR ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VIOR || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	i.Value = 0x80000000 | ( i.Value & 0x01ffffff );
	Vu::Instruction::Recompile::IOR ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}



// VCALLMS //

static void Recompile::VCALLMS ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VCALLMS || defined INLINE_DEBUG_VU0 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	//cout << "\nhps2x64 ALERT: R5900/VU0: *** VCALLMS *** unimplemented";
	
	if ( VU0::_VU0->Running )
	{
		// a VU0 program is in progress already //
					
//#ifdef INLINE_DEBUG_VUCOM
//	debug << " (VIFSTOP)";
//#endif

#if defined INLINE_DEBUG_VCALLMS || defined INLINE_DEBUG_VU0 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\nR5900/VU0: VCALLMS while VU0 is already running!";
#endif

#ifdef VERBOSE_VCALLMS
		cout << "\nhps2x64 ALERT: R5900/VU0: VCALLMS while VU0 is already running!";
#endif
		
		// this is probably supposed to wait until vu0 is done and then execute
		r->NextPC = r->PC;
		return;
	}
					

	// set PC = IMM * 8
	VU0::_VU0->PC = i.Imm15 << 3;
	
	// need to set next pc too since this could get called in the middle of VU Main CPU loop
	VU0::_VU0->NextPC = VU0::_VU0->PC;
	
	// VU0 is now running
	VU0::_VU0->Running = 1;
	
	// ***todo*** also set VPU STAT COP2 r29 ??
	// set VBSx in VPU STAT to 1 (running)
	// note: bit 7 in register 29 is vif0 status
	VU0::_VU0->vi [ 29 ].uLo |= 1;
	
	// also set VIFx STAT to indicate program is running
	VU0::_VU0->VifRegs.STAT.VEW = 1;
	

#ifdef VERBOSE_MSCAL
	// debugging
	cout << "\nhps2x64: VU#0" << ": VCALLMS";
	cout << " StartPC=" << hex << VU0::_VU0->PC;
#endif

#ifdef INLINE_DEBUG_VUEXECUTE
	Vu::Instruction::Recompile::debug << "\r\n*** VCALLMS";
	Vu::Instruction::Recompile::debug << " VU#0";		// << Number;
	Vu::Instruction::Recompile::debug << " StartPC=" << hex << VU0::_VU0->PC;
	//Vu::Instruction::Recompile::debug << " VifCode=" << hex << VifCode.Value;
	Vu::Instruction::Recompile::debug << " ***";
#endif

}

static void Recompile::VCALLMSR ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VCALLMSR || defined INLINE_DEBUG_VU0 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	//cout << "\nhps2x64 ALERT: R5900/VU0: *** VCALLMSR *** unimplemented";
	
	if ( VU0::_VU0->Running )
	{
		// a VU0 program is in progress already //
					
//#ifdef INLINE_DEBUG_VUCOM
//	debug << " (VIFSTOP)";
//#endif

#if defined INLINE_DEBUG_VCALLMS || defined INLINE_DEBUG_VU0 || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\nR5900/VU0: VCALLMS while VU0 is already running!";
#endif

#ifdef VERBOSE_VCALLMSR
		cout << "\nhps2x64 ALERT: R5900/VU0: VCALLMSR while VU0 is already running!";
#endif
		
		// this is probably supposed to wait until vu0 is done and then execute
		r->NextPC = r->PC;
		return;
	}
					

	// set PC = IMM * 8
	VU0::_VU0->PC = VU0::_VU0->vi [ 27 ].uLo << 3;
	
	// need to set next pc too since this could get called in the middle of VU Main CPU loop
	VU0::_VU0->NextPC = VU0::_VU0->PC;
	
	// VU0 is now running
	VU0::_VU0->Running = 1;
	
	// ***todo*** also set VPU STAT COP2 r29 ??
	// set VBSx in VPU STAT to 1 (running)
	// note: bit 7 in register 29 is vif0 status
	VU0::_VU0->vi [ 29 ].uLo |= 1;
	
	// also set VIFx STAT to indicate program is running
	VU0::_VU0->VifRegs.STAT.VEW = 1;
	

#ifdef VERBOSE_MSCAL
	// debugging
	cout << "\nhps2x64: VU#0" << ": VCALLMSR";
	cout << " StartPC=" << hex << VU0::_VU0->PC;
#endif

#ifdef INLINE_DEBUG_VUEXECUTE
	Vu::Instruction::Recompile::debug << "\r\n*** VCALLMSR";
	Vu::Instruction::Recompile::debug << " VU#0";		// << Number;
	Vu::Instruction::Recompile::debug << " StartPC=" << hex << VU0::_VU0->PC;
	//Vu::Instruction::Recompile::debug << " VifCode=" << hex << VifCode.Value;
	Vu::Instruction::Recompile::debug << " ***";
#endif
	
}


// VFTOI //

static void Recompile::VFTOI0 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VFTOI0 || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::FTOI0 ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VFTOI4 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VFTOI4 || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::FTOI4 ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VFTOI12 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VFTOI12 || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::FTOI12 ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VFTOI15 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VFTOI15 || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::FTOI15 ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}


// VITOF //

static void Recompile::VITOF0 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VITOF0 || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::ITOF0 ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VITOF4 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VITOF4 || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::ITOF4 ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VITOF12 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VITOF12 || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::ITOF12 ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VITOF15 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VITOF15 || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::ITOF15 ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}





static void Recompile::VMOVE ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMOVE || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	i.Value = 0x80000000 | ( i.Value & 0x01ffffff );
	Vu::Instruction::Recompile::MOVE ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VLQI ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VLQI || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	i.Value = 0x80000000 | ( i.Value & 0x01ffffff );
	Vu::Instruction::Recompile::LQI ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VDIV ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VDIV || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	i.Value = 0x80000000 | ( i.Value & 0x01ffffff );
	Vu::Instruction::Recompile::DIV ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
	// in macro mode, set Q immediately for now
	VU0::_VU0->SetQ ();
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMTIR ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMTIR || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	i.Value = 0x80000000 | ( i.Value & 0x01ffffff );
	Vu::Instruction::Recompile::MTIR ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VRNEXT ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VRNEXT || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	i.Value = 0x80000000 | ( i.Value & 0x01ffffff );
	Vu::Instruction::Recompile::RNEXT ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VMR32 ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMR32 || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	i.Value = 0x80000000 | ( i.Value & 0x01ffffff );
	Vu::Instruction::Recompile::MR32 ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VSQI ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VSQI || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	i.Value = 0x80000000 | ( i.Value & 0x01ffffff );
	Vu::Instruction::Recompile::SQI ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VSQRT ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VSQRT || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	i.Value = 0x80000000 | ( i.Value & 0x01ffffff );
	Vu::Instruction::Recompile::SQRT ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
	// in macro mode, set Q immediately for now
	VU0::_VU0->SetQ ();
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMFIR ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMFIR || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	i.Value = 0x80000000 | ( i.Value & 0x01ffffff );
	Vu::Instruction::Recompile::MFIR ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VRGET ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VRGET || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	i.Value = 0x80000000 | ( i.Value & 0x01ffffff );
	Vu::Instruction::Recompile::RGET ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}




// VSUBA //

static void Recompile::VSUBA ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VSUBA || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::SUBA ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VSUBAi ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VSUBAi || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::SUBAi ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VSUBAq ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VSUBAq || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::SUBAq ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VSUBABCX ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VSUBABCX || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::SUBABCX ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VSUBABCY ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VSUBABCY || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::SUBABCY ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VSUBABCZ ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VSUBABCZ || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::SUBABCZ ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VSUBABCW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VSUBABCW || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::SUBABCW ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}



// VMADDA //

static void Recompile::VMADDA ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMADDA || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MADDA ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMADDAi ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMADDAi || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MADDAi ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMADDAq ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMADDAq || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MADDAq ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMADDABCX ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMADDABCX || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MADDABCX ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMADDABCY ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMADDABCY || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MADDABCY ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMADDABCZ ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMADDABCZ || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MADDABCZ ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMADDABCW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMADDABCW || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MADDABCW ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}




// VMSUBA //

static void Recompile::VMSUBA ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMSUBA || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MSUBA ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMSUBAi ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMSUBAi || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MSUBAi ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMSUBAq ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMSUBAq || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MSUBAq ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMSUBABCX ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMSUBABCX || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MSUBABCX ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMSUBABCY ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMSUBABCY || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MSUBABCY ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMSUBABCZ ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMSUBABCZ || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MSUBABCZ ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMSUBABCW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMSUBABCW || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MSUBABCW ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}





// VMULA //

static void Recompile::VMULA ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMULA || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MULA ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMULAi ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMULAi || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MULAi ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMULAq ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMULAq || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MULAq ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMULABCX ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMULABCX || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MULABCX ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMULABCY ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMULABCY || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MULABCY ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMULABCZ ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMULABCZ || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MULABCZ ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VMULABCW ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VMULABCW || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::MULABCW ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}





static void Recompile::VOPMULA ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VOPMULA || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::OPMULA ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VLQD ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VLQD || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	i.Value = 0x80000000 | ( i.Value & 0x01ffffff );
	Vu::Instruction::Recompile::LQD ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VRSQRT ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VRSQRT || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	i.Value = 0x80000000 | ( i.Value & 0x01ffffff );
	Vu::Instruction::Recompile::RSQRT ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
	// in macro mode, set Q immediately for now
	VU0::_VU0->SetQ ();
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VILWR ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VILWR || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	i.Value = 0x80000000 | ( i.Value & 0x01ffffff );
	Vu::Instruction::Recompile::ILWR ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VRINIT ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VRINIT || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	i.Value = 0x80000000 | ( i.Value & 0x01ffffff );
	Vu::Instruction::Recompile::RINIT ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VCLIP ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VCLIP || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	Vu::Instruction::Recompile::CLIP ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#else
	// update flags immediately for now
	VU0::_VU0->SetCurrentFlags ();
#endif
}

static void Recompile::VNOP ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VNOP || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VSQD ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VSQD || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	i.Value = 0x80000000 | ( i.Value & 0x01ffffff );
	Vu::Instruction::Recompile::SQD ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VWAITQ ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VWAITQ || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	i.Value = 0x80000000 | ( i.Value & 0x01ffffff );
	Vu::Instruction::Recompile::WAITQ ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VISWR ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VISWR || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	i.Value = 0x80000000 | ( i.Value & 0x01ffffff );
	Vu::Instruction::Recompile::ISWR ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}

static void Recompile::VRXOR ( Instruction::Format i )
{
#if defined INLINE_DEBUG_VRXOR || defined INLINE_DEBUG_VU0 // || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << setw( 8 ) << r->PC << " " << dec << r->CycleCount << " " << Print::PrintInstruction ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	i.Value = 0x80000000 | ( i.Value & 0x01ffffff );
	Vu::Instruction::Recompile::RXOR ( VU0::_VU0, (Vu::Instruction::Format&) i );
	
#ifdef ENABLE_STALLS
	// update pipeline in macro mode ??
	VU0::_VU0->MacroMode_AdvanceCycle ( i.Value );
#endif
}






static const Recompile::Function Recompile::FunctionList []
{
	// instructions on both R3000A and R5900
	// 1 + 56 + 6 = 63 instructions //
	Recompile::Invalid,
	Recompile::J, Recompile::JAL, Recompile::JR, Recompile::JALR, Recompile::BEQ, Recompile::BNE, Recompile::BGTZ, Recompile::BGEZ,
	Recompile::BLTZ, Recompile::BLEZ, Recompile::BGEZAL, Recompile::BLTZAL, Recompile::ADD, Recompile::ADDI, Recompile::ADDU, Recompile::ADDIU,
	Recompile::SUB, Recompile::SUBU, Recompile::MULT, Recompile::MULTU, Recompile::DIV, Recompile::DIVU, Recompile::AND, Recompile::ANDI,
	Recompile::OR, Recompile::ORI, Recompile::XOR, Recompile::XORI, Recompile::NOR, Recompile::LUI, Recompile::SLL, Recompile::SRL,
	Recompile::SRA, Recompile::SLLV, Recompile::SRLV, Recompile::SRAV, Recompile::SLT, Recompile::SLTI, Recompile::SLTU, Recompile::SLTIU,
	Recompile::LB, Recompile::LBU, Recompile::LH, Recompile::LHU, Recompile::LW, Recompile::LWL, Recompile::LWR, Recompile::SB,
	Recompile::SH, Recompile::SW, Recompile::SWL, Recompile::SWR, Recompile::MFHI, Recompile::MTHI, Recompile::MFLO, Recompile::MTLO,
	Recompile::MFC0, Recompile::MTC0, Recompile::CFC2, Recompile::CTC2, Recompile::SYSCALL, Recompile::BREAK,
	
	// instructions on R3000A ONLY
	//Recompile::MFC2, Recompile::MTC2, Recompile::LWC2, Recompile::SWC2, Recompile::RFE,
	//Recompile::RTPS, Recompile::RTPT, Recompile::CC, Recompile::CDP, Recompile::DCPL, Recompile::DPCS, Recompile::DPCT, Recompile::NCS,
	//Recompile::NCT, Recompile::NCDS, Recompile::NCDT, Recompile::NCCS, Recompile::NCCT, Recompile::GPF, Recompile::GPL, Recompile::AVSZ3,
	//Recompile::AVSZ4, Recompile::SQR, Recompile::OP, Recompile::NCLIP, Recompile::INTPL, Recompile::MVMVA
	
	// instructions on R5900 ONLY
	// (24*8) + 4 + 6 = 192 + 10 = 202 instructions //
	Recompile::BEQL, Recompile::BNEL, Recompile::BGEZL, Recompile::BGTZL, Recompile::BLEZL, Recompile::BLTZL, Recompile::BGEZALL, Recompile::BLTZALL,
	Recompile::DADD, Recompile::DADDI, Recompile::DADDU, Recompile::DADDIU, Recompile::DSUB, Recompile::DSUBU, Recompile::DSLL, Recompile::DSLL32,
	Recompile::DSLLV, Recompile::DSRA, Recompile::DSRA32, Recompile::DSRAV, Recompile::DSRL, Recompile::DSRL32, Recompile::DSRLV, Recompile::LD,
	Recompile::LDL, Recompile::LDR, Recompile::LWU, Recompile::LQ, Recompile::PREF, Recompile::SD, Recompile::SDL, Recompile::SDR,
	Recompile::SQ, Recompile::TEQ, Recompile::TEQI, Recompile::TNE, Recompile::TNEI, Recompile::TGE, Recompile::TGEI, Recompile::TGEU,
	Recompile::TGEIU, Recompile::TLT, Recompile::TLTI, Recompile::TLTU, Recompile::TLTIU, Recompile::MOVN, Recompile::MOVZ, Recompile::MULT1,
	Recompile::MULTU1, Recompile::DIV1, Recompile::DIVU1, Recompile::MADD, Recompile::MADD1, Recompile::MADDU, Recompile::MADDU1, Recompile::MFHI1,
	Recompile::MTHI1, Recompile::MFLO1, Recompile::MTLO1, Recompile::MFSA, Recompile::MTSA, Recompile::MTSAB, Recompile::MTSAH,
	Recompile::PABSH, Recompile::PABSW, Recompile::PADDB, Recompile::PADDH, Recompile::PADDW, Recompile::PADDSB, Recompile::PADDSH, Recompile::PADDSW,
	Recompile::PADDUB, Recompile::PADDUH, Recompile::PADDUW, Recompile::PADSBH, Recompile::PAND, Recompile::POR, Recompile::PXOR, Recompile::PNOR,
	Recompile::PCEQB, Recompile::PCEQH, Recompile::PCEQW, Recompile::PCGTB, Recompile::PCGTH, Recompile::PCGTW, Recompile::PCPYH, Recompile::PCPYLD,
	Recompile::PCPYUD, Recompile::PDIVBW, Recompile::PDIVUW, Recompile::PDIVW, Recompile::PEXCH, Recompile::PEXCW, Recompile::PEXEH, Recompile::PEXEW,
	Recompile::PEXT5, Recompile::PEXTLB, Recompile::PEXTLH, Recompile::PEXTLW, Recompile::PEXTUB, Recompile::PEXTUH, Recompile::PEXTUW, Recompile::PHMADH,
	Recompile::PHMSBH, Recompile::PINTEH, Recompile::PINTH, Recompile::PLZCW, Recompile::PMADDH, Recompile::PMADDW, Recompile::PMADDUW, Recompile::PMAXH,
	Recompile::PMAXW, Recompile::PMINH, Recompile::PMINW, Recompile::PMFHI, Recompile::PMFLO, Recompile::PMTHI, Recompile::PMTLO, Recompile::PMFHL_LH,
	Recompile::PMFHL_SH, Recompile::PMFHL_LW, Recompile::PMFHL_UW, Recompile::PMFHL_SLW, Recompile::PMTHL_LW, Recompile::PMSUBH, Recompile::PMSUBW, Recompile::PMULTH,
	Recompile::PMULTW, Recompile::PMULTUW, Recompile::PPAC5, Recompile::PPACB, Recompile::PPACH, Recompile::PPACW, Recompile::PREVH, Recompile::PROT3W,
	Recompile::PSLLH, Recompile::PSLLVW, Recompile::PSLLW, Recompile::PSRAH, Recompile::PSRAW, Recompile::PSRAVW, Recompile::PSRLH, Recompile::PSRLW,
	Recompile::PSRLVW, Recompile::PSUBB, Recompile::PSUBH, Recompile::PSUBW, Recompile::PSUBSB, Recompile::PSUBSH, Recompile::PSUBSW, Recompile::PSUBUB,
	Recompile::PSUBUH, Recompile::PSUBUW,
	Recompile::QFSRV, Recompile::SYNC,
	
	Recompile::DI, Recompile::EI, Recompile::ERET, Recompile::CACHE, Recompile::TLBP, Recompile::TLBR, Recompile::TLBWI, Recompile::TLBWR,
	Recompile::CFC0, Recompile::CTC0,
	
	Recompile::BC0T, Recompile::BC0TL, Recompile::BC0F, Recompile::BC0FL, Recompile::BC1T, Recompile::BC1TL, Recompile::BC1F, Recompile::BC1FL,
	Recompile::BC2T, Recompile::BC2TL, Recompile::BC2F, Recompile::BC2FL,
	
	Recompile::LWC1, Recompile::SWC1, Recompile::MFC1, Recompile::MTC1, Recompile::CFC1, Recompile::CTC1,
	Recompile::ABS_S, Recompile::ADD_S, Recompile::ADDA_S, Recompile::C_EQ_S, Recompile::C_F_S, Recompile::C_LE_S, Recompile::C_LT_S, Recompile::CVT_S_W,
	Recompile::CVT_W_S, Recompile::DIV_S, Recompile::MADD_S, Recompile::MADDA_S, Recompile::MAX_S, Recompile::MIN_S, Recompile::MOV_S, Recompile::MSUB_S,
	Recompile::MSUBA_S, Recompile::MUL_S, Recompile::MULA_S, Recompile::NEG_S, Recompile::RSQRT_S, Recompile::SQRT_S, Recompile::SUB_S, Recompile::SUBA_S,
	
	// VU macro mode instructions
	Recompile::QMFC2_NI, Recompile::QMFC2_I, Recompile::QMTC2_NI, Recompile::QMTC2_I, Recompile::LQC2, Recompile::SQC2,
	
	Recompile::VABS,
	Recompile::VADD, Recompile::VADDi, Recompile::VADDq, Recompile::VADDBCX, Recompile::VADDBCY, Recompile::VADDBCZ, Recompile::VADDBCW,
	Recompile::VADDA, Recompile::VADDAi, Recompile::VADDAq, Recompile::VADDABCX, Recompile::VADDABCY, Recompile::VADDABCZ, Recompile::VADDABCW,
	Recompile::VCALLMS, Recompile::VCALLMSR, Recompile::VCLIP, Recompile::VDIV,
	Recompile::VFTOI0, Recompile::VFTOI4, Recompile::VFTOI12, Recompile::VFTOI15,
	Recompile::VIADD, Recompile::VIADDI, Recompile::VIAND, Recompile::VILWR, Recompile::VIOR, Recompile::VISUB, Recompile::VISWR,
	Recompile::VITOF0, Recompile::VITOF4, Recompile::VITOF12, Recompile::VITOF15,
	Recompile::VLQD, Recompile::VLQI,
	
	Recompile::VMADD, Recompile::VMADDi, Recompile::VMADDq, Recompile::VMADDBCX, Recompile::VMADDBCY, Recompile::VMADDBCZ, Recompile::VMADDBCW,
	Recompile::VMADDA, Recompile::VMADDAi, Recompile::VMADDAq, Recompile::VMADDABCX, Recompile::VMADDABCY, Recompile::VMADDABCZ, Recompile::VMADDABCW,
	Recompile::VMAX, Recompile::VMAXi, Recompile::VMAXBCX, Recompile::VMAXBCY, Recompile::VMAXBCZ, Recompile::VMAXBCW,
	Recompile::VMFIR,
	Recompile::VMINI, Recompile::VMINIi, Recompile::VMINIBCX, Recompile::VMINIBCY, Recompile::VMINIBCZ, Recompile::VMINIBCW,
	Recompile::VMOVE, Recompile::VMR32,
	
	Recompile::VMSUB, Recompile::VMSUBi, Recompile::VMSUBq, Recompile::VMSUBBCX, Recompile::VMSUBBCY, Recompile::VMSUBBCZ, Recompile::VMSUBBCW,
	Recompile::VMSUBA, Recompile::VMSUBAi, Recompile::VMSUBAq, Recompile::VMSUBABCX, Recompile::VMSUBABCY, Recompile::VMSUBABCZ, Recompile::VMSUBABCW,
	Recompile::VMTIR,
	Recompile::VMUL, Recompile::VMULi, Recompile::VMULq, Recompile::VMULBCX, Recompile::VMULBCY, Recompile::VMULBCZ, Recompile::VMULBCW,
	Recompile::VMULA, Recompile::VMULAi, Recompile::VMULAq, Recompile::VMULABCX, Recompile::VMULABCY, Recompile::VMULABCZ, Recompile::VMULABCW,
	Recompile::VNOP, Recompile::VOPMSUB, Recompile::VOPMULA, Recompile::VRGET, Recompile::VRINIT, Recompile::VRNEXT, Recompile::VRSQRT, Recompile::VRXOR,
	Recompile::VSQD, Recompile::VSQI, Recompile::VSQRT,
	Recompile::VSUB, Recompile::VSUBi, Recompile::VSUBq, Recompile::VSUBBCX, Recompile::VSUBBCY, Recompile::VSUBBCZ, Recompile::VSUBBCW,
	Recompile::VSUBA, Recompile::VSUBAi, Recompile::VSUBAq, Recompile::VSUBABCX, Recompile::VSUBABCY, Recompile::VSUBABCZ, Recompile::VSUBABCW,
	Recompile::VWAITQ,
	Recompile::COP2
};





#ifdef _DEBUG_VERSION_
Debug::Log Recompile::debug;
#endif





// generates the lookup table
Recompile::Execute ( Cpu* pCpu )
{
	r = pCpu;
}



}

}



