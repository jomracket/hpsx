

#include "VU_Execute.h"
#include "VU_Print.h"
#include "PS2Float.h"
#include "PS2_GPU.h"

//#include <cmath>
#include <stdlib.h>

using namespace std;
using namespace Vu::Instruction;
using namespace PS2Float;


#ifdef _DEBUG_VERSION_
Debug::Log Execute::debug;
#endif


// will need this for accurate operation, and cycle accuracy is required
#define ENABLE_STALLS
#define ENABLE_INTDELAYSLOT


// enable debugging

#ifdef _DEBUG_VERSION_

#define INLINE_DEBUG_ENABLE

//#define INLINE_DEBUG_SPLIT

/*
//#define INLINE_DEBUG_STALLS


#define INLINE_DEBUG_VU
//#define INLINE_DEBUG_UNIMPLEMENTED
*/

#endif




const char Execute::XyzwLUT [ 4 ] = { 'x', 'y', 'z', 'w' };
const char* Execute::BCType [ 4 ] = { "F", "T", "FL", "TL" };






static void Execute::Start ()
{
	// make sure the lookup object has started (note: this can take a LONG time for R5900 currently)
	Lookup::Start ();
	
#ifdef INLINE_DEBUG_ENABLE

#ifdef INLINE_DEBUG_SPLIT
	// put debug output into a separate file
	debug.SetSplit ( true );
	debug.SetCombine ( false );
#endif

	debug.Create ( "PS2_VU_Execute_Log.txt" );
#endif
}



static void Execute::INVALID ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_INVALID || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << "INVALID" << "; " << hex << i.Value;
	debug << " vfx=" << hex << v->vf [ i.Fs ].fx << " vfy=" << v->vf [ i.Fs ].fy << " vfz=" << v->vf [ i.Fs ].fz << " vfw=" << v->vf [ i.Fs ].fw;
#endif

	cout << "\nhps2x64: ERROR: VU: Invalid instruction encountered";
}



//// *** UPPER instructions *** ////


// ABS //

static void Execute::ABS ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ABS || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " vfx=" << hex << v->vf [ i.Fs ].fx << " vfy=" << v->vf [ i.Fs ].fy << " vfz=" << v->vf [ i.Fs ].fz << " vfw=" << v->vf [ i.Fs ].fw;
#endif

#ifdef ENABLE_STALLS
	// set the source register(s)
	v->Set_SrcReg ( i.Value, i.Fs );
	
	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// todo: can set the MAC and STATUS flags registers as being modified also if needed later
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
	v->Set_DestReg_Upper ( i.Value, i.Ft );
#endif

	if ( i.destx )
	{
		v->vf [ i.Ft ].uw0 = v->vf [ i.Fs ].uw0 & ~0x80000000;
	}
	
	if ( i.desty )
	{
		v->vf [ i.Ft ].uw1 = v->vf [ i.Fs ].uw1 & ~0x80000000;
	}
	
	if ( i.destz )
	{
		v->vf [ i.Ft ].uw2 = v->vf [ i.Fs ].uw2 & ~0x80000000;
	}
	
	if ( i.destw )
	{
		v->vf [ i.Ft ].uw3 = v->vf [ i.Fs ].uw3 & ~0x80000000;
	}
	
	// flags affected: none

#if defined INLINE_DEBUG_ABS || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Ft=" << " vfx=" << hex << v->vf [ i.Ft ].fx << " vfy=" << v->vf [ i.Ft ].fy << " vfz=" << v->vf [ i.Ft ].fz << " vfw=" << v->vf [ i.Ft ].fw;
#endif
}





// ADD //

static void Execute::ADD ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ADD || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	// fd = fs + ft
	VuUpperOp ( v, i, PS2_Float_Add );
	
	// flags affected: zero, sign, [ overflow, underflow ]

#if defined INLINE_DEBUG_ADD || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::ADDi ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ADDI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " I=" << hex << v->vi [ 21 ].f << " " << v->vi [ 21 ].u;
#endif

	// fd = fs + I
	
	VuUpperOpI ( v, i, PS2_Float_Add );
	
	// flags affected: zero, sign, [ overflow, underflow ]

#if defined INLINE_DEBUG_ADDI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::ADDq ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ADDQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Q=" << hex << v->vi [ 22 ].f << " " << v->vi [ 22 ].u;
#endif

	// fd = fs + Q
	
	VuUpperOpQ ( v, i, PS2_Float_Add );
	
	// flags affected: zero, sign, [ overflow, underflow ]

#if defined INLINE_DEBUG_ADDQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::ADDBCX ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ADCBX || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	// fd = fs + ftbc
	
	VuUpperOpX ( v, i, PS2_Float_Add );

	// flags affected: zero, sign, [ overflow, underflow ]

#if defined INLINE_DEBUG_ADDBCX || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::ADDBCY ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ADDBCY || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	// fd = fs + ftbc
	
	VuUpperOpY ( v, i, PS2_Float_Add );
	
	// flags affected: zero, sign, [ overflow, underflow ]

#if defined INLINE_DEBUG_ADDBCY || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::ADDBCZ ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ADDBCZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	// fd = fs + ftbc
	
	VuUpperOpZ ( v, i, PS2_Float_Add );
	
	// flags affected: zero, sign, [ overflow, underflow ]

#if defined INLINE_DEBUG_ADDBCZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::ADDBCW ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ADDBCW || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	// fd = fs + ftbc
	VuUpperOpW ( v, i, PS2_Float_Add );
	
	// flags affected: zero, sign, [ overflow, underflow ]

#if defined INLINE_DEBUG_ADDBCW || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}




// SUB //

static void Execute::SUB ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_SUB || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	// fd = fs - ft
	VuUpperOp ( v, i, PS2_Float_Sub );
	
	// flags affected: zero, sign, [ overflow, underflow ]

#if defined INLINE_DEBUG_SUB || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::SUBi ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_SUBI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " I=" << hex << v->vi [ 21 ].f << " " << v->vi [ 21 ].u;
#endif

	VuUpperOpI ( v, i, PS2_Float_Sub );
	
#if defined INLINE_DEBUG_SUBI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::SUBq ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_SUBQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Q=" << hex << v->vi [ 22 ].f << " " << v->vi [ 22 ].u;
#endif

	VuUpperOpQ ( v, i, PS2_Float_Sub );
	
#if defined INLINE_DEBUG_SUBQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::SUBBCX ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_SUBX || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	VuUpperOpX ( v, i, PS2_Float_Sub );
	
#if defined INLINE_DEBUG_SUBX || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::SUBBCY ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_SUBY || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	VuUpperOpY ( v, i, PS2_Float_Sub );
	
#if defined INLINE_DEBUG_SUBY || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::SUBBCZ ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_SUBZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	VuUpperOpZ ( v, i, PS2_Float_Sub );
	
#if defined INLINE_DEBUG_SUBZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::SUBBCW ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_SUBW || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	VuUpperOpW ( v, i, PS2_Float_Sub );
	
#if defined INLINE_DEBUG_SUBW || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}




// MADD //

static void Execute::MADD ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MADD || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	VuUpperOp ( v, i, PS2_Float_Madd );
	
#if defined INLINE_DEBUG_MADD || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MADDi ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MADDI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " I=" << hex << v->vi [ 21 ].f << " " << v->vi [ 21 ].u;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	VuUpperOpI ( v, i, PS2_Float_Madd );
	
#if defined INLINE_DEBUG_MADDI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MADDq ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MADDQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Q=" << hex << v->vi [ 22 ].f << " " << v->vi [ 22 ].u;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	VuUpperOpQ ( v, i, PS2_Float_Madd );
	
#if defined INLINE_DEBUG_MADDQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MADDBCX ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MADDX || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	VuUpperOpX ( v, i, PS2_Float_Madd );
	
#if defined INLINE_DEBUG_MADDX || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MADDBCY ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MADDY || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	VuUpperOpY ( v, i, PS2_Float_Madd );
	
#if defined INLINE_DEBUG_MADDY || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MADDBCZ ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MADDZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	VuUpperOpZ ( v, i, PS2_Float_Madd );
	
#if defined INLINE_DEBUG_MADDZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MADDBCW ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MADDW || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	VuUpperOpW ( v, i, PS2_Float_Madd );
	
#if defined INLINE_DEBUG_MADDW || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}



// MSUB //

static void Execute::MSUB ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MSUB || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	VuUpperOp ( v, i, PS2_Float_Msub );
	
#if defined INLINE_DEBUG_MSUB || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MSUBi ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MSUBI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " I=" << hex << v->vi [ 21 ].f << " " << v->vi [ 21 ].u;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	VuUpperOpI ( v, i, PS2_Float_Msub );
	
#if defined INLINE_DEBUG_MSUBI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MSUBq ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MSUBQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Q=" << hex << v->vi [ 22 ].f << " " << v->vi [ 22 ].u;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	VuUpperOpQ ( v, i, PS2_Float_Msub );
	
#if defined INLINE_DEBUG_MSUBQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MSUBBCX ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MSUBX || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	VuUpperOpX ( v, i, PS2_Float_Msub );
	
#if defined INLINE_DEBUG_MSUBX || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MSUBBCY ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MSUBY || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	VuUpperOpY ( v, i, PS2_Float_Msub );
	
#if defined INLINE_DEBUG_MSUBY || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MSUBBCZ ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MSUBZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	VuUpperOpZ ( v, i, PS2_Float_Msub );
	
#if defined INLINE_DEBUG_MSUBZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MSUBBCW ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MSUBW || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	VuUpperOpW ( v, i, PS2_Float_Msub );
	
#if defined INLINE_DEBUG_MSUBW || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}



// MUL //

static void Execute::MUL ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MUL || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	VuUpperOp ( v, i, PS2_Float_Mul );
	
#if defined INLINE_DEBUG_MUL || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MULi ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MULI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " I=" << hex << v->vi [ 21 ].f << " " << v->vi [ 21 ].u;
#endif

	VuUpperOpI ( v, i, PS2_Float_Mul );
	
#if defined INLINE_DEBUG_MULI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MULq ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MULQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Q=" << hex << v->vi [ 22 ].f << " " << v->vi [ 22 ].u;
#endif

	VuUpperOpQ ( v, i, PS2_Float_Mul );
	
#if defined INLINE_DEBUG_MULQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MULBCX ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MULX || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	VuUpperOpX ( v, i, PS2_Float_Mul );
	
#if defined INLINE_DEBUG_MULX || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MULBCY ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MULY || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	VuUpperOpY ( v, i, PS2_Float_Mul );
	
#if defined INLINE_DEBUG_MULY || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MULBCZ ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MULZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	VuUpperOpZ ( v, i, PS2_Float_Mul );
	
#if defined INLINE_DEBUG_MULZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MULBCW ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MULW || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	VuUpperOpW ( v, i, PS2_Float_Mul );
	
#if defined INLINE_DEBUG_MULW || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}



// MAX //

static void Execute::MAX ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MAX || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

#ifdef ENABLE_STALLS
	// set the source register(s)
	v->Set_SrcRegs ( i.Value, i.Fs, i.Ft );
	

	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// todo: can set the MAC and STATUS flags registers as being modified also if needed later
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
	v->Set_DestReg_Upper ( i.Value, i.Fd );
#endif

	if ( i.destx )
	{
		v->vf [ i.Fd ].fx = PS2_Float_Max ( v->vf [ i.Fs ].fx, v->vf [ i.Ft ].fx );
	}
	
	if ( i.desty )
	{
		v->vf [ i.Fd ].fy = PS2_Float_Max ( v->vf [ i.Fs ].fy, v->vf [ i.Ft ].fy );
	}
	
	if ( i.destz )
	{
		v->vf [ i.Fd ].fz = PS2_Float_Max ( v->vf [ i.Fs ].fz, v->vf [ i.Ft ].fz );
	}
	
	if ( i.destw )
	{
		v->vf [ i.Fd ].fw = PS2_Float_Max ( v->vf [ i.Fs ].fw, v->vf [ i.Ft ].fw );
	}
	
#if defined INLINE_DEBUG_MAX || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
#endif
}

static void Execute::MAXi ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MAXI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " I=" << hex << v->vi [ 21 ].f << " " << v->vi [ 21 ].u;
#endif

#ifdef ENABLE_STALLS
	// set the source register(s)
	v->Set_SrcReg ( i.Value, i.Fs );
	
	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// todo: can set the MAC and STATUS flags registers as being modified also if needed later
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
	v->Set_DestReg_Upper ( i.Value, i.Fd );
#endif

	if ( i.destx )
	{
		v->vf [ i.Fd ].fx = PS2_Float_Max ( v->vf [ i.Fs ].fx, v->vi [ 21 ].f );
	}
	
	if ( i.desty )
	{
		v->vf [ i.Fd ].fy = PS2_Float_Max ( v->vf [ i.Fs ].fy, v->vi [ 21 ].f );
	}
	
	if ( i.destz )
	{
		v->vf [ i.Fd ].fz = PS2_Float_Max ( v->vf [ i.Fs ].fz, v->vi [ 21 ].f );
	}
	
	if ( i.destw )
	{
		v->vf [ i.Fd ].fw = PS2_Float_Max ( v->vf [ i.Fs ].fw, v->vi [ 21 ].f );
	}
	
#if defined INLINE_DEBUG_MAXI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
#endif
}

static void Execute::MAXBCX ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MAXX || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	float fx;

#ifdef ENABLE_STALLS
	// set the source register(s)
	v->Set_SrcRegsBC ( i.Value, i.Fs, i.Ft );
	
	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// todo: can set the MAC and STATUS flags registers as being modified also if needed later
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
	v->Set_DestReg_Upper ( i.Value, i.Fd );
#endif

	// don't want to overwrite and propagate...
	fx = v->vf [ i.Ft ].fx;

	if ( i.destx )
	{
		v->vf [ i.Fd ].fx = PS2_Float_Max ( v->vf [ i.Fs ].fx, fx );
	}
	
	if ( i.desty )
	{
		v->vf [ i.Fd ].fy = PS2_Float_Max ( v->vf [ i.Fs ].fy, fx );
	}
	
	if ( i.destz )
	{
		v->vf [ i.Fd ].fz = PS2_Float_Max ( v->vf [ i.Fs ].fz, fx );
	}
	
	if ( i.destw )
	{
		v->vf [ i.Fd ].fw = PS2_Float_Max ( v->vf [ i.Fs ].fw, fx );
	}
	
#if defined INLINE_DEBUG_MAXX || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
#endif
}

static void Execute::MAXBCY ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MAXY || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	float fy;

#ifdef ENABLE_STALLS
	// set the source register(s)
	v->Set_SrcRegsBC ( i.Value, i.Fs, i.Ft );
	
	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// todo: can set the MAC and STATUS flags registers as being modified also if needed later
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
	v->Set_DestReg_Upper ( i.Value, i.Fd );
#endif

	fy = v->vf [ i.Ft ].fy;

	if ( i.destx )
	{
		v->vf [ i.Fd ].fx = PS2_Float_Max ( v->vf [ i.Fs ].fx, fy );
	}
	
	if ( i.desty )
	{
		v->vf [ i.Fd ].fy = PS2_Float_Max ( v->vf [ i.Fs ].fy, fy );
	}
	
	if ( i.destz )
	{
		v->vf [ i.Fd ].fz = PS2_Float_Max ( v->vf [ i.Fs ].fz, fy );
	}
	
	if ( i.destw )
	{
		v->vf [ i.Fd ].fw = PS2_Float_Max ( v->vf [ i.Fs ].fw, fy );
	}
	
#if defined INLINE_DEBUG_MAXY || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
#endif
}

static void Execute::MAXBCZ ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MAXZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	float fz;

#ifdef ENABLE_STALLS
	// set the source register(s)
	v->Set_SrcRegsBC ( i.Value, i.Fs, i.Ft );
	
	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// todo: can set the MAC and STATUS flags registers as being modified also if needed later
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
	v->Set_DestReg_Upper ( i.Value, i.Fd );
#endif

	fz = v->vf [ i.Ft ].fz;

	if ( i.destx )
	{
		v->vf [ i.Fd ].fx = PS2_Float_Max ( v->vf [ i.Fs ].fx, fz );
	}
	
	if ( i.desty )
	{
		v->vf [ i.Fd ].fy = PS2_Float_Max ( v->vf [ i.Fs ].fy, fz );
	}
	
	if ( i.destz )
	{
		v->vf [ i.Fd ].fz = PS2_Float_Max ( v->vf [ i.Fs ].fz, fz );
	}
	
	if ( i.destw )
	{
		v->vf [ i.Fd ].fw = PS2_Float_Max ( v->vf [ i.Fs ].fw, fz );
	}
	
#if defined INLINE_DEBUG_MAXZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
#endif
}

static void Execute::MAXBCW ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MAXW || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	float fw;

#ifdef ENABLE_STALLS
	// set the source register(s)
	v->Set_SrcRegsBC ( i.Value, i.Fs, i.Ft );
	
	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// todo: can set the MAC and STATUS flags registers as being modified also if needed later
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
	v->Set_DestReg_Upper ( i.Value, i.Fd );
#endif

	fw = v->vf [ i.Ft ].fw;

	if ( i.destx )
	{
		v->vf [ i.Fd ].fx = PS2_Float_Max ( v->vf [ i.Fs ].fx, fw );
	}
	
	if ( i.desty )
	{
		v->vf [ i.Fd ].fy = PS2_Float_Max ( v->vf [ i.Fs ].fy, fw );
	}
	
	if ( i.destz )
	{
		v->vf [ i.Fd ].fz = PS2_Float_Max ( v->vf [ i.Fs ].fz, fw );
	}
	
	if ( i.destw )
	{
		v->vf [ i.Fd ].fw = PS2_Float_Max ( v->vf [ i.Fs ].fw, fw );
	}
	
#if defined INLINE_DEBUG_MAXW || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
#endif
}



// MINI //

static void Execute::MINI ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MINI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

#ifdef ENABLE_STALLS
	// set the source register(s)
	v->Set_SrcRegs ( i.Value, i.Fs, i.Ft );
	
	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// todo: can set the MAC and STATUS flags registers as being modified also if needed later
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
	v->Set_DestReg_Upper ( i.Value, i.Fd );
#endif

	if ( i.destx )
	{
		v->vf [ i.Fd ].fx = PS2_Float_Min ( v->vf [ i.Fs ].fx, v->vf [ i.Ft ].fx );
	}
	
	if ( i.desty )
	{
		v->vf [ i.Fd ].fy = PS2_Float_Min ( v->vf [ i.Fs ].fy, v->vf [ i.Ft ].fy );
	}
	
	if ( i.destz )
	{
		v->vf [ i.Fd ].fz = PS2_Float_Min ( v->vf [ i.Fs ].fz, v->vf [ i.Ft ].fz );
	}
	
	if ( i.destw )
	{
		v->vf [ i.Fd ].fw = PS2_Float_Min ( v->vf [ i.Fs ].fw, v->vf [ i.Ft ].fw );
	}
	
#if defined INLINE_DEBUG_MINI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
#endif
}

static void Execute::MINIi ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MINII || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " I=" << hex << v->vi [ 21 ].f << " " << v->vi [ 21 ].u;
#endif

#ifdef ENABLE_STALLS
	// set the source register(s)
	v->Set_SrcReg ( i.Value, i.Fs );
	
	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// todo: can set the MAC and STATUS flags registers as being modified also if needed later
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
	v->Set_DestReg_Upper ( i.Value, i.Fd );
#endif

	if ( i.destx )
	{
		v->vf [ i.Fd ].fx = PS2_Float_Min ( v->vf [ i.Fs ].fx, v->vi [ 21 ].f );
	}
	
	if ( i.desty )
	{
		v->vf [ i.Fd ].fy = PS2_Float_Min ( v->vf [ i.Fs ].fy, v->vi [ 21 ].f );
	}
	
	if ( i.destz )
	{
		v->vf [ i.Fd ].fz = PS2_Float_Min ( v->vf [ i.Fs ].fz, v->vi [ 21 ].f );
	}
	
	if ( i.destw )
	{
		v->vf [ i.Fd ].fw = PS2_Float_Min ( v->vf [ i.Fs ].fw, v->vi [ 21 ].f );
	}
	
#if defined INLINE_DEBUG_MINII || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
#endif
}

static void Execute::MINIBCX ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MINIX || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	float fx;

#ifdef ENABLE_STALLS
	// set the source register(s)
	v->Set_SrcRegsBC ( i.Value, i.Fs, i.Ft );
	
	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// todo: can set the MAC and STATUS flags registers as being modified also if needed later
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
	v->Set_DestReg_Upper ( i.Value, i.Fd );
#endif

	fx = v->vf [ i.Ft ].fx;

	if ( i.destx )
	{
		v->vf [ i.Fd ].fx = PS2_Float_Min ( v->vf [ i.Fs ].fx, fx );
	}
	
	if ( i.desty )
	{
		v->vf [ i.Fd ].fy = PS2_Float_Min ( v->vf [ i.Fs ].fy, fx );
	}
	
	if ( i.destz )
	{
		v->vf [ i.Fd ].fz = PS2_Float_Min ( v->vf [ i.Fs ].fz, fx );
	}
	
	if ( i.destw )
	{
		v->vf [ i.Fd ].fw = PS2_Float_Min ( v->vf [ i.Fs ].fw, fx );
	}
	
#if defined INLINE_DEBUG_MINIX || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
#endif
}

static void Execute::MINIBCY ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MINIY || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	float fy;

#ifdef ENABLE_STALLS
	// set the source register(s)
	v->Set_SrcRegsBC ( i.Value, i.Fs, i.Ft );
	
	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// todo: can set the MAC and STATUS flags registers as being modified also if needed later
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
	v->Set_DestReg_Upper ( i.Value, i.Fd );
#endif

	fy = v->vf [ i.Ft ].fy;

	if ( i.destx )
	{
		v->vf [ i.Fd ].fx = PS2_Float_Min ( v->vf [ i.Fs ].fx, fy );
	}
	
	if ( i.desty )
	{
		v->vf [ i.Fd ].fy = PS2_Float_Min ( v->vf [ i.Fs ].fy, fy );
	}
	
	if ( i.destz )
	{
		v->vf [ i.Fd ].fz = PS2_Float_Min ( v->vf [ i.Fs ].fz, fy );
	}
	
	if ( i.destw )
	{
		v->vf [ i.Fd ].fw = PS2_Float_Min ( v->vf [ i.Fs ].fw, fy );
	}
	
#if defined INLINE_DEBUG_MINIY || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
#endif
}

static void Execute::MINIBCZ ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MINIZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	float fz;

#ifdef ENABLE_STALLS
	// set the source register(s)
	v->Set_SrcRegsBC ( i.Value, i.Fs, i.Ft );
	
	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// todo: can set the MAC and STATUS flags registers as being modified also if needed later
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
	v->Set_DestReg_Upper ( i.Value, i.Fd );
#endif

	fz = v->vf [ i.Ft ].fz;

	if ( i.destx )
	{
		v->vf [ i.Fd ].fx = PS2_Float_Min ( v->vf [ i.Fs ].fx, fz );
	}
	
	if ( i.desty )
	{
		v->vf [ i.Fd ].fy = PS2_Float_Min ( v->vf [ i.Fs ].fy, fz );
	}
	
	if ( i.destz )
	{
		v->vf [ i.Fd ].fz = PS2_Float_Min ( v->vf [ i.Fs ].fz, fz );
	}
	
	if ( i.destw )
	{
		v->vf [ i.Fd ].fw = PS2_Float_Min ( v->vf [ i.Fs ].fw, fz );
	}
	
#if defined INLINE_DEBUG_MINIZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
#endif
}

static void Execute::MINIBCW ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MINIW || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	float fw;

#ifdef ENABLE_STALLS
	// set the source register(s)
	v->Set_SrcRegsBC ( i.Value, i.Fs, i.Ft );
	
	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// todo: can set the MAC and STATUS flags registers as being modified also if needed later
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
	v->Set_DestReg_Upper ( i.Value, i.Fd );
#endif

	fw = v->vf [ i.Ft ].fw;

	if ( i.destx )
	{
		v->vf [ i.Fd ].fx = PS2_Float_Min ( v->vf [ i.Fs ].fx, fw );
	}
	
	if ( i.desty )
	{
		v->vf [ i.Fd ].fy = PS2_Float_Min ( v->vf [ i.Fs ].fy, fw );
	}
	
	if ( i.destz )
	{
		v->vf [ i.Fd ].fz = PS2_Float_Min ( v->vf [ i.Fs ].fz, fw );
	}
	
	if ( i.destw )
	{
		v->vf [ i.Fd ].fw = PS2_Float_Min ( v->vf [ i.Fs ].fw, fw );
	}
	
#if defined INLINE_DEBUG_MINIW || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
#endif
}








// ITOF //

static void Execute::ITOF0 ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ITOF0 || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " vfx=" << dec << v->vf [ i.Fs ].sx << " vfy=" << v->vf [ i.Fs ].sy << " vfz=" << v->vf [ i.Fs ].sz << " vfw=" << v->vf [ i.Fs ].sw;
#endif

#ifdef ENABLE_STALLS
	// set the source register(s)
	v->Set_SrcReg ( i.Value, i.Fs );
	
	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// todo: can set the MAC and STATUS flags registers as being modified also if needed later
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
	v->Set_DestReg_Upper ( i.Value, i.Ft );
#endif

	if ( i.destx )
	{
		v->vf [ i.Ft ].fx = (float) v->vf [ i.Fs ].sw0;
	}
	
	if ( i.desty )
	{
		v->vf [ i.Ft ].fy = (float) v->vf [ i.Fs ].sw1;
	}
	
	if ( i.destz )
	{
		v->vf [ i.Ft ].fz = (float) v->vf [ i.Fs ].sw2;
	}
	
	if ( i.destw )
	{
		v->vf [ i.Ft ].fw = (float) v->vf [ i.Fs ].sw3;
	}
	
	// flags affected: none

#if defined INLINE_DEBUG_ITOF0 || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Ft=" << " vfx=" << dec << v->vf [ i.Ft ].fx << " vfy=" << v->vf [ i.Ft ].fy << " vfz=" << v->vf [ i.Ft ].fz << " vfw=" << v->vf [ i.Ft ].fw;
#endif
}

static void Execute::FTOI0 ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_FTOI0 || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " vfx=" << dec << v->vf [ i.Fs ].fx << " vfy=" << v->vf [ i.Fs ].fy << " vfz=" << v->vf [ i.Fs ].fz << " vfw=" << v->vf [ i.Fs ].fw;
#endif

#ifdef ENABLE_STALLS
	// set the source register(s)
	v->Set_SrcReg ( i.Value, i.Fs );
	
	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// todo: can set the MAC and STATUS flags registers as being modified also if needed later
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
	v->Set_DestReg_Upper ( i.Value, i.Ft );
#endif

	if ( i.destx )
	{
		v->vf [ i.Ft ].sw0 = PS2_Float_ToInteger ( v->vf [ i.Fs ].fx );
	}
	
	if ( i.desty )
	{
		v->vf [ i.Ft ].sw1 = PS2_Float_ToInteger ( v->vf [ i.Fs ].fy );
	}
	
	if ( i.destz )
	{
		v->vf [ i.Ft ].sw2 = PS2_Float_ToInteger ( v->vf [ i.Fs ].fz );
	}
	
	if ( i.destw )
	{
		v->vf [ i.Ft ].sw3 = PS2_Float_ToInteger ( v->vf [ i.Fs ].fw );
	}
	
	// flags affected: none

#if defined INLINE_DEBUG_FTOI0 || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Ft=" << " vfx=" << dec << v->vf [ i.Ft ].sx << " vfy=" << v->vf [ i.Ft ].sy << " vfz=" << v->vf [ i.Ft ].sz << " vfw=" << v->vf [ i.Ft ].sw;
#endif
}

static void Execute::ITOF4 ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ITOF4 || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " vfx=" << dec << v->vf [ i.Fs ].sx << " vfy=" << v->vf [ i.Fs ].sy << " vfz=" << v->vf [ i.Fs ].sz << " vfw=" << v->vf [ i.Fs ].sw;
#endif

	static const float c_fMultiplier = 1.0f / 16.0f;

#ifdef ENABLE_STALLS
	// set the source register(s)
	v->Set_SrcReg ( i.Value, i.Fs );
	
	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// todo: can set the MAC and STATUS flags registers as being modified also if needed later
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
	v->Set_DestReg_Upper ( i.Value, i.Ft );
#endif

	if ( i.destx )
	{
		v->vf [ i.Ft ].fx = ( (float) v->vf [ i.Fs ].sw0 ) * c_fMultiplier;
	}
	
	if ( i.desty )
	{
		v->vf [ i.Ft ].fy = ( (float) v->vf [ i.Fs ].sw1 ) * c_fMultiplier;
	}
	
	if ( i.destz )
	{
		v->vf [ i.Ft ].fz = ( (float) v->vf [ i.Fs ].sw2 ) * c_fMultiplier;
	}
	
	if ( i.destw )
	{
		v->vf [ i.Ft ].fw = ( (float) v->vf [ i.Fs ].sw3 ) * c_fMultiplier;
	}
	
	// flags affected: none
	
#if defined INLINE_DEBUG_ITOF4 || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Ft=" << " vfx=" << dec << v->vf [ i.Ft ].fx << " vfy=" << v->vf [ i.Ft ].fy << " vfz=" << v->vf [ i.Ft ].fz << " vfw=" << v->vf [ i.Ft ].fw;
#endif
}

static void Execute::FTOI4 ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_FTOI4 || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " vfx=" << dec << v->vf [ i.Fs ].fx << " vfy=" << v->vf [ i.Fs ].fy << " vfz=" << v->vf [ i.Fs ].fz << " vfw=" << v->vf [ i.Fs ].fw;
#endif

	static const float c_fMultiplier = 16.0f;
	
#ifdef ENABLE_STALLS
	// set the source register(s)
	v->Set_SrcReg ( i.Value, i.Fs );
	
	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// todo: can set the MAC and STATUS flags registers as being modified also if needed later
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
	v->Set_DestReg_Upper ( i.Value, i.Ft );
#endif

	if ( i.destx )
	{
		v->vf [ i.Ft ].sw0 = PS2_Float_ToInteger ( v->vf [ i.Fs ].fx * c_fMultiplier );
	}
	
	if ( i.desty )
	{
		v->vf [ i.Ft ].sw1 = PS2_Float_ToInteger ( v->vf [ i.Fs ].fy * c_fMultiplier );
	}
	
	if ( i.destz )
	{
		v->vf [ i.Ft ].sw2 = PS2_Float_ToInteger ( v->vf [ i.Fs ].fz * c_fMultiplier );
	}
	
	if ( i.destw )
	{
		v->vf [ i.Ft ].sw3 = PS2_Float_ToInteger ( v->vf [ i.Fs ].fw * c_fMultiplier );
	}
	
	// flags affected: none

#if defined INLINE_DEBUG_FTOI4 || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Ft=" << " vfx=" << dec << v->vf [ i.Ft ].sx << " vfy=" << v->vf [ i.Ft ].sy << " vfz=" << v->vf [ i.Ft ].sz << " vfw=" << v->vf [ i.Ft ].sw;
#endif
}

static void Execute::ITOF12 ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ITOF12 || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " vfx=" << dec << v->vf [ i.Fs ].sx << " vfy=" << v->vf [ i.Fs ].sy << " vfz=" << v->vf [ i.Fs ].sz << " vfw=" << v->vf [ i.Fs ].sw;
#endif

	static const float c_fMultiplier = 1.0f / 4096.0f;

#ifdef ENABLE_STALLS
	// set the source register(s)
	v->Set_SrcReg ( i.Value, i.Fs );
	
	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// todo: can set the MAC and STATUS flags registers as being modified also if needed later
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
	v->Set_DestReg_Upper ( i.Value, i.Ft );
#endif

	if ( i.destx )
	{
		v->vf [ i.Ft ].fx = ( (float) v->vf [ i.Fs ].sw0 ) * c_fMultiplier;
	}
	
	if ( i.desty )
	{
		v->vf [ i.Ft ].fy = ( (float) v->vf [ i.Fs ].sw1 ) * c_fMultiplier;
	}
	
	if ( i.destz )
	{
		v->vf [ i.Ft ].fz = ( (float) v->vf [ i.Fs ].sw2 ) * c_fMultiplier;
	}
	
	if ( i.destw )
	{
		v->vf [ i.Ft ].fw = ( (float) v->vf [ i.Fs ].sw3 ) * c_fMultiplier;
	}
	
	// flags affected: none
	
#if defined INLINE_DEBUG_ITOF12 || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Ft=" << " vfx=" << dec << v->vf [ i.Ft ].fx << " vfy=" << v->vf [ i.Ft ].fy << " vfz=" << v->vf [ i.Ft ].fz << " vfw=" << v->vf [ i.Ft ].fw;
#endif
}

static void Execute::FTOI12 ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_FTOI12 || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " vfx=" << dec << v->vf [ i.Fs ].fx << " vfy=" << v->vf [ i.Fs ].fy << " vfz=" << v->vf [ i.Fs ].fz << " vfw=" << v->vf [ i.Fs ].fw;
#endif

	static const float c_fMultiplier = 4096.0f;
	
#ifdef ENABLE_STALLS
	// set the source register(s)
	v->Set_SrcReg ( i.Value, i.Fs );
	
	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// todo: can set the MAC and STATUS flags registers as being modified also if needed later
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
	v->Set_DestReg_Upper ( i.Value, i.Ft );
#endif

	if ( i.destx )
	{
		v->vf [ i.Ft ].sw0 = PS2_Float_ToInteger ( v->vf [ i.Fs ].fx * c_fMultiplier );
	}
	
	if ( i.desty )
	{
		v->vf [ i.Ft ].sw1 = PS2_Float_ToInteger ( v->vf [ i.Fs ].fy * c_fMultiplier );
	}
	
	if ( i.destz )
	{
		v->vf [ i.Ft ].sw2 = PS2_Float_ToInteger ( v->vf [ i.Fs ].fz * c_fMultiplier );
	}
	
	if ( i.destw )
	{
		v->vf [ i.Ft ].sw3 = PS2_Float_ToInteger ( v->vf [ i.Fs ].fw * c_fMultiplier );
	}
	
	// flags affected: none

#if defined INLINE_DEBUG_FTOI12 || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Ft=" << " vfx=" << dec << v->vf [ i.Ft ].sx << " vfy=" << v->vf [ i.Ft ].sy << " vfz=" << v->vf [ i.Ft ].sz << " vfw=" << v->vf [ i.Ft ].sw;
#endif
}

static void Execute::ITOF15 ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ITOF15 || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " vfx=" << dec << v->vf [ i.Fs ].sx << " vfy=" << v->vf [ i.Fs ].sy << " vfz=" << v->vf [ i.Fs ].sz << " vfw=" << v->vf [ i.Fs ].sw;
#endif

	static const float c_fMultiplier = 1.0f / 32768.0f;

#ifdef ENABLE_STALLS
	// set the source register(s)
	v->Set_SrcReg ( i.Value, i.Fs );
	
	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// todo: can set the MAC and STATUS flags registers as being modified also if needed later
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
	v->Set_DestReg_Upper ( i.Value, i.Ft );
#endif

	if ( i.destx )
	{
		v->vf [ i.Ft ].fx = ( (float) v->vf [ i.Fs ].sw0 ) * c_fMultiplier;
	}
	
	if ( i.desty )
	{
		v->vf [ i.Ft ].fy = ( (float) v->vf [ i.Fs ].sw1 ) * c_fMultiplier;
	}
	
	if ( i.destz )
	{
		v->vf [ i.Ft ].fz = ( (float) v->vf [ i.Fs ].sw2 ) * c_fMultiplier;
	}
	
	if ( i.destw )
	{
		v->vf [ i.Ft ].fw = ( (float) v->vf [ i.Fs ].sw3 ) * c_fMultiplier;
	}
	
	// flags affected: none
	
#if defined INLINE_DEBUG_ITOF15 || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Ft=" << " vfx=" << dec << v->vf [ i.Ft ].fx << " vfy=" << v->vf [ i.Ft ].fy << " vfz=" << v->vf [ i.Ft ].fz << " vfw=" << v->vf [ i.Ft ].fw;
#endif
}

static void Execute::FTOI15 ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_FTOI15 || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " vfx=" << dec << v->vf [ i.Fs ].fx << " vfy=" << v->vf [ i.Fs ].fy << " vfz=" << v->vf [ i.Fs ].fz << " vfw=" << v->vf [ i.Fs ].fw;
#endif

	static const float c_fMultiplier = 32768.0f;
	
#ifdef ENABLE_STALLS
	// set the source register(s)
	v->Set_SrcReg ( i.Value, i.Fs );
	
	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// todo: can set the MAC and STATUS flags registers as being modified also if needed later
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
	v->Set_DestReg_Upper ( i.Value, i.Ft );
#endif

	if ( i.destx )
	{
		v->vf [ i.Ft ].sw0 = PS2_Float_ToInteger ( v->vf [ i.Fs ].fx * c_fMultiplier );
	}
	
	if ( i.desty )
	{
		v->vf [ i.Ft ].sw1 = PS2_Float_ToInteger ( v->vf [ i.Fs ].fy * c_fMultiplier );
	}
	
	if ( i.destz )
	{
		v->vf [ i.Ft ].sw2 = PS2_Float_ToInteger ( v->vf [ i.Fs ].fz * c_fMultiplier );
	}
	
	if ( i.destw )
	{
		v->vf [ i.Ft ].sw3 = PS2_Float_ToInteger ( v->vf [ i.Fs ].fw * c_fMultiplier );
	}
	
	// flags affected: none

#if defined INLINE_DEBUG_FTOI15 || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Ft=" << " vfx=" << dec << v->vf [ i.Ft ].sx << " vfy=" << v->vf [ i.Ft ].sy << " vfz=" << v->vf [ i.Ft ].sz << " vfw=" << v->vf [ i.Ft ].sw;
#endif
}





// ADDA //

static void Execute::ADDA ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ADDA || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	// fd = fs + ft
	VuUpperOp_A ( v, i, PS2_Float_Add );
	
#if defined INLINE_DEBUG_ADDA || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::ADDAi ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ADDAI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " I=" << hex << v->vi [ 21 ].f << " " << v->vi [ 21 ].u;
#endif

	VuUpperOpI_A ( v, i, PS2_Float_Add );
	
#if defined INLINE_DEBUG_ADDAI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::ADDAq ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ADDAQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Q=" << hex << v->vi [ 22 ].f << " " << v->vi [ 22 ].u;
#endif

	VuUpperOpQ_A ( v, i, PS2_Float_Add );
	
#if defined INLINE_DEBUG_ADDAQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::ADDABCX ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ADDAX || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	VuUpperOpX_A ( v, i, PS2_Float_Add );
	
#if defined INLINE_DEBUG_ADDAX || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::ADDABCY ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ADDAY || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	VuUpperOpY_A ( v, i, PS2_Float_Add );
	
#if defined INLINE_DEBUG_ADDAY || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::ADDABCZ ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ADDAZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	VuUpperOpZ_A ( v, i, PS2_Float_Add );
	
#if defined INLINE_DEBUG_ADDAZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::ADDABCW ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ADDAW || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	VuUpperOpW_A ( v, i, PS2_Float_Add );
	
#if defined INLINE_DEBUG_ADDAW || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}




// SUBA //

static void Execute::SUBA ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_SUBA || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	VuUpperOp_A ( v, i, PS2_Float_Sub );
	
#if defined INLINE_DEBUG_SUBA || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::SUBAi ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_SUBAI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " I=" << hex << v->vi [ 21 ].f << " " << v->vi [ 21 ].u;
#endif

	VuUpperOpI_A ( v, i, PS2_Float_Sub );
	
#if defined INLINE_DEBUG_SUBAI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::SUBAq ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_SUBAQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Q=" << hex << v->vi [ 22 ].f << " " << v->vi [ 22 ].u;
#endif

	VuUpperOpQ_A ( v, i, PS2_Float_Sub );
	
#if defined INLINE_DEBUG_SUBAQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::SUBABCX ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_SUBAX || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	VuUpperOpX_A ( v, i, PS2_Float_Sub );
	
#if defined INLINE_DEBUG_SUBAX || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::SUBABCY ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_SUBAY || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	VuUpperOpY_A ( v, i, PS2_Float_Sub );
	
#if defined INLINE_DEBUG_SUBAY || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::SUBABCZ ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_SUBAZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	VuUpperOpZ_A ( v, i, PS2_Float_Sub );
	
#if defined INLINE_DEBUG_SUBAZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::SUBABCW ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_SUBAW || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	VuUpperOpW_A ( v, i, PS2_Float_Sub );
	
#if defined INLINE_DEBUG_SUBAW || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}



// MADDA //

static void Execute::MADDA ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MADDA || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	VuUpperOp_A ( v, i, PS2_Float_Madd );
	
#if defined INLINE_DEBUG_MADDA || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MADDAi ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MADDAI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " I=" << hex << v->vi [ 21 ].f << " " << v->vi [ 21 ].u;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	VuUpperOpI_A ( v, i, PS2_Float_Madd );
	
#if defined INLINE_DEBUG_MADDAI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MADDAq ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MADDAQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Q=" << hex << v->vi [ 22 ].f << " " << v->vi [ 22 ].u;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	VuUpperOpQ_A ( v, i, PS2_Float_Madd );
	
#if defined INLINE_DEBUG_MADDAQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MADDABCX ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MADDAX || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	VuUpperOpX_A ( v, i, PS2_Float_Madd );
	
#if defined INLINE_DEBUG_MADDAX || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MADDABCY ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MADDAY || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	VuUpperOpY_A ( v, i, PS2_Float_Madd );
	
#if defined INLINE_DEBUG_MADDAY || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MADDABCZ ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MADDAZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	VuUpperOpZ_A ( v, i, PS2_Float_Madd );
	
#if defined INLINE_DEBUG_MADDAZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MADDABCW ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MADDAW || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	VuUpperOpW_A ( v, i, PS2_Float_Madd );
	
#if defined INLINE_DEBUG_MADDAW || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}


// MSUBA //

static void Execute::MSUBA ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MSUBA || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	VuUpperOp_A ( v, i, PS2_Float_Msub );
	
#if defined INLINE_DEBUG_MSUBA || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MSUBAi ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MSUBAI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " I=" << hex << v->vi [ 21 ].f << " " << v->vi [ 21 ].u;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	VuUpperOpI_A ( v, i, PS2_Float_Msub );
	
#if defined INLINE_DEBUG_MSUBAI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MSUBAq ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MSUBAQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Q=" << hex << v->vi [ 22 ].f << " " << v->vi [ 22 ].u;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	VuUpperOpQ_A ( v, i, PS2_Float_Msub );
	
#if defined INLINE_DEBUG_MSUBAQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MSUBABCX ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MSUBAX || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	VuUpperOpX_A ( v, i, PS2_Float_Msub );
	
#if defined INLINE_DEBUG_MSUBAX || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MSUBABCY ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MSUBAY || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	VuUpperOpY_A ( v, i, PS2_Float_Msub );
	
#if defined INLINE_DEBUG_MSUBAY || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MSUBABCZ ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MSUBAZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	VuUpperOpZ_A ( v, i, PS2_Float_Msub );
	
#if defined INLINE_DEBUG_MSUBAZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MSUBABCW ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MSUBAW || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	VuUpperOpW_A ( v, i, PS2_Float_Msub );
	
#if defined INLINE_DEBUG_MSUBAW || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}



// MULA //

static void Execute::MULA ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MULA || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	VuUpperOp_A ( v, i, PS2_Float_Mul );
	
#if defined INLINE_DEBUG_MULA || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MULAi ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MULAI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " I=" << hex << v->vi [ 21 ].f << " " << v->vi [ 21 ].u;
#endif

	VuUpperOpI_A ( v, i, PS2_Float_Mul );
	
#if defined INLINE_DEBUG_MULAI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MULAq ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MULAQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Q=" << hex << v->vi [ 22 ].f << " " << v->vi [ 22 ].u;
#endif

	VuUpperOpQ_A ( v, i, PS2_Float_Mul );
	
#if defined INLINE_DEBUG_MULAQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MULABCX ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MULAX || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	VuUpperOpX_A ( v, i, PS2_Float_Mul );
	
#if defined INLINE_DEBUG_MULAX || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MULABCY ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MULAY || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	VuUpperOpY_A ( v, i, PS2_Float_Mul );
	
#if defined INLINE_DEBUG_MULAY || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MULABCZ ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MULAZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	VuUpperOpZ_A ( v, i, PS2_Float_Mul );
	
#if defined INLINE_DEBUG_MULAZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::MULABCW ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MULAW || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << " Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	VuUpperOpW_A ( v, i, PS2_Float_Mul );
	
#if defined INLINE_DEBUG_MULAW || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}







// other upper instructions //

static void Execute::CLIP ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_CLIP || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << "Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	FloatLong fw_plus, fw_minus, fw;
	float fx, fy, fz;
	
#ifdef ENABLE_STALLS
	// set the source register(s)
	v->Set_SrcRegs ( i.Value, i.Fs, i.Ft );
	
	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// todo: can set the MAC and STATUS flags registers as being modified also if needed later
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
#endif

	
	fx = v->vf [ i.Fs ].fx;
	fy = v->vf [ i.Fs ].fy;
	fz = v->vf [ i.Fs ].fz;
	fw.f = v->vf [ i.Ft ].fw;
	
	ClampValue_f ( fx );
	ClampValue_f ( fy );
	ClampValue_f ( fz );
	ClampValue_f ( fw.f );

	fw_plus.l = fw.l & 0x7fffffff;
	fw_minus.l = fw.l | 0x80000000;
	
	
	
	// read clipping flag
	//v->ClippingFlag.Value = v->vi [ 18 ].u;
	//v->ClippingFlag.Value <<= 6;
	v->ClippingFlag.Value = 0;
	
	//if ( v->vf [ i.Fs ].fx > fw_plus.f ) v->ClippingFlag.x_plus0 = 1; else if ( v->vf [ i.Fs ].fx < fw_minus.f ) v->ClippingFlag.x_minus0 = 1;
	//if ( v->vf [ i.Fs ].fy > fw_plus.f ) v->ClippingFlag.y_plus0 = 1; else if ( v->vf [ i.Fs ].fy < fw_minus.f ) v->ClippingFlag.y_minus0 = 1;
	//if ( v->vf [ i.Fs ].fz > fw_plus.f ) v->ClippingFlag.z_plus0 = 1; else if ( v->vf [ i.Fs ].fz < fw_minus.f ) v->ClippingFlag.z_minus0 = 1;
	
	if ( fx > fw_plus.f ) v->ClippingFlag.x_plus0 = 1; else if ( fx < fw_minus.f ) v->ClippingFlag.x_minus0 = 1;
	if ( fy > fw_plus.f ) v->ClippingFlag.y_plus0 = 1; else if ( fy < fw_minus.f ) v->ClippingFlag.y_minus0 = 1;
	if ( fz > fw_plus.f ) v->ClippingFlag.z_plus0 = 1; else if ( fz < fw_minus.f ) v->ClippingFlag.z_minus0 = 1;
	
	// set 24 bits to the clipping flag
	//v->vi [ 18 ].u = v->ClippingFlag.Value & 0xffffff;
	
	v->FlagSave [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].FlagsAffected = VU::RF_UPDATE_CLIP;
	v->FlagSave [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].ClippingFlag = v->ClippingFlag.Value;
	
#if defined INLINE_DEBUG_CLIP || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " ClippingFlag=" << hex << v->ClippingFlag.Value;
#endif
}



static void Execute::OPMULA ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_OPMULA || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << "Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
#endif

	// ACC_x = fs_y * ft_z
	// ACC_y = fs_z * ft_x
	// ACC_z = fs_x * ft_y
	VuUpperOp_OPMULA ( v, i, PS2_Float_Mul );

#if defined INLINE_DEBUG_OPMULA || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}

static void Execute::OPMSUB ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_OPMSUB || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << "Fs= x=" << hex << v->vf [ i.Fs ].fx << " y=" << v->vf [ i.Fs ].fy << " z=" << v->vf [ i.Fs ].fz << " w=" << v->vf [ i.Fs ].fw;
	debug << "Ft= x=" << hex << v->vf [ i.Ft ].fx << " y=" << v->vf [ i.Ft ].fy << " z=" << v->vf [ i.Ft ].fz << " w=" << v->vf [ i.Ft ].fw;
	debug << " ACC= x=" << v->dACC [ 0 ].f << " y=" << v->dACC [ 1 ].f << " z=" << v->dACC [ 2 ].f << " w=" << v->dACC [ 3 ].f;
#endif

	/*
	// must store result in intermediate variables before saving into registers
	float fd_x, fd_y, fd_z;

	// fd_x = ACC_x - fs_y * ft_z
	fd_x = PS2_Float_Msub ( v->dACC [ 0 ].f, v->vf [ i.Fd ].fx, v->vf [ i.Fs ].fy,  v->vf [ i.Ft ].fz, 3, & v->vi [ 16 ].sLo, & v->vi [ 17 ].sLo );
	
	// fd_y = ACC_y - fs_x * ft_z
	fd_y = PS2_Float_Msub ( v->dACC [ 1 ].f, v->vf [ i.Fd ].fy, v->vf [ i.Fs ].fx,  v->vf [ i.Ft ].fz, 2, & v->vi [ 16 ].sLo, & v->vi [ 17 ].sLo );
	
	// fd_z = ACC_z - fs_x * ft_y
	fd_z = PS2_Float_Msub ( v->dACC [ 2 ].f, v->vf [ i.Fd ].fz, v->vf [ i.Fs ].fx,  v->vf [ i.Ft ].fy, 1, & v->vi [ 16 ].sLo, & v->vi [ 17 ].sLo );
	
	// now can store result without possibly corrupting registers
	v->vf [ i.Fd ].fx = fd_x;
	v->vf [ i.Fd ].fy = fd_y;
	v->vf [ i.Fd ].fz = fd_z;
	*/
	
	VuUpperOp_MSUB ( v, i, PS2_Float_Msub );
	
#if defined INLINE_DEBUG_OPMULA || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Fd=" << " vfx=" << hex << v->vf [ i.Fd ].fx << " vfy=" << v->vf [ i.Fd ].fy << " vfz=" << v->vf [ i.Fd ].fz << " vfw=" << v->vf [ i.Fd ].fw;
	debug << " MAC=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo << " STATF=" << v->vi [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].uLo;
#endif
}



static void Execute::NOP ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_NOP || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionHI ( i.Value ).c_str () << "; " << hex << i.Value;
#endif


}






//// *** LOWER instructions *** ////




// branch/jump instructions //

static void Execute::B ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_B || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

		// next instruction is in the branch delay slot
		VU::DelaySlot *d = & ( v->DelaySlots [ v->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		v->Status.DelaySlot_Valid |= 0x2;
}

static void Execute::BAL ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_BAL || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

		// next instruction is in the branch delay slot
		VU::DelaySlot *d = & ( v->DelaySlots [ v->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		v->Status.DelaySlot_Valid |= 0x2;
		
		// should probably store updated program counter divided by 8 it looks like, unless the PC is already divided by 8??
		//v->vi [ i.it ].uLo = v->PC + 16;
		v->vi [ i.it ].uLo = ( v->PC + 16 ) >> 3;
}

static void Execute::IBEQ ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_IBEQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " it=" << v->vi [ i.it ].uLo << " is=" << v->vi [ i.is ].uLo;
#endif

	if ( v->vi [ i.it ].uLo == v->vi [ i.is ].uLo )
	{
#if defined INLINE_DEBUG_IBEQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " BRANCH";
#endif

		// next instruction is in the branch delay slot
		VU::DelaySlot *d = & ( v->DelaySlots [ v->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		v->Status.DelaySlot_Valid |= 0x2;
	}
}

static void Execute::IBNE ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_IBNE || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " it=" << v->vi [ i.it ].uLo << " is=" << v->vi [ i.is ].uLo;
#endif

	if ( v->vi [ i.it ].uLo != v->vi [ i.is ].uLo )
	{
#if defined INLINE_DEBUG_IBNE || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " BRANCH";
#endif

		// next instruction is in the branch delay slot
		VU::DelaySlot *d = & ( v->DelaySlots [ v->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		v->Status.DelaySlot_Valid |= 0x2;
	}
}

static void Execute::IBLTZ ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_IBLTZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " is=" << v->vi [ i.is ].uLo;
#endif

	if ( v->vi [ i.is ].sLo < 0 )
	{
#if defined INLINE_DEBUG_IBLTZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " BRANCH";
#endif

		// next instruction is in the branch delay slot
		VU::DelaySlot *d = & ( v->DelaySlots [ v->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		v->Status.DelaySlot_Valid |= 0x2;
	}
}

static void Execute::IBGTZ ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_IBGTZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " is=" << v->vi [ i.is ].uLo;
#endif

	if ( v->vi [ i.is ].sLo > 0 )
	{
#if defined INLINE_DEBUG_IBGTZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " BRANCH";
#endif

		// next instruction is in the branch delay slot
		VU::DelaySlot *d = & ( v->DelaySlots [ v->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		v->Status.DelaySlot_Valid |= 0x2;
	}
}

static void Execute::IBLEZ ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_IBLEZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " is=" << v->vi [ i.is ].uLo;
#endif

	if ( v->vi [ i.is ].sLo <= 0 )
	{
#if defined INLINE_DEBUG_IBLEZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " BRANCH";
#endif

		// next instruction is in the branch delay slot
		VU::DelaySlot *d = & ( v->DelaySlots [ v->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		v->Status.DelaySlot_Valid |= 0x2;
	}
}

static void Execute::IBGEZ ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_IBGEZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " is=" << v->vi [ i.is ].uLo;
#endif

	if ( v->vi [ i.is ].sLo >= 0 )
	{
#if defined INLINE_DEBUG_IBGEZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " BRANCH";
#endif

		// next instruction is in the branch delay slot
		VU::DelaySlot *d = & ( v->DelaySlots [ v->NextDelaySlotIndex ^ 1 ] );
		d->Instruction = i;
		//d->cb = r->_cb_Branch;
		v->Status.DelaySlot_Valid |= 0x2;
	}
}

static void Execute::JR ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_JR || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " is(hex)=" << v->vi [ i.is ].uLo;
#endif

#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
#endif
	
	// next instruction is in the branch delay slot
	VU::DelaySlot *d = & ( v->DelaySlots [ v->NextDelaySlotIndex ^ 1 ] );
	d->Instruction = i;
	//d->cb = r->_cb_JumpRegister;

	// *** todo *** check if address exception should be generated if lower 3-bits of jump address are not zero
	// will clear out lower three bits of address for now
	//d->Data = v->vi [ i.is ].uLo & ~7;
	d->Data = v->vi [ i.is ].uLo;
	
	v->Status.DelaySlot_Valid |= 0x2;
}

static void Execute::JALR ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_JALR || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " is(hex)=" << v->vi [ i.is ].uLo;
#endif

#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
#endif
	
	// next instruction is in the branch delay slot
	VU::DelaySlot *d = & ( v->DelaySlots [ v->NextDelaySlotIndex ^ 1 ] );
	d->Instruction = i;
	//d->cb = r->_cb_JumpRegister;

	// *** todo *** check if address exception should be generated if lower 3-bits of jump address are not zero
	// will clear out lower three bits of address for now
	//d->Data = v->vi [ i.is ].uLo & ~7;
	d->Data = v->vi [ i.is ].uLo;
	
	v->Status.DelaySlot_Valid |= 0x2;
	
	//v->vi [ i.it ].uLo = v->PC + 16;
	v->vi [ i.it ].uLo = ( v->PC + 16 ) >> 3;
	
#if defined INLINE_DEBUG_JALR || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << hex << " Output: it(hex)=" << v->vi [ i.it ].uLo;
#endif
}









// FC/FM/FS instructions //

static void Execute::FCEQ ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_FCEQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " CF=" << v->vi [ 18 ].u;
#endif

#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
#endif

	//v->vi [ 1 ].u = ( ( ( v->vi [ 18 ].u & 0xffffff ) == i.Imm24 ) ? 1 : 0 );
	v->vi [ 1 ].u = ! ( ( v->vi [ 18 ].u ^ i.Imm24 ) & 0xffffff );
	
#if defined INLINE_DEBUG_FCEQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << hex << " Output:" << " vi1=" << v->vi [ 1 ].u;
#endif
}

static void Execute::FCAND ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_FCAND || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " CF=" << v->vi [ 18 ].u;
#endif

#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
#endif

	v->vi [ 1 ].u = ( ( v->vi [ 18 ].u & i.Imm24 ) ? 1 : 0 );
	
#if defined INLINE_DEBUG_FCAND || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << hex << " Output:" << " vi1=" << v->vi [ 1 ].u;
#endif
}

static void Execute::FCOR ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_FCOR || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " CF=" << v->vi [ 18 ].u;
#endif

#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
#endif

	v->vi [ 1 ].u = ( ( ( ( v->vi [ 18 ].u & 0xffffff ) | i.Imm24 ) == 0xffffff ) ? 1 : 0 );
	
#if defined INLINE_DEBUG_FCOR || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << hex << " Output:" << " vi1=" << v->vi [ 1 ].u;
#endif
}

static void Execute::FCGET ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_FCGET || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " CF=" << v->vi [ 18 ].u;
#endif

#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
#endif

	v->vi [ i.it ].uLo = v->vi [ 18 ].u & 0xfff;
	
#if defined INLINE_DEBUG_FCGET || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << hex << " Output:" << " it=" << v->vi [ i.it ].u;
#endif
}

static void Execute::FCSET ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_FCSET || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	//v->vi [ 18 ].u = i.Imm24;
	
	//v->FlagSave [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].FlagsAffected = VU::RF_SET_CLIP;
	//v->FlagSave [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].ClippingFlag = i.Imm24;
	v->FlagSave [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].FlagsAffected_Lower = VU::RF_SET_CLIP;
	v->FlagSave [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].FlagsSet_Lower = i.Imm24;
}

static void Execute::FMEQ ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_FMEQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " is=" << hex << v->vi [ i.is ].u << " MAC=" << v->vi [ 17 ].u;
#endif

#ifdef ENABLE_STALLS

	// set the source integer register
	v->Set_Int_SrcReg ( i.is + 32 );
	
	// make sure the source registers are available
	if ( v->TestStall_INT () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " INT-STALL ";
#endif
		// Integer pipeline stall //
		v->PipelineWait_INT ();
	}
	
	// note: no need to set destination register since instruction is on the integer pipeline
#endif

#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
#endif

	//v->vi [ i.it ].u = ~( v->vi [ i.is ].u ^ v->vi [ 17 ].u );
	v->vi [ i.it ].u = ! ( ( v->vi [ i.is ].u ^ v->vi [ 17 ].u ) & 0xffff );
	
#if defined INLINE_DEBUG_FMEQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << hex << " Output:" << " it=" << v->vi [ i.it ].u;
#endif
}

static void Execute::FMAND ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_FMAND || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " is=" << hex << v->vi [ i.is ].u << " MAC=" << v->vi [ 17 ].u;
#endif

#ifdef ENABLE_STALLS

	// set the source integer register
	v->Set_Int_SrcReg ( i.is + 32 );
	
	// make sure the source registers are available
	if ( v->TestStall_INT () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " INT-STALL ";
#endif
		// Integer pipeline stall //
		v->PipelineWait_INT ();
	}
	
	// note: no need to set destination register since instruction is on the integer pipeline
#endif

#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
#endif

	v->vi [ i.it ].u = v->vi [ i.is ].u & v->vi [ 17 ].u;
	
#if defined INLINE_DEBUG_FMAND || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << hex << " Output:" << " it=" << v->vi [ i.it ].u;
#endif
}

static void Execute::FMOR ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_FMOR || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " is=" << hex << v->vi [ i.is ].u << " MAC=" << v->vi [ 17 ].u;
#endif

#ifdef ENABLE_STALLS

	// set the source integer register
	v->Set_Int_SrcReg ( i.is + 32 );
	
	// make sure the source registers are available
	if ( v->TestStall_INT () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " INT-STALL ";
#endif
		// Integer pipeline stall //
		v->PipelineWait_INT ();
	}
	
	// note: no need to set destination register since instruction is on the integer pipeline
#endif

#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
#endif

	v->vi [ i.it ].u = v->vi [ i.is ].u | v->vi [ 17 ].u;
	
#if defined INLINE_DEBUG_FMOR || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << hex << " Output:" << " it=" << v->vi [ i.it ].u;
#endif
}

static void Execute::FSEQ ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_FSEQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " STAT=" << v->vi [ 16 ].u;
#endif

#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
#endif

	//v->vi [ i.it ].u = ~( v->vi [ 16 ].u ^ ( ( ( i.Imm15_1 << 11 ) | ( i.Imm15_0 ) ) & 0xfff ) );
	//v->vi [ i.it ].u = ( ( ( v->vi [ 16 ].u & 0xfff ) == ( ( ( i.Imm15_1 << 11 ) | ( i.Imm15_0 ) ) & 0xfff ) ) ? 1 : 0 );
	v->vi [ i.it ].u = ! ( ( v->vi [ 16 ].u ^ ( ( i.Imm15_1 << 11 ) | ( i.Imm15_0 ) ) ) & 0xfff );
	
#if defined INLINE_DEBUG_FSEQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << hex << " Output:" << " it=" << v->vi [ i.it ].u;
#endif
}

static void Execute::FSSET ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_FSSET || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	//v->vi [ 16 ].u = ( v->vi [ 16 ].u & 0x3f ) | ( ( ( i.Imm15_1 << 11 ) | ( i.Imm15_0 ) ) & 0xfc0 );
	
	//v->FlagSave [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].FlagsAffected = VU::RF_SET_STICKY;
	//v->FlagSave [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].StatusFlag = ( ( ( i.Imm15_1 << 11 ) | ( i.Imm15_0 ) ) & 0xfc0 );
	v->FlagSave [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].FlagsAffected_Lower = VU::RF_SET_STICKY;
	v->FlagSave [ v->iFlagSave_Index & v->c_lFlag_Delay_Mask ].FlagsSet_Lower = ( ( ( i.Imm15_1 << 11 ) | ( i.Imm15_0 ) ) & 0xfc0 );
}

static void Execute::FSAND ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_FSAND || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " STAT=" << v->vi [ 16 ].u;
#endif

#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
#endif

	v->vi [ i.it ].u = v->vi [ 16 ].u & ( ( ( i.Imm15_1 << 11 ) | ( i.Imm15_0 ) ) & 0xfff );
	
#if defined INLINE_DEBUG_FSAND || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << hex << " Output:" << " it=" << v->vi [ i.it ].u;
#endif
}

static void Execute::FSOR ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_FSOR || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " STAT=" << v->vi [ 16 ].u;
#endif

#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
#endif

	v->vi [ i.it ].u = v->vi [ 16 ].u | ( ( ( i.Imm15_1 << 11 ) | ( i.Imm15_0 ) ) & 0xfff );
	
#if defined INLINE_DEBUG_FSOR || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << hex << " Output:" << " it=" << v->vi [ i.it ].u;
#endif
}



// Integer math //


static void Execute::IADD ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_IADD || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " is=" << hex << v->vi [ i.is ].uLo << " it=" << v->vi [ i.it ].uLo;
#endif

#ifdef ENABLE_STALLS

	// set the source integer register
	v->Set_Int_SrcRegs ( i.is + 32, i.it + 32 );
	
	// make sure the source registers are available
	if ( v->TestStall_INT () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " INT-STALL ";
#endif
		// Integer pipeline stall //
		v->PipelineWait_INT ();
	}
	
	// note: no need to set destination register since instruction is on the integer pipeline
#endif

	// id = is + it

#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
	
	v->Set_IntDelaySlot ( i.id, v->vi [ i.is ].uLo + v->vi [ i.it ].uLo );
#else
	v->vi [ i.id ].u = v->vi [ i.is ].uLo + v->vi [ i.it ].uLo;
#endif

	
#if defined INLINE_DEBUG_IADD || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: id=" << hex << v->vi [ i.id ].uLo;
#endif
}

static void Execute::IADDI ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_IADDI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " is=" << hex << v->vi [ i.is ].uLo;
#endif

#ifdef ENABLE_STALLS

	// set the source integer register
	v->Set_Int_SrcReg ( i.is + 32 );
	
	// make sure the source registers are available
	if ( v->TestStall_INT () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " INT-STALL ";
#endif
		// Integer pipeline stall //
		v->PipelineWait_INT ();
	}
	
	// note: no need to set destination register since instruction is on the integer pipeline
#endif

	// it = is + Imm5
#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
	
	v->Set_IntDelaySlot ( i.it, v->vi [ i.is ].uLo + ( (s32) i.Imm5 ) );
#else
	v->vi [ i.it ].u = v->vi [ i.is ].uLo + ( (s32) i.Imm5 );
#endif
	
#if defined INLINE_DEBUG_IADDI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: it=" << hex << v->vi [ i.it ].uLo;
#endif
}

static void Execute::IADDIU ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_IADDI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " is=" << hex << v->vi [ i.is ].uLo;
#endif

#ifdef ENABLE_STALLS

	// set the source integer register
	v->Set_Int_SrcReg ( i.is + 32 );
	
	// make sure the source registers are available
	if ( v->TestStall_INT () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " INT-STALL ";
#endif
		// Integer pipeline stall //
		v->PipelineWait_INT ();
	}
	
	// note: no need to set destination register since instruction is on the integer pipeline
#endif

	// it = is + Imm15
#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
	
	v->Set_IntDelaySlot ( i.it, v->vi [ i.is ].uLo + ( ( i.Imm15_1 << 11 ) | ( i.Imm15_0 ) ) );
#else
	v->vi [ i.it ].u = v->vi [ i.is ].uLo + ( ( i.Imm15_1 << 11 ) | ( i.Imm15_0 ) );
#endif
	
#if defined INLINE_DEBUG_IADDI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: it=" << hex << v->vi [ i.it ].uLo;
#endif
}

static void Execute::ISUB ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ISUB || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " is=" << hex << v->vi [ i.is ].uLo << " it=" << v->vi [ i.it ].uLo;
#endif

#ifdef ENABLE_STALLS

	// set the source integer register
	v->Set_Int_SrcRegs ( i.is + 32, i.it + 32 );
	
	// make sure the source registers are available
	if ( v->TestStall_INT () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " INT-STALL ";
#endif
		// Integer pipeline stall //
		v->PipelineWait_INT ();
	}
	
	// note: no need to set destination register since instruction is on the integer pipeline
#endif

	// id = is - it
#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
	
	v->Set_IntDelaySlot ( i.id, v->vi [ i.is ].uLo - v->vi [ i.it ].uLo );
#else
	v->vi [ i.id ].u = v->vi [ i.is ].uLo - v->vi [ i.it ].uLo;
#endif
	
#if defined INLINE_DEBUG_ISUB || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: id=" << hex << v->vi [ i.id ].uLo;
#endif
}

static void Execute::ISUBIU ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ISUBIU || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " is=" << hex << v->vi [ i.is ].uLo;
#endif

#ifdef ENABLE_STALLS

	// set the source integer register
	v->Set_Int_SrcReg ( i.is + 32 );
	
	// make sure the source registers are available
	if ( v->TestStall_INT () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " INT-STALL ";
#endif
		// Integer pipeline stall //
		v->PipelineWait_INT ();
	}
	
	// note: no need to set destination register since instruction is on the integer pipeline
#endif

	// it = is - Imm15
#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
	
	v->Set_IntDelaySlot ( i.it, v->vi [ i.is ].uLo - ( ( i.Imm15_1 << 11 ) | ( i.Imm15_0 ) ) );
#else
	v->vi [ i.it ].u = v->vi [ i.is ].uLo - ( ( i.Imm15_1 << 11 ) | ( i.Imm15_0 ) );
#endif
	
#if defined INLINE_DEBUG_ISUBIU || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: it=" << hex << v->vi [ i.it ].uLo;
#endif
}


static void Execute::IAND ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_IAND || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " is=" << hex << v->vi [ i.is ].uLo << " it=" << v->vi [ i.it ].uLo;
#endif

#ifdef ENABLE_STALLS

	// set the source integer register
	v->Set_Int_SrcRegs ( i.is + 32, i.it + 32 );
	
	// make sure the source registers are available
	if ( v->TestStall_INT () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " INT-STALL ";
#endif
		// Integer pipeline stall //
		v->PipelineWait_INT ();
	}
	
	// note: no need to set destination register since instruction is on the integer pipeline
#endif

	// id = is & it
#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
	
	v->Set_IntDelaySlot ( i.id, v->vi [ i.is ].uLo & v->vi [ i.it ].uLo );
#else
	v->vi [ i.id ].u = v->vi [ i.is ].uLo & v->vi [ i.it ].uLo;
#endif
	
#if defined INLINE_DEBUG_IAND || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: id=" << hex << v->vi [ i.id ].uLo;
#endif
}

static void Execute::IOR ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_IOR || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " is=" << hex << v->vi [ i.is ].uLo << " it=" << v->vi [ i.it ].uLo;
#endif

#ifdef ENABLE_STALLS

	// set the source integer register
	v->Set_Int_SrcRegs ( i.is + 32, i.it + 32 );
	
	// make sure the source registers are available
	if ( v->TestStall_INT () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " INT-STALL ";
#endif
		// Integer pipeline stall //
		v->PipelineWait_INT ();
	}
	
	// note: no need to set destination register since instruction is on the integer pipeline
#endif

	// id = is | it
#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
	
	v->Set_IntDelaySlot ( i.id, v->vi [ i.is ].uLo | v->vi [ i.it ].uLo );
#else
	v->vi [ i.id ].u = v->vi [ i.is ].uLo | v->vi [ i.it ].uLo;
#endif
	
#if defined INLINE_DEBUG_IOR || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: id=" << hex << v->vi [ i.id ].uLo;
#endif
}



// STORE (to integer) instructions //

static void Execute::ISWR ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ISWR || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Base=" << v->vi [ i.is ].uLo << " it=" << v->vi [ i.it ].uLo;
#endif

	// ISWR itdest, (is)
	// do Imm11 x16
	
	u32 StoreAddress;
	u32* pVuMem32;
	
#ifdef ENABLE_STALLS

	// set the source integer register
	v->Set_Int_SrcRegs ( i.is + 32, i.it + 32 );
	
	// make sure the source registers are available
	if ( v->TestStall_INT () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " INT-STALL ";
#endif
		// Integer pipeline stall //
		v->PipelineWait_INT ();
	}
	
	// note: don't want to set destination register until after upper instruction is executed!!!
#endif

#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
#endif

	StoreAddress = v->vi [ i.is ].uLo << 2;
	
	pVuMem32 = v->GetMemPtr ( StoreAddress );
	
	if ( i.destx ) pVuMem32 [ 0 ] = v->vi [ i.it ].uLo;
	if ( i.desty ) pVuMem32 [ 1 ] = v->vi [ i.it ].uLo;
	if ( i.destz ) pVuMem32 [ 2 ] = v->vi [ i.it ].uLo;
	if ( i.destw ) pVuMem32 [ 3 ] = v->vi [ i.it ].uLo;
}


static void Execute::ISW ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ISW || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Base=" << v->vi [ i.is ].uLo << " it=" << v->vi [ i.it ].uLo;
	debug << hex << " SA=" << ( v->vi [ i.is ].sLo + i.Imm11 );
#endif

	// ISW itdest, Imm11(is)
	// do Imm11 x16
	
	u32 StoreAddress;
	u32* pVuMem32;
	
#ifdef ENABLE_STALLS

	// set the source integer register
	v->Set_Int_SrcRegs ( i.is + 32, i.it + 32 );
	
	// make sure the source registers are available
	if ( v->TestStall_INT () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " INT-STALL ";
#endif
		// Integer pipeline stall //
		v->PipelineWait_INT ();
	}
	
	// note: don't want to set destination register until after upper instruction is executed!!!
#endif

#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
#endif

	StoreAddress = ( v->vi [ i.is ].sLo + i.Imm11 ) << 2;
	
	pVuMem32 = v->GetMemPtr ( StoreAddress );
	
	if ( i.destx ) pVuMem32 [ 0 ] = v->vi [ i.it ].uLo;
	if ( i.desty ) pVuMem32 [ 1 ] = v->vi [ i.it ].uLo;
	if ( i.destz ) pVuMem32 [ 2 ] = v->vi [ i.it ].uLo;
	if ( i.destw ) pVuMem32 [ 3 ] = v->vi [ i.it ].uLo;
}


// STORE (to float) instructions //

static void Execute::SQ ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_SQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " it=" << v->vi [ i.it ].uLo << " fs=" << v->vf [ i.Fs ].uw0 << " " << v->vf [ i.Fs ].uw1 << " " << v->vf [ i.Fs ].uw2 << " " << v->vf [ i.Fs ].uw3;
	debug << hex << " SA=" << ( v->vi [ i.it ].sLo + i.Imm11 );
#endif

	// SQ fsdest, Imm11(it)
	// do Imm11 x16
	
	u32 StoreAddress;
	u32* pVuMem32;
	
#ifdef ENABLE_STALLS
	// set the source register(s)
	v->Set_SrcReg ( i.Value, i.Fs );
	
	// set the source integer register
	v->Set_Int_SrcReg ( i.it + 32 );
	
	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// make sure the source registers are available
	if ( v->TestStall_INT () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " INT-STALL ";
#endif
		// Integer pipeline stall //
		v->PipelineWait_INT ();
	}
	
	// todo: can set the MAC and STATUS flags registers as being modified also if needed later
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
#endif

#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
#endif

	StoreAddress = ( v->vi [ i.it ].sLo + i.Imm11 ) << 2;
	
	pVuMem32 = v->GetMemPtr ( StoreAddress );
	
	if ( i.destx ) pVuMem32 [ 0 ] = v->vf [ i.Fs ].uw0;
	if ( i.desty ) pVuMem32 [ 1 ] = v->vf [ i.Fs ].uw1;
	if ( i.destz ) pVuMem32 [ 2 ] = v->vf [ i.Fs ].uw2;
	if ( i.destw ) pVuMem32 [ 3 ] = v->vf [ i.Fs ].uw3;
}


static void Execute::SQD ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_SQD || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " it=" << v->vi [ i.it ].uLo << " fs=" << v->vf [ i.Fs ].uw0 << " " << v->vf [ i.Fs ].uw1 << " " << v->vf [ i.Fs ].uw2 << " " << v->vf [ i.Fs ].uw3;
	debug << hex << " SA=" << (v->vi [ i.it ].uLo-1);
#endif

	// SQD fsdest, (--it)
	// do Imm11 x16
	
	u32 StoreAddress;
	u32* pVuMem32;
	
#ifdef ENABLE_STALLS
	// set the source register(s)
	v->Set_SrcReg ( i.Value, i.Fs );
	
	// set the source integer register
	v->Set_Int_SrcReg ( i.it + 32 );
	
	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// make sure the source registers are available
	if ( v->TestStall_INT () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " INT-STALL ";
#endif
		// Integer pipeline stall //
		v->PipelineWait_INT ();
	}
	
	// todo: can set the MAC and STATUS flags registers as being modified also if needed later
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
#endif

	// pre-decrement
#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
	
	v->Set_IntDelaySlot ( i.it, v->vi [ i.it ].uLo - 1 );
	StoreAddress = ( v->vi [ i.it ].uLo - 1 ) << 2;
#else
	v->vi [ i.it ].uLo--;
	
	StoreAddress = v->vi [ i.it ].uLo << 2;
#endif
	
	pVuMem32 = v->GetMemPtr ( StoreAddress );
	
	if ( i.destx ) pVuMem32 [ 0 ] = v->vf [ i.Fs ].uw0;
	if ( i.desty ) pVuMem32 [ 1 ] = v->vf [ i.Fs ].uw1;
	if ( i.destz ) pVuMem32 [ 2 ] = v->vf [ i.Fs ].uw2;
	if ( i.destw ) pVuMem32 [ 3 ] = v->vf [ i.Fs ].uw3;
}


static void Execute::SQI ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_SQI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " it=" << v->vi [ i.it ].uLo << " fs(hex)=" << v->vf [ i.Fs ].uw0 << " " << v->vf [ i.Fs ].uw1 << " " << v->vf [ i.Fs ].uw2 << " " << v->vf [ i.Fs ].uw3;
	debug << dec << " fs(dec)=" << v->vf [ i.Fs ].fx << " " << v->vf [ i.Fs ].fy << " " << v->vf [ i.Fs ].fz << " " << v->vf [ i.Fs ].fw;
	debug << hex << " SA=" << v->vi [ i.it ].uLo;
#endif

	// SQD fsdest, (it++)
	// do Imm11 x16
	
	u32 StoreAddress;
	u32* pVuMem32;
	
#ifdef ENABLE_STALLS
	// set the source register(s)
	v->Set_SrcReg ( i.Value, i.Fs );
	
	// set the source integer register
	v->Set_Int_SrcReg ( i.it + 32 );
	
	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// make sure the source registers are available
	if ( v->TestStall_INT () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " INT-STALL ";
#endif
		// Integer pipeline stall //
		v->PipelineWait_INT ();
	}
	
	// todo: can set the MAC and STATUS flags registers as being modified also if needed later
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
#endif

#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
#endif

	StoreAddress = v->vi [ i.it ].uLo << 2;
	
	pVuMem32 = v->GetMemPtr ( StoreAddress );
	
	if ( i.destx ) pVuMem32 [ 0 ] = v->vf [ i.Fs ].uw0;
	if ( i.desty ) pVuMem32 [ 1 ] = v->vf [ i.Fs ].uw1;
	if ( i.destz ) pVuMem32 [ 2 ] = v->vf [ i.Fs ].uw2;
	if ( i.destw ) pVuMem32 [ 3 ] = v->vf [ i.Fs ].uw3;
	
	// post-increment
#ifdef ENABLE_INTDELAYSLOT
	
	v->Set_IntDelaySlot ( i.it, v->vi [ i.it ].uLo + 1 );
#else
	v->vi [ i.it ].uLo++;
#endif

}



// LOAD (to integer) instructions //

static void Execute::ILWR ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ILWR || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Base=" << v->vi [ i.is ].uLo;
#endif

	// ILWR itdest, (is)
	// do Imm11 x16
	
	u32 LoadAddress;
	u32* pVuMem32;

#ifdef ENABLE_STALLS

	// TODO: check if the source register is ready for use or if a stall is needed
	
	// set the source integer register
	v->Set_Int_SrcReg ( i.is + 32 );
	
	// make sure the source registers are available
	if ( v->TestStall_INT () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " INT-STALL ";
#endif
		// Integer pipeline stall //
		v->PipelineWait_INT ();
	}

	// integer register load takes 4 cycles
	// integer register is +32 in the bitmap
	v->Set_DestReg_Lower ( i.it + 32 );
#endif

#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
#endif
	
	LoadAddress = v->vi [ i.is ].uLo << 2;
	
	pVuMem32 = v->GetMemPtr ( LoadAddress );
	
#ifdef ENABLE_INTDELAYSLOT
	if ( i.destx ) v->Set_IntDelaySlot ( i.it, pVuMem32 [ 0 ] );
	if ( i.desty ) v->Set_IntDelaySlot ( i.it, pVuMem32 [ 1 ] );
	if ( i.destz ) v->Set_IntDelaySlot ( i.it, pVuMem32 [ 2 ] );
	if ( i.destw ) v->Set_IntDelaySlot ( i.it, pVuMem32 [ 3 ] );
#else
	if ( i.destx ) v->vi [ i.it ].uLo = pVuMem32 [ 0 ];
	if ( i.desty ) v->vi [ i.it ].uLo = pVuMem32 [ 1 ];
	if ( i.destz ) v->vi [ i.it ].uLo = pVuMem32 [ 2 ];
	if ( i.destw ) v->vi [ i.it ].uLo = pVuMem32 [ 3 ];
#endif


#if defined INLINE_DEBUG_ILWR || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output:" << " it=" << v->vi [ i.it ].uLo;
#endif
}


static void Execute::ILW ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ILW || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " Base=" << v->vi [ i.is ].uLo;
	debug << hex << " LA=" << ( v->vi [ i.is ].sLo + i.Imm11 );
#endif

	// ILW itdest, Imm11(is)
	// do Imm11 x16
	
	u32 LoadAddress;
	u32* pVuMem32;
	
#ifdef ENABLE_STALLS

	// TODO: check if the source register is ready for use or if a stall is needed
	
	// set the source integer register
	v->Set_Int_SrcReg ( i.is + 32 );
	
	// make sure the source registers are available
	if ( v->TestStall_INT () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " INT-STALL ";
#endif
		// Integer pipeline stall //
		v->PipelineWait_INT ();
	}

	// integer register load takes 4 cycles
	// integer register is +32 in the bitmap
	v->Set_DestReg_Lower ( i.it + 32 );
#endif

#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
#endif
	
	LoadAddress = ( v->vi [ i.is ].sLo + i.Imm11 ) << 2;
	
	pVuMem32 = v->GetMemPtr ( LoadAddress );
	
#ifdef ENABLE_INTDELAYSLOT
	if ( i.destx ) v->Set_IntDelaySlot ( i.it, pVuMem32 [ 0 ] );
	if ( i.desty ) v->Set_IntDelaySlot ( i.it, pVuMem32 [ 1 ] );
	if ( i.destz ) v->Set_IntDelaySlot ( i.it, pVuMem32 [ 2 ] );
	if ( i.destw ) v->Set_IntDelaySlot ( i.it, pVuMem32 [ 3 ] );
#else
	if ( i.destx ) v->vi [ i.it ].uLo = pVuMem32 [ 0 ];
	if ( i.desty ) v->vi [ i.it ].uLo = pVuMem32 [ 1 ];
	if ( i.destz ) v->vi [ i.it ].uLo = pVuMem32 [ 2 ];
	if ( i.destw ) v->vi [ i.it ].uLo = pVuMem32 [ 3 ];
#endif
	
#if defined INLINE_DEBUG_ILW || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output:" << " it=" << v->vi [ i.it ].uLo;
#endif
}


// LOAD (to float) instructions //

static void Execute::Execute_LoadDelaySlot ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_LD || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n(LoadMoveDelaySlot)" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	// disable the quick delay slot
	v->Status.EnableLoadMoveDelaySlot = 0;

	// only perform transfer if the upper instruction does not write to same register as lower instruction
	// also must check the field, because it only cancels if it writes to the same field as upper instruction?? - no, incorrect
	//if ( ( !( i.Value & iHi.Value & ( 0xf << 21 ) ) ) || ( i.Ft != iHi.Ft ) )
	if ( ! ( v->FlagSave [ v->iFlagSave_Index & VU::c_lFlag_Delay_Mask ].Int_Bitmap & ( 1 << i.Ft ) ) )
	{
		if ( i.destx ) v->vf [ i.Ft ].uw0 = v->LoadMoveDelayReg.uw0;
		if ( i.desty ) v->vf [ i.Ft ].uw1 = v->LoadMoveDelayReg.uw1;
		if ( i.destz ) v->vf [ i.Ft ].uw2 = v->LoadMoveDelayReg.uw2;
		if ( i.destw ) v->vf [ i.Ft ].uw3 = v->LoadMoveDelayReg.uw3;
		
#ifdef ENABLE_STALLS

	// must set this AFTER checking if instruction should be cancelled
	
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
	v->Set_DestReg_Upper ( i.Value, i.Ft );
#endif
	}
	else
	{
#if defined INLINE_DEBUG_LD || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
		debug << " CANCELLED ";
#endif
	}


	// must clear this absolute last
	//v->UpperDest_Bitmap = 0;

#if defined INLINE_DEBUG_LD || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << hex << " ft(hex)=" << v->vf [ i.Ft ].uw0 << " " << v->vf [ i.Ft ].uw1 << " " << v->vf [ i.Ft ].uw2 << " " << v->vf [ i.Ft ].uw3;
	debug << dec << " ft(dec)=" << v->vf [ i.Ft ].fx << " " << v->vf [ i.Ft ].fy << " " << v->vf [ i.Ft ].fz << " " << v->vf [ i.Ft ].fw;
#endif
}

static void Execute::LQ ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_LQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " is=" << v->vi [ i.is ].uLo;
	debug << hex << " LA=" << ( v->vi [ i.is ].sLo + i.Imm11 );
#endif

	// LQ ftdest, Imm11(is)
	// do Imm11 x16
	
	u32 LoadAddress;
	u32* pVuMem32;
	
#ifdef ENABLE_STALLS

	// set the source integer register
	v->Set_Int_SrcReg ( i.is + 32 );
	
	// make sure the source registers are available
	if ( v->TestStall_INT () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " INT-STALL ";
#endif
		// Integer pipeline stall //
		v->PipelineWait_INT ();
	}
	
	// note: don't want to set destination register until after upper instruction is executed!!!
#endif

#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
#endif

	LoadAddress = ( v->vi [ i.is ].sLo + i.Imm11 ) << 2;
	
	pVuMem32 = v->GetMemPtr ( LoadAddress );
	
#ifdef ENABLE_STALLS
	if ( i.destx ) v->LoadMoveDelayReg.uw0 = pVuMem32 [ 0 ];
	if ( i.desty ) v->LoadMoveDelayReg.uw1 = pVuMem32 [ 1 ];
	if ( i.destz ) v->LoadMoveDelayReg.uw2 = pVuMem32 [ 2 ];
	if ( i.destw ) v->LoadMoveDelayReg.uw3 = pVuMem32 [ 3 ];
	
	// enable the quick delay slot
	v->Status.EnableLoadMoveDelaySlot = 1;
#else
	// TODO: this should only happen AFTER upper instruction is executed probably!!!
	if ( i.destx ) v->vf [ i.Ft ].uw0 = pVuMem32 [ 0 ];
	if ( i.desty ) v->vf [ i.Ft ].uw1 = pVuMem32 [ 1 ];
	if ( i.destz ) v->vf [ i.Ft ].uw2 = pVuMem32 [ 2 ];
	if ( i.destw ) v->vf [ i.Ft ].uw3 = pVuMem32 [ 3 ];
#endif
	
#if defined INLINE_DEBUG_LQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << hex << " ft(hex)=" << v->vf [ i.Ft ].uw0 << " " << v->vf [ i.Ft ].uw1 << " " << v->vf [ i.Ft ].uw2 << " " << v->vf [ i.Ft ].uw3;
	debug << dec << " ft(dec)=" << v->vf [ i.Ft ].fx << " " << v->vf [ i.Ft ].fy << " " << v->vf [ i.Ft ].fz << " " << v->vf [ i.Ft ].fw;
#endif
}

static void Execute::LQD ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_LQD || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " is=" << v->vi [ i.is ].uLo;
	debug << hex << " LA=" << (v->vi [ i.is ].uLo-1);
#endif

	// LQD ftdest, (--is)
	// do Imm11 x16
	
	u32 LoadAddress;
	u32* pVuMem32;
	
#ifdef ENABLE_STALLS

	// set the source integer register
	v->Set_Int_SrcReg ( i.is + 32 );
	
	// make sure the source registers are available
	if ( v->TestStall_INT () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " INT-STALL ";
#endif
		// Integer pipeline stall //
		v->PipelineWait_INT ();
	}
	
	// note: don't want to set destination register until after upper instruction is executed!!!
#endif

	// pre-decrement
#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
	
	v->Set_IntDelaySlot ( i.is, v->vi [ i.is ].uLo - 1 );
	LoadAddress = ( v->vi [ i.is ].uLo - 1 ) << 2;
#else
	v->vi [ i.is ].uLo--;
	
	LoadAddress = v->vi [ i.is ].uLo << 2;
#endif
	
	pVuMem32 = v->GetMemPtr ( LoadAddress );
	
#ifdef ENABLE_STALLS
	if ( i.destx ) v->LoadMoveDelayReg.uw0 = pVuMem32 [ 0 ];
	if ( i.desty ) v->LoadMoveDelayReg.uw1 = pVuMem32 [ 1 ];
	if ( i.destz ) v->LoadMoveDelayReg.uw2 = pVuMem32 [ 2 ];
	if ( i.destw ) v->LoadMoveDelayReg.uw3 = pVuMem32 [ 3 ];
	
	// enable the quick delay slot
	v->Status.EnableLoadMoveDelaySlot = 1;
#else
	if ( i.destx ) v->vf [ i.Ft ].uw0 = pVuMem32 [ 0 ];
	if ( i.desty ) v->vf [ i.Ft ].uw1 = pVuMem32 [ 1 ];
	if ( i.destz ) v->vf [ i.Ft ].uw2 = pVuMem32 [ 2 ];
	if ( i.destw ) v->vf [ i.Ft ].uw3 = pVuMem32 [ 3 ];
#endif
	
#if defined INLINE_DEBUG_LQD || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << hex << " Output:" << " ft=" << v->vf [ i.Ft ].uw0 << " " << v->vf [ i.Ft ].uw1 << " " << v->vf [ i.Ft ].uw2 << " " << v->vf [ i.Ft ].uw3;
#endif
}

static void Execute::LQI ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_LQI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " is=" << v->vi [ i.is ].uLo;
	debug << hex << " LA=" << v->vi [ i.is ].uLo;
#endif

	// LQI ftdest, (is++)
	// do Imm11 x16
	
	u32 LoadAddress;
	u32* pVuMem32;
	
#ifdef ENABLE_STALLS

	// set the source integer register
	v->Set_Int_SrcReg ( i.is + 32 );
	
	// make sure the source registers are available
	if ( v->TestStall_INT () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " INT-STALL ";
#endif
		// Integer pipeline stall //
		v->PipelineWait_INT ();
	}
	
	// note: don't want to set destination register until after upper instruction is executed!!!
#endif

#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
#endif

	LoadAddress = v->vi [ i.is ].uLo << 2;
	
	pVuMem32 = v->GetMemPtr ( LoadAddress );
	
#ifdef ENABLE_STALLS
	if ( i.destx ) v->LoadMoveDelayReg.uw0 = pVuMem32 [ 0 ];
	if ( i.desty ) v->LoadMoveDelayReg.uw1 = pVuMem32 [ 1 ];
	if ( i.destz ) v->LoadMoveDelayReg.uw2 = pVuMem32 [ 2 ];
	if ( i.destw ) v->LoadMoveDelayReg.uw3 = pVuMem32 [ 3 ];
	
	// enable the quick delay slot
	v->Status.EnableLoadMoveDelaySlot = 1;
#else
	if ( i.destx ) v->vf [ i.Ft ].uw0 = pVuMem32 [ 0 ];
	if ( i.desty ) v->vf [ i.Ft ].uw1 = pVuMem32 [ 1 ];
	if ( i.destz ) v->vf [ i.Ft ].uw2 = pVuMem32 [ 2 ];
	if ( i.destw ) v->vf [ i.Ft ].uw3 = pVuMem32 [ 3 ];
#endif
	
	// post-increment
#ifdef ENABLE_INTDELAYSLOT
	
	v->Set_IntDelaySlot ( i.is, v->vi [ i.is ].uLo + 1 );
#else
	v->vi [ i.is ].uLo++;
#endif
	
#if defined INLINE_DEBUG_LQI || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << hex << " Output:" << " ft(hex)=" << v->vf [ i.Ft ].uw0 << " " << v->vf [ i.Ft ].uw1 << " " << v->vf [ i.Ft ].uw2 << " " << v->vf [ i.Ft ].uw3;
	debug << dec << " ft(dec)=" << v->vf [ i.Ft ].fx << " " << v->vf [ i.Ft ].fy << " " << v->vf [ i.Ft ].fz << " " << v->vf [ i.Ft ].fw;
#endif
}










// MOVE (to float) instructions //


static void Execute::MFP ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MFP || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " vfx=" << hex << v->vf [ i.Fs ].fx << " vfy=" << v->vf [ i.Fs ].fy << " vfz=" << v->vf [ i.Fs ].fz << " vfw=" << v->vf [ i.Fs ].fw;
	debug << " P=" << hex << v->vi [ VU::REG_P ].u << " " << dec << v->vi [ VU::REG_P ].f;
#endif

	// dest ft = P
	
	// the MFP instruction does NOT wait until the EFU unit is done executing
	// also need to check timing of EFU instructions
	/*
#ifdef ENABLE_STALLS
	// if the EFU unit is still running, then need to wait until it finishes first
	if ( ( (s64)v->CycleCount ) < ( (s64)v->PBusyUntil_Cycle ) )
	{
		// EFU unit is already busy //
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		
		// wait until EFU unit is done with what it is doing
		v->PipelineWaitP ();
	}
	
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
	// note: must do this AFTER upper instruction is executed if it does not cancel the instruction
	//v->Set_DestReg_Upper ( i.Value, i.Ft );
#endif
	*/
	
#ifdef ENABLE_STALLS
	if ( i.destx ) v->LoadMoveDelayReg.uw0 = v->vi [ VU::REG_P ].u;
	if ( i.desty ) v->LoadMoveDelayReg.uw1 = v->vi [ VU::REG_P ].u;
	if ( i.destz ) v->LoadMoveDelayReg.uw2 = v->vi [ VU::REG_P ].u;
	if ( i.destw ) v->LoadMoveDelayReg.uw3 = v->vi [ VU::REG_P ].u;
	
	// enable the quick delay slot
	v->Status.EnableLoadMoveDelaySlot = 1;
#else
	// TODO: this should only store to the float registers AFTER upper instruction has been executed probably!!!
	// but only if the instruction does not get cancelled by upper instruction
	if ( i.destx ) v->vf [ i.Ft ].uw0 = v->vi [ 23 ].u;
	if ( i.desty ) v->vf [ i.Ft ].uw1 = v->vi [ 23 ].u;
	if ( i.destz ) v->vf [ i.Ft ].uw2 = v->vi [ 23 ].u;
	if ( i.destw ) v->vf [ i.Ft ].uw3 = v->vi [ 23 ].u;
#endif
	
	// flags affected: none

#if defined INLINE_DEBUG_MFP || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Ft=" << " vfx=" << hex << v->vf [ i.Ft ].fx << " vfy=" << v->vf [ i.Ft ].fy << " vfz=" << v->vf [ i.Ft ].fz << " vfw=" << v->vf [ i.Ft ].fw;
#endif
}

static void Execute::MOVE ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MOVE || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	if ( i.Fs || i.Ft )
	debug << " vfx=" << hex << v->vf [ i.Fs ].fx << " vfy=" << v->vf [ i.Fs ].fy << " vfz=" << v->vf [ i.Fs ].fz << " vfw=" << v->vf [ i.Fs ].fw;
#endif

#ifdef ENABLE_STALLS
	// set the source register(s)
	v->Set_SrcReg ( i.Value, i.Fs );
	
	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
	// note: must do this AFTER upper instruction is executed if it does not cancel the instruction
	//v->Set_DestReg_Upper ( i.Value, i.Ft );
#endif


	// dest ft = fs
	
#ifdef ENABLE_STALLS
	if ( i.destx ) v->LoadMoveDelayReg.uw0 = v->vf [ i.Fs ].uw0;
	if ( i.desty ) v->LoadMoveDelayReg.uw1 = v->vf [ i.Fs ].uw1;
	if ( i.destz ) v->LoadMoveDelayReg.uw2 = v->vf [ i.Fs ].uw2;
	if ( i.destw ) v->LoadMoveDelayReg.uw3 = v->vf [ i.Fs ].uw3;
	
	// enable the quick delay slot
	v->Status.EnableLoadMoveDelaySlot = 1;
#else
	// TODO: this needs to write the register into a temporary register and execute the instruction after upper instruction
	// but only if the instruction does not get cancelled by upper instruction
	if ( i.destx ) v->vf [ i.Ft ].uw0 = v->vf [ i.Fs ].uw0;
	if ( i.desty ) v->vf [ i.Ft ].uw1 = v->vf [ i.Fs ].uw1;
	if ( i.destz ) v->vf [ i.Ft ].uw2 = v->vf [ i.Fs ].uw2;
	if ( i.destw ) v->vf [ i.Ft ].uw3 = v->vf [ i.Fs ].uw3;
#endif
	
	// flags affected: none

#if defined INLINE_DEBUG_MOVE || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	if ( i.Fs || i.Ft )
	debug << " Output: Ft=" << " vfx=" << hex << v->vf [ i.Ft ].fx << " vfy=" << v->vf [ i.Ft ].fy << " vfz=" << v->vf [ i.Ft ].fz << " vfw=" << v->vf [ i.Ft ].fw;
#endif
}


static void Execute::MR32 ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MOVE || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " vfx=" << hex << v->vf [ i.Fs ].fx << " vfy=" << v->vf [ i.Fs ].fy << " vfz=" << v->vf [ i.Fs ].fz << " vfw=" << v->vf [ i.Fs ].fw;
#endif

	// dest ft = fs
	
	u32 temp;
	
#ifdef ENABLE_STALLS
	// set the source register(s)
	v->Set_SrcReg ( ( ( i.Value << 1 ) & ( 0xe << 21 ) ) | ( ( i.Value >> 3 ) & ( 1 << 21 ) ), i.Fs );
	
	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// todo: can set the MAC and STATUS flags registers as being modified also if needed later
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
	// note: this should only happen AFTER the upper instruction has executed
	//v->Set_DestReg_Upper ( i.Value, i.Ft );
#endif

	// TODO: this should only store to the float registers AFTER upper instruction has been executed probably!!!
	// but only if the instruction does not get cancelled by upper instruction
	
	// must do this or data can get overwritten
	temp = v->vf [ i.Fs ].ux;
	
#ifdef ENABLE_STALLS
	if ( i.destx ) v->LoadMoveDelayReg.uw0 = v->vf [ i.Fs ].uy;
	if ( i.desty ) v->LoadMoveDelayReg.uw1 = v->vf [ i.Fs ].uz;
	if ( i.destz ) v->LoadMoveDelayReg.uw2 = v->vf [ i.Fs ].uw;
	if ( i.destw ) v->LoadMoveDelayReg.uw3 = temp;
	
	// enable the quick delay slot
	v->Status.EnableLoadMoveDelaySlot = 1;
#else
	if ( i.destx ) v->vf [ i.Ft ].ux = v->vf [ i.Fs ].uy;
	if ( i.desty ) v->vf [ i.Ft ].uy = v->vf [ i.Fs ].uz;
	if ( i.destz ) v->vf [ i.Ft ].uz = v->vf [ i.Fs ].uw;
	if ( i.destw ) v->vf [ i.Ft ].uw = temp;
#endif
	
	// flags affected: none

#if defined INLINE_DEBUG_MOVE || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Ft=" << " vfx=" << hex << v->vf [ i.Ft ].fx << " vfy=" << v->vf [ i.Ft ].fy << " vfz=" << v->vf [ i.Ft ].fz << " vfw=" << v->vf [ i.Ft ].fw;
#endif
}

static void Execute::MFIR ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MFIR || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " vi=" << hex << v->vi [ i.is ].uLo;
#endif

	// dest ft = is
	
	// TODO: this should only store to the float registers AFTER upper instruction has been executed probably!!!
	// but only if the instruction does not get cancelled by upper instruction

/*
#ifdef ENABLE_STALLS
	// set the source integer register
	v->Set_Int_SrcReg ( i.is + 32 );
	
	// make sure the source registers are available
	if ( v->TestStall_INT () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " INT-STALL ";
#endif
		// Integer pipeline stall //
		v->PipelineWait_INT ();
	}
#endif
*/

#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
#endif

	
#ifdef ENABLE_STALLS
	if ( i.destx ) v->LoadMoveDelayReg.sw0 = (s32) v->vi [ i.is ].sLo;
	if ( i.desty ) v->LoadMoveDelayReg.sw1 = (s32) v->vi [ i.is ].sLo;
	if ( i.destz ) v->LoadMoveDelayReg.sw2 = (s32) v->vi [ i.is ].sLo;
	if ( i.destw ) v->LoadMoveDelayReg.sw3 = (s32) v->vi [ i.is ].sLo;
	
	// enable the quick delay slot
	v->Status.EnableLoadMoveDelaySlot = 1;
#else
	// TODO: destination register should only be set AFTER upper instruction has executed
	if ( i.destx ) v->vf [ i.Ft ].sw0 = (s32) v->vi [ i.is ].sLo;
	if ( i.desty ) v->vf [ i.Ft ].sw1 = (s32) v->vi [ i.is ].sLo;
	if ( i.destz ) v->vf [ i.Ft ].sw2 = (s32) v->vi [ i.is ].sLo;
	if ( i.destw ) v->vf [ i.Ft ].sw3 = (s32) v->vi [ i.is ].sLo;
#endif
	
	// flags affected: none

#if defined INLINE_DEBUG_MFIR || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Ft=" << " vfx=" << hex << v->vf [ i.Ft ].sw0 << " vfy=" << v->vf [ i.Ft ].sw1 << " vfz=" << v->vf [ i.Ft ].sw2 << " vfw=" << v->vf [ i.Ft ].sw3;
#endif
}


// MOVE (to integer) instructions //

static void Execute::MTIR ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_MFIR || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fs=" << hex << v->vf [ i.Fs ].vuw [ i.fsf ];
#endif

	// fsf it = fs
	
	// todo: determine if integer register can be used by branch immediately or if you need int delay slot
#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
	
	v->Set_IntDelaySlot ( i.it, (u16) v->vf [ i.Fs ].vuw [ i.fsf ] );
#else
	// note: this should be ok, since this is a lower instruction and integer instructions are lower instructions
	// note: this instruction happens immediately, with NO stall possible
	v->vi [ i.it ].uLo = (u16) v->vf [ i.Fs ].vuw [ i.fsf ];
#endif

	// flags affected: none

#if defined INLINE_DEBUG_MFIR || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: it=" << hex << v->vi [ i.it ].uLo;
#endif
}



// Random Number instructions //

static void Execute::RGET ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_RGET || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " R=" << hex << v->vi [ VU::REG_R ].u;
#endif

	//cout << "\nhps2x64: ERROR: VU: Instruction not implemented: RGET";

#ifdef ENABLE_STALLS
	
	// todo: can set the MAC and STATUS flags registers as being modified also if needed later
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
	v->Set_DestReg_Upper ( i.Value, i.Ft );
#endif

#ifdef ENABLE_STALLS
	if ( i.destx ) v->LoadMoveDelayReg.uw0 = v->vi [ VU::REG_R ].u;
	if ( i.desty ) v->LoadMoveDelayReg.uw1 = v->vi [ VU::REG_R ].u;
	if ( i.destz ) v->LoadMoveDelayReg.uw2 = v->vi [ VU::REG_R ].u;
	if ( i.destw ) v->LoadMoveDelayReg.uw3 = v->vi [ VU::REG_R ].u;
	
	// enable the quick delay slot
	v->Status.EnableLoadMoveDelaySlot = 1;
#else
	// TODO: destination register should only be set AFTER upper instruction has executed
	if ( i.destx ) v->vf [ i.Ft ].uw0 = v->vi [ VU::REG_R ].u;
	if ( i.desty ) v->vf [ i.Ft ].uw1 = v->vi [ VU::REG_R ].u;
	if ( i.destz ) v->vf [ i.Ft ].uw2 = v->vi [ VU::REG_R ].u;
	if ( i.destw ) v->vf [ i.Ft ].uw3 = v->vi [ VU::REG_R ].u;
#endif

	/*
	if ( i.destx )
	{
		v->vf [ i.Ft ].uw0 = v->vi [ VU::REG_R ].u;
	}
	
	if ( i.desty )
	{
		v->vf [ i.Ft ].uw1 = v->vi [ VU::REG_R ].u;
	}
	
	if ( i.destz )
	{
		v->vf [ i.Ft ].uw2 = v->vi [ VU::REG_R ].u;
	}
	
	if ( i.destw )
	{
		v->vf [ i.Ft ].uw3 = v->vi [ VU::REG_R ].u;
	}
	*/
	
	// flags affected: none

#if defined INLINE_DEBUG_RGET || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Ft=" << " vfx=" << hex << v->vf [ i.Ft ].fx << " vfy=" << v->vf [ i.Ft ].fy << " vfz=" << v->vf [ i.Ft ].fz << " vfw=" << v->vf [ i.Ft ].fw;
#endif
}

static void Execute::RNEXT ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_RNEXT || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	//cout << "\nhps2x64: ERROR: VU: Instruction not implemented: RNEXT";

#ifdef ENABLE_STALLS
	
	// todo: can set the MAC and STATUS flags registers as being modified also if needed later
	// set the destination register(s)
	// note: can only set this once the pipeline is not stalled since it modifies the pipeline stage bitmap
	v->Set_DestReg_Upper ( i.Value, i.Ft );
#endif
	
	// r = r^23 + r^5 + 1 ??
	// this will fill in for now
	// *TODO* fix random number generator
	v->vi [ VU::REG_R ].u = ( 0x7f << 23 ) | ( rand () & 0x7fffff );
	
#ifdef ENABLE_STALLS
	if ( i.destx ) v->LoadMoveDelayReg.uw0 = v->vi [ VU::REG_R ].u;
	if ( i.desty ) v->LoadMoveDelayReg.uw1 = v->vi [ VU::REG_R ].u;
	if ( i.destz ) v->LoadMoveDelayReg.uw2 = v->vi [ VU::REG_R ].u;
	if ( i.destw ) v->LoadMoveDelayReg.uw3 = v->vi [ VU::REG_R ].u;
	
	// enable the quick delay slot
	v->Status.EnableLoadMoveDelaySlot = 1;
#else
	// TODO: destination register should only be set AFTER upper instruction has executed
	if ( i.destx ) v->vf [ i.Ft ].uw0 = v->vi [ VU::REG_R ].u;
	if ( i.desty ) v->vf [ i.Ft ].uw1 = v->vi [ VU::REG_R ].u;
	if ( i.destz ) v->vf [ i.Ft ].uw2 = v->vi [ VU::REG_R ].u;
	if ( i.destw ) v->vf [ i.Ft ].uw3 = v->vi [ VU::REG_R ].u;
#endif

	/*
	if ( i.destx )
	{
		v->vf [ i.Ft ].uw0 = v->vi [ VU::REG_R ].u;
	}
	
	if ( i.desty )
	{
		v->vf [ i.Ft ].uw1 = v->vi [ VU::REG_R ].u;
	}
	
	if ( i.destz )
	{
		v->vf [ i.Ft ].uw2 = v->vi [ VU::REG_R ].u;
	}
	
	if ( i.destw )
	{
		v->vf [ i.Ft ].uw3 = v->vi [ VU::REG_R ].u;
	}
	*/
	
#if defined INLINE_DEBUG_RNEXT || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_FPU	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: Ft=" << " vfx=" << hex << v->vf [ i.Ft ].fx << " vfy=" << v->vf [ i.Ft ].fy << " vfz=" << v->vf [ i.Ft ].fz << " vfw=" << v->vf [ i.Ft ].fw;
	debug << " R=" << hex << v->vi [ VU::REG_R ].u;
#endif
}

static void Execute::RINIT ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_RINIT || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fsfsf=" << hex << v->vf [ i.Fs ].vuw [ i.fsf ];
#endif

	//cout << "\nhps2x64: ERROR: VU: Instruction not implemented: RINIT";
	
	v->vi [ VU::REG_R ].u = ( 0x7f << 23 ) | ( v->vf [ i.Fs ].vuw [ i.fsf ] & 0x7fffff );
	
	// seed random number generator for now
	srand ( v->vi [ VU::REG_R ].u );

#if defined INLINE_DEBUG_RINIT || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: R=" << hex << v->vi [ VU::REG_R ].u;
#endif
}

static void Execute::RXOR ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_RXOR || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << " Fsfsf=" << hex << v->vf [ i.Fs ].vuw [ i.fsf ];
	debug << " R=" << hex << v->vi [ VU::REG_R ].u;
#endif

	//cout << "\nhps2x64: ERROR: VU: Instruction not implemented: RXOR";
	
	v->vi [ VU::REG_R ].u = ( 0x7f << 23 ) | ( ( v->vf [ i.Fs ].vuw [ i.fsf ] ^ v->vi [ VU::REG_R ].u ) & 0x7fffff );
	
#if defined INLINE_DEBUG_RXOR || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " Output: R=" << hex << v->vi [ VU::REG_R ].u;
#endif
}










// X instructions //

static void Execute::XGKICK ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_XGKICK || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

#ifdef ENABLE_STALLS

	// set the source integer register
	v->Set_Int_SrcReg ( i.is + 32 );
	
	// make sure the source registers are available
	if ( v->TestStall_INT () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " INT-STALL ";
#endif
		// Integer pipeline stall //
		v->PipelineWait_INT ();
	}
	
	// note: don't want to set destination register until after upper instruction is executed!!!
#endif

#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
#endif

#if defined INLINE_DEBUG_XGKICK || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << " vi=" << hex << v->vi [ i.is ].uLo;
#endif

	// if there is an xgkick instruction in progress, then need to complete it immediately
	if ( v->Status.XgKickDelay_Valid )
	{
		// looks like this is only supposed to write one 128-bit value to PATH1
		// no, this actually writes an entire gif packet to path1
		// the address should only be a maximum of 10-bits, so must mask
		//GPU::Path1_WriteBlock ( & v->VuMem64 [ ( v->vi [ i.is ].uLo & 0x3ff ) << 1 ] );
		GPU::Path1_WriteBlock ( & v->VuMem64 [ ( v->XgKick_Address & 0x3ff ) << 1 ] );
		
		// the previous xgkick is done with
		//v->Status.XgKickDelay_Valid = 0;
	}
	
	// need to execute xgkick instruction, but it doesn't execute completely immediately and vu keeps going
	// so for now will delay execution for an instruction or two
	v->Status.XgKickDelay_Valid = 0x2;
	v->XgKick_Address = v->vi [ i.is ].uLo;
}


static void Execute::XTOP ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_XTOP || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " TOP(hex)=" << v->VifRegs.TOP;
#endif

#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
#endif

	// it = TOP
	// this instruction is VU1 only
	v->vi [ i.it ].uLo = v->VifRegs.TOP & 0x3ff;

#if defined INLINE_DEBUG_XTOP || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << hex << " it(hex)=" << v->vi [ i.it ].uLo;
#endif
}

static void Execute::XITOP ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_XITOP || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << hex << " ITOP(hex)=" << v->VifRegs.ITOP;
#endif

#ifdef ENABLE_INTDELAYSLOT
	// execute int delay slot immediately
	v->Execute_IntDelaySlot ();
#endif

	if ( !v->Number )
	{
		// VU0 //
		v->vi [ i.it ].uLo = v->VifRegs.ITOP & 0xff;
	}
	else
	{
		// VU1 //
		v->vi [ i.it ].uLo = v->VifRegs.ITOP & 0x3ff;
	}
	
#if defined INLINE_DEBUG_XITOP || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << hex << " it(hex)=" << v->vi [ i.it ].uLo;
#endif
}





// WAIT instructions //

static void Execute::WAITP ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_WAITP || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	// TODO: still need to update cycle count
	
#ifdef ENABLE_STALLS
	//if ( ( (s64)v->CycleCount ) < ( (s64)v->PBusyUntil_Cycle ) )
	if ( v->PBusyUntil_Cycle )
	{
		// div/rsqrt/sqrt unit is already busy //
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		
		// wait until efu unit is done with what it is doing
		v->PipelineWaitP ();
	}
#else
	v->SetP ();
	//v->vi [ VU::REG_P ].f = v->NextP.f;
	//v->PBusyUntil_Cycle = -1LL;
#endif
}

static void Execute::WAITQ ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_WAITQ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	// TODO: still need to update cycle count
	
#ifdef ENABLE_STALLS
	if ( ( (s64)v->CycleCount ) < ( (s64)v->QBusyUntil_Cycle ) )
	{
		// div/rsqrt/sqrt unit is already busy //
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		
		// wait until div unit is done with what it is doing
		v->PipelineWaitQ ();
	}
#else
	v->SetQ ();
	//v->vi [ VU::REG_Q ].f = v->NextQ.f;
	//v->QBusyUntil_Cycle = -1LL;
	
	// have to also set the flags for div/sqrt/rsqrt
	//v->vi [ VU::REG_STATUSFLAG ].uLo &= ~0x30;
	//v->vi [ VU::REG_STATUSFLAG ].uLo |= v->NextQ_Flag;
#endif
}



// lower float math //

static void Execute::DIV ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_DIV || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << dec << " fs=" << ( (float&) v->vf [ i.Fs ].vuw [ i.fsf ] );
	debug << dec << " ft=" << ( (float&) v->vf [ i.Ft ].vuw [ i.ftf ] );
#endif

	// todo: update cycle count when div has to wait for a previous div (where Q=NextQ)

	static const u64 c_CycleTime = 7;

	float fs;
	float ft;
	
#ifdef ENABLE_STALLS
	// TODO: need to wait for source register(s) to be ready
	v->Set_SrcRegBC ( i.ftf, i.Ft );
	v->Add_SrcRegBC ( i.fsf, i.Fs );

	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// if the div/rsqrt/sqrt unit is still running, then need to wait until it finishes first
	if ( ( (s64)v->CycleCount ) < ( (s64)v->QBusyUntil_Cycle ) )
	{
		// div/rsqrt/sqrt unit is already busy //
#ifdef INLINE_DEBUG_STALLS
	debug << " Q-STALL ";
#endif
		
		// wait until div unit is done with what it is doing
		v->PipelineWaitQ ();
	}
#else
	// todo: update cycle count if QBusyUntil_Cycle is greater than CycleCount
	//v->vi [ VU::REG_Q ].f = v->NextQ.f;
	v->SetQ ();
#endif
	
	
	fs = (float&) v->vf [ i.Fs ].vuw [ i.fsf ];
	ft = (float&) v->vf [ i.Ft ].vuw [ i.ftf ];
	
	//v->vi [ 22 ].f = PS2_Float_Div ( fs, ft, & v->vi [ 16 ].sLo );
	v->NextQ.f = PS2_Float_Div ( fs, ft, & v->NextQ_Flag );
	v->QBusyUntil_Cycle = v->CycleCount + c_CycleTime;
	
#if defined INLINE_DEBUG_DIV || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << dec << " Q=" << v->vi [ 22 ].f;
	debug << dec << " NextQ=" << v->NextQ.f;
#endif
}

static void Execute::RSQRT ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_RSQRT || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << dec << " fs=" << ( (float&) v->vf [ i.Fs ].vuw [ i.fsf ] );
	debug << dec << " ft=" << ( (float&) v->vf [ i.Ft ].vuw [ i.ftf ] );
#endif

	static const u64 c_CycleTime = 13;

	float fs;
	float ft;
	
#ifdef ENABLE_STALLS
	// TODO: need to wait for source register(s) to be ready
	v->Set_SrcRegBC ( i.ftf, i.Ft );
	v->Add_SrcRegBC ( i.fsf, i.Fs );

	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// if the div/rsqrt/sqrt unit is still running, then need to wait until it finishes first
	if ( ( (s64)v->CycleCount ) < ( (s64)v->QBusyUntil_Cycle ) )
	{
		// div/rsqrt/sqrt unit is already busy //
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		
		// wait until div unit is done with what it is doing
		v->PipelineWaitQ ();
	}
#else
	// todo: update cycle count if QBusyUntil_Cycle is greater than CycleCount
	//v->vi [ VU::REG_Q ].f = v->NextQ.f;
	v->SetQ ();
#endif
	
	
	fs = (float&) v->vf [ i.Fs ].vuw [ i.fsf ];
	ft = (float&) v->vf [ i.Ft ].vuw [ i.ftf ];
	
	//v->vi [ 22 ].f = PS2_Float_RSqrt ( fs, ft, & v->vi [ 16 ].sLo );
	v->NextQ.f = PS2_Float_RSqrt ( fs, ft, & v->NextQ_Flag );
	v->QBusyUntil_Cycle = v->CycleCount + c_CycleTime;
	
#if defined INLINE_DEBUG_RSQRT || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << dec << " Q=" << v->vi [ 22 ].f;
	debug << dec << " NextQ=" << v->NextQ.f;
#endif
}

static void Execute::SQRT ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_SQRT || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
	debug << dec << " ft=" << ( (float&) v->vf [ i.Ft ].vuw [ i.ftf ] );
#endif

	static const u64 c_CycleTime = 7;

	float ft;
	
#ifdef ENABLE_STALLS
	// TODO: need to wait for source register(s) to be ready
	v->Set_SrcRegBC ( i.ftf, i.Ft );

	// make sure the source registers are available
	if ( v->TestStall () )
	{
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		// FMAC pipeline stall //
		v->PipelineWait_FMAC ();
	}
	
	// if the div/rsqrt/sqrt unit is still running, then need to wait until it finishes first
	if ( ( (s64) v->CycleCount ) < ( (s64) v->QBusyUntil_Cycle ) )
	{
		// div/rsqrt/sqrt unit is already busy //
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		
		// wait until div unit is done with what it is doing
		v->PipelineWaitQ ();
	}
#else
	// todo: update cycle count if QBusyUntil_Cycle is greater than CycleCount
	//v->vi [ VU::REG_Q ].f = v->NextQ.f;
	v->SetQ ();
#endif
	
	
	ft = (float&) v->vf [ i.Ft ].vuw [ i.ftf ];
	
	//v->vi [ 22 ].f = PS2_Float_Sqrt ( ft, & v->vi [ 16 ].sLo );
	v->NextQ.f = PS2_Float_Sqrt ( ft, & v->NextQ_Flag );
	v->QBusyUntil_Cycle = v->CycleCount + c_CycleTime;
	
#if defined INLINE_DEBUG_SQRT || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT	// || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << dec << " Q=" << v->vi [ 22 ].f;
	debug << dec << " NextQ=" << v->NextQ.f;
#endif
}




// External unit //

static void Execute::EATAN ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_EATAN || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	static const u64 c_CycleTime = 54;
	
	// I'll make c0 = pi/4
	static const float c_fC0 = (const float&) ((const long&) 0x3f490fdb);
	
	static const float c_fC1 = (const float&) ((const long&) 0x3f7ffff5);
	static const float c_fC2 = (const float&) ((const long&) 0xbeaaa61c);
	static const float c_fC3 = (const float&) ((const long&) 0x3e4c40a6);
	static const float c_fC4 = (const float&) ((const long&) 0xbe0e6c63);
	static const float c_fC5 = (const float&) ((const long&) 0x3dc577df);
	static const float c_fC6 = (const float&) ((const long&) 0xbd6501c4);
	static const float c_fC7 = (const float&) ((const long&) 0x3cb31652);
	static const float c_fC8 = (const float&) ((const long&) 0xbb84d7e7);

	u16 NoFlags;
	
	float fs;
	float fy1, fy2, fy3, fy4, fy5;
	float ft, ft2, ft3, ft5, ft7, ft9, ft11, ft13, ft15;

	
	//cout << "\nhps2x64: ERROR: VU: Instruction not implemented: EATAN";


#ifdef ENABLE_STALLS
	// if the EFU unit is still running, then need to wait until it finishes first
	//if ( ( (s64)v->CycleCount ) < ( (s64)v->PBusyUntil_Cycle ) )
	if ( v->PBusyUntil_Cycle )
	{
		// EFU unit is already busy //
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		
		// wait until EFU unit is done with what it is doing
		v->PipelineWaitP ();
	}
#else
	// todo: update cycle count if PBusyUntil_Cycle is greater than CycleCount
	//v->vi [ VU::REG_P ].f = v->NextP.f;
	v->SetP ();
#endif

	
	fs = (float&) v->vf [ i.Fs ].vuw [ i.fsf ];
	
	// get (x-1)/(x+1)
	ft = PS2_Float_Div ( PS2_Float_Sub ( fs, 1.0f, 0, & NoFlags, & NoFlags ), PS2_Float_Add ( fs, 1.0f, 0, & NoFlags, & NoFlags ), & NoFlags );
	
	ft2 = PS2_Float_Mul ( ft, ft, 0, & NoFlags, & NoFlags );
	ft3 = PS2_Float_Mul ( ft, ft2, 0, & NoFlags, & NoFlags );
	ft5 = PS2_Float_Mul ( ft3, ft2, 0, & NoFlags, & NoFlags );
	ft7 = PS2_Float_Mul ( ft5, ft2, 0, & NoFlags, & NoFlags );
	ft9 = PS2_Float_Mul ( ft7, ft2, 0, & NoFlags, & NoFlags );
	ft11 = PS2_Float_Mul ( ft9, ft2, 0, & NoFlags, & NoFlags );
	ft13 = PS2_Float_Mul ( ft11, ft2, 0, & NoFlags, & NoFlags );
	ft15 = PS2_Float_Mul ( ft13, ft2, 0, & NoFlags, & NoFlags );
	
	// (pi/4) + ( c1 * ft + c2 * ft^3 + c3 * ft^5 + c4 * ft^7 + c5 * ft^9 + c6 * ft^11 + c7 * ft^13 + c8 * ft^15 )
	fy1 = PS2_Float_Add ( PS2_Float_Mul ( c_fC1, ft, 0, & NoFlags, & NoFlags ), PS2_Float_Mul ( c_fC2, ft3, 0, & NoFlags, & NoFlags ), 0, & NoFlags, & NoFlags );
	fy2 = PS2_Float_Add ( PS2_Float_Mul ( c_fC3, ft5, 0, & NoFlags, & NoFlags ), PS2_Float_Mul ( c_fC4, ft7, 0, & NoFlags, & NoFlags ), 0, & NoFlags, & NoFlags );
	fy3 = PS2_Float_Add ( PS2_Float_Mul ( c_fC5, ft9, 0, & NoFlags, & NoFlags ), PS2_Float_Mul ( c_fC6, ft11, 0, & NoFlags, & NoFlags ), 0, & NoFlags, & NoFlags );
	fy4 = PS2_Float_Add ( PS2_Float_Mul ( c_fC7, ft13, 0, & NoFlags, & NoFlags ), PS2_Float_Mul ( c_fC8, ft15, 0, & NoFlags, & NoFlags ), 0, & NoFlags, & NoFlags );
	fy5 = PS2_Float_Add ( PS2_Float_Add ( fy1, fy2, 0, & NoFlags, & NoFlags ), PS2_Float_Add ( fy3, fy4, 0, & NoFlags, & NoFlags ), 0, & NoFlags, & NoFlags );
	v->NextP.f = PS2_Float_Add ( fy5, c_fC0, 0, & NoFlags, & NoFlags );
	v->PBusyUntil_Cycle = v->CycleCount + c_CycleTime;
}

static void Execute::EATANxy ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_EATANXY || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	static const u64 c_CycleTime = 54;
	
	// I'll make c0 = pi/4
	static const float c_fC0 = (const float&) ((const long&) 0x3f490fdb);
	
	static const float c_fC1 = (const float&) ((const long&) 0x3f7ffff5);
	static const float c_fC2 = (const float&) ((const long&) 0xbeaaa61c);
	static const float c_fC3 = (const float&) ((const long&) 0x3e4c40a6);
	static const float c_fC4 = (const float&) ((const long&) 0xbe0e6c63);
	static const float c_fC5 = (const float&) ((const long&) 0x3dc577df);
	static const float c_fC6 = (const float&) ((const long&) 0xbd6501c4);
	static const float c_fC7 = (const float&) ((const long&) 0x3cb31652);
	static const float c_fC8 = (const float&) ((const long&) 0xbb84d7e7);

	u16 NoFlags;
	
	float fx, fy;
	float fy1, fy2, fy3, fy4, fy5;
	float ft, ft2, ft3, ft5, ft7, ft9, ft11, ft13, ft15;

	
	//cout << "\nhps2x64: ERROR: VU: Instruction not implemented: EATANxy";


#ifdef ENABLE_STALLS
	// if the EFU unit is still running, then need to wait until it finishes first
	//if ( ( (s64)v->CycleCount ) < ( (s64)v->PBusyUntil_Cycle ) )
	if ( v->PBusyUntil_Cycle )
	{
		// EFU unit is already busy //
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		
		// wait until EFU unit is done with what it is doing
		v->PipelineWaitP ();
	}
#else
	// todo: update cycle count if PBusyUntil_Cycle is greater than CycleCount
	//v->vi [ VU::REG_P ].f = v->NextP.f;
	v->SetP ();
#endif

	
	fx = v->vf [ i.Fs ].fx;
	fy = v->vf [ i.Fs ].fy;
	
	// get (y-1)/(x+y)
	ft = PS2_Float_Div ( PS2_Float_Sub ( fy, 1.0f, 0, & NoFlags, & NoFlags ), PS2_Float_Add ( fx, fy, 0, & NoFlags, & NoFlags ), & NoFlags );
	
	ft2 = PS2_Float_Mul ( ft, ft, 0, & NoFlags, & NoFlags );
	ft3 = PS2_Float_Mul ( ft, ft2, 0, & NoFlags, & NoFlags );
	ft5 = PS2_Float_Mul ( ft3, ft2, 0, & NoFlags, & NoFlags );
	ft7 = PS2_Float_Mul ( ft5, ft2, 0, & NoFlags, & NoFlags );
	ft9 = PS2_Float_Mul ( ft7, ft2, 0, & NoFlags, & NoFlags );
	ft11 = PS2_Float_Mul ( ft9, ft2, 0, & NoFlags, & NoFlags );
	ft13 = PS2_Float_Mul ( ft11, ft2, 0, & NoFlags, & NoFlags );
	ft15 = PS2_Float_Mul ( ft13, ft2, 0, & NoFlags, & NoFlags );
	
	// (pi/4) + ( c1 * ft + c2 * ft^3 + c3 * ft^5 + c4 * ft^7 + c5 * ft^9 + c6 * ft^11 + c7 * ft^13 + c8 * ft^15 )
	fy1 = PS2_Float_Add ( PS2_Float_Mul ( c_fC1, ft, 0, & NoFlags, & NoFlags ), PS2_Float_Mul ( c_fC2, ft3, 0, & NoFlags, & NoFlags ), 0, & NoFlags, & NoFlags );
	fy2 = PS2_Float_Add ( PS2_Float_Mul ( c_fC3, ft5, 0, & NoFlags, & NoFlags ), PS2_Float_Mul ( c_fC4, ft7, 0, & NoFlags, & NoFlags ), 0, & NoFlags, & NoFlags );
	fy3 = PS2_Float_Add ( PS2_Float_Mul ( c_fC5, ft9, 0, & NoFlags, & NoFlags ), PS2_Float_Mul ( c_fC6, ft11, 0, & NoFlags, & NoFlags ), 0, & NoFlags, & NoFlags );
	fy4 = PS2_Float_Add ( PS2_Float_Mul ( c_fC7, ft13, 0, & NoFlags, & NoFlags ), PS2_Float_Mul ( c_fC8, ft15, 0, & NoFlags, & NoFlags ), 0, & NoFlags, & NoFlags );
	fy5 = PS2_Float_Add ( PS2_Float_Add ( fy1, fy2, 0, & NoFlags, & NoFlags ), PS2_Float_Add ( fy3, fy4, 0, & NoFlags, & NoFlags ), 0, & NoFlags, & NoFlags );
	v->NextP.f = PS2_Float_Add ( fy5, c_fC0, 0, & NoFlags, & NoFlags );
	v->PBusyUntil_Cycle = v->CycleCount + c_CycleTime;
}

static void Execute::EATANxz ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_EATANXZ || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	static const u64 c_CycleTime = 54;
	
	// I'll make c0 = pi/4
	static const float c_fC0 = (const float&) ((const long&) 0x3f490fdb);
	
	static const float c_fC1 = (const float&) ((const long&) 0x3f7ffff5);
	static const float c_fC2 = (const float&) ((const long&) 0xbeaaa61c);
	static const float c_fC3 = (const float&) ((const long&) 0x3e4c40a6);
	static const float c_fC4 = (const float&) ((const long&) 0xbe0e6c63);
	static const float c_fC5 = (const float&) ((const long&) 0x3dc577df);
	static const float c_fC6 = (const float&) ((const long&) 0xbd6501c4);
	static const float c_fC7 = (const float&) ((const long&) 0x3cb31652);
	static const float c_fC8 = (const float&) ((const long&) 0xbb84d7e7);

	u16 NoFlags;
	
	float fx, fz;
	float fy1, fy2, fy3, fy4, fy5;
	float ft, ft2, ft3, ft5, ft7, ft9, ft11, ft13, ft15;

	
	//cout << "\nhps2x64: ERROR: VU: Instruction not implemented: EATANxz";


#ifdef ENABLE_STALLS
	// if the EFU unit is still running, then need to wait until it finishes first
	//if ( ( (s64)v->CycleCount ) < ( (s64)v->PBusyUntil_Cycle ) )
	if ( v->PBusyUntil_Cycle )
	{
		// EFU unit is already busy //
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		
		// wait until EFU unit is done with what it is doing
		v->PipelineWaitP ();
	}
#else
	// todo: update cycle count if PBusyUntil_Cycle is greater than CycleCount
	//v->vi [ VU::REG_P ].f = v->NextP.f;
	v->SetP ();
#endif

	
	fx = v->vf [ i.Fs ].fx;
	fz = v->vf [ i.Fs ].fz;
	
	// get (z-x)/(x+z)
	ft = PS2_Float_Div ( PS2_Float_Sub ( fz, fx, 0, & NoFlags, & NoFlags ), PS2_Float_Add ( fx, fz, 0, & NoFlags, & NoFlags ), & NoFlags );
	
	ft2 = PS2_Float_Mul ( ft, ft, 0, & NoFlags, & NoFlags );
	ft3 = PS2_Float_Mul ( ft, ft2, 0, & NoFlags, & NoFlags );
	ft5 = PS2_Float_Mul ( ft3, ft2, 0, & NoFlags, & NoFlags );
	ft7 = PS2_Float_Mul ( ft5, ft2, 0, & NoFlags, & NoFlags );
	ft9 = PS2_Float_Mul ( ft7, ft2, 0, & NoFlags, & NoFlags );
	ft11 = PS2_Float_Mul ( ft9, ft2, 0, & NoFlags, & NoFlags );
	ft13 = PS2_Float_Mul ( ft11, ft2, 0, & NoFlags, & NoFlags );
	ft15 = PS2_Float_Mul ( ft13, ft2, 0, & NoFlags, & NoFlags );
	
	// (pi/4) + ( c1 * ft + c2 * ft^3 + c3 * ft^5 + c4 * ft^7 + c5 * ft^9 + c6 * ft^11 + c7 * ft^13 + c8 * ft^15 )
	fy1 = PS2_Float_Add ( PS2_Float_Mul ( c_fC1, ft, 0, & NoFlags, & NoFlags ), PS2_Float_Mul ( c_fC2, ft3, 0, & NoFlags, & NoFlags ), 0, & NoFlags, & NoFlags );
	fy2 = PS2_Float_Add ( PS2_Float_Mul ( c_fC3, ft5, 0, & NoFlags, & NoFlags ), PS2_Float_Mul ( c_fC4, ft7, 0, & NoFlags, & NoFlags ), 0, & NoFlags, & NoFlags );
	fy3 = PS2_Float_Add ( PS2_Float_Mul ( c_fC5, ft9, 0, & NoFlags, & NoFlags ), PS2_Float_Mul ( c_fC6, ft11, 0, & NoFlags, & NoFlags ), 0, & NoFlags, & NoFlags );
	fy4 = PS2_Float_Add ( PS2_Float_Mul ( c_fC7, ft13, 0, & NoFlags, & NoFlags ), PS2_Float_Mul ( c_fC8, ft15, 0, & NoFlags, & NoFlags ), 0, & NoFlags, & NoFlags );
	fy5 = PS2_Float_Add ( PS2_Float_Add ( fy1, fy2, 0, & NoFlags, & NoFlags ), PS2_Float_Add ( fy3, fy4, 0, & NoFlags, & NoFlags ), 0, & NoFlags, & NoFlags );
	v->NextP.f = PS2_Float_Add ( fy5, c_fC0, 0, & NoFlags, & NoFlags );
	v->PBusyUntil_Cycle = v->CycleCount + c_CycleTime;
}

static void Execute::EEXP ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_EEXP || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	static const u64 c_CycleTime = 44;
	
	//static const float c_fC0 = (const float&) ((const long&) 0x3f800000);
	static const float c_fC1 = (const float&) ((const long&) 0x3e7fffa8);
	static const float c_fC2 = (const float&) ((const long&) 0x3d0007f4);
	static const float c_fC3 = (const float&) ((const long&) 0x3b29d3ff);
	static const float c_fC4 = (const float&) ((const long&) 0x3933e553);
	static const float c_fC5 = (const float&) ((const long&) 0x36b63510);
	static const float c_fC6 = (const float&) ((const long&) 0x353961ac);

	u16 NoFlags;
	
	float fs;
	float fx2, fx3, fx4, fx5, fx6;
	float fy, fy2, fy4;

	
	//cout << "\nhps2x64: ERROR: VU: Instruction not implemented: EEXP";


#ifdef ENABLE_STALLS
	// if the EFU unit is still running, then need to wait until it finishes first
	//if ( ( (s64)v->CycleCount ) < ( (s64)v->PBusyUntil_Cycle ) )
	if ( v->PBusyUntil_Cycle )
	{
		// EFU unit is already busy //
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		
		// wait until EFU unit is done with what it is doing
		v->PipelineWaitP ();
	}
#else
	// todo: update cycle count if PBusyUntil_Cycle is greater than CycleCount
	//v->vi [ VU::REG_P ].f = v->NextP.f;
	v->SetP ();
#endif

	
	fs = (float&) v->vf [ i.Fs ].vuw [ i.fsf ];
	
	fx2 = PS2_Float_Mul ( fs, fs, 0, & NoFlags, & NoFlags );
	fx3 = PS2_Float_Mul ( fs, fx2, 0, & NoFlags, & NoFlags );
	fx4 = PS2_Float_Mul ( fs, fx3, 0, & NoFlags, & NoFlags );
	fx5 = PS2_Float_Mul ( fs, fx4, 0, & NoFlags, & NoFlags );
	fx6 = PS2_Float_Mul ( fs, fx5, 0, & NoFlags, & NoFlags );
	
	// 1 / ( ( 1 + c1 * x + c2 * x^2 + c3 * x^3 + c4 * x^4 + c5 * x^5 + c6 * x^6 ) ^ 4 )
	// *TODO*: should use fast floating point ?
	fy = 1.0f + ( c_fC1 * fs ) + ( c_fC2 * fx2 ) + ( c_fC3 * fx3 ) + ( c_fC4 * fx4 ) + ( c_fC5 * fx5 ) + ( c_fC6 * fx6 );
	fy2 = PS2_Float_Mul ( fy, fy, 0, & NoFlags, & NoFlags );
	fy4 = PS2_Float_Mul ( fy2, fy2, 0, & NoFlags, & NoFlags );
	v->NextP.f = PS2_Float_Div ( 1.0f, fy4, & NoFlags );
	v->PBusyUntil_Cycle = v->CycleCount + c_CycleTime;
}

static void Execute::ESIN ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ESIN || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	static const u64 c_CycleTime = 29;
	
	static const float c_fC1 = (const float&) ((const long&) 0x3f800000);
	static const float c_fC2 = (const float&) ((const long&) 0xbe2aaaa4);
	static const float c_fC3 = (const float&) ((const long&) 0x3c08873e);
	static const float c_fC4 = (const float&) ((const long&) 0xb94fb21f);
	static const float c_fC5 = (const float&) ((const long&) 0x362e9c14);

	u16 NoFlags;
	
	float fs;
	float fx2, fx3, fx5, fx7, fx9;

	
	//cout << "\nhps2x64: ERROR: VU: Instruction not implemented: ESIN";


#ifdef ENABLE_STALLS
	// if the EFU unit is still running, then need to wait until it finishes first
	//if ( ( (s64)v->CycleCount ) < ( (s64)v->PBusyUntil_Cycle ) )
	if ( v->PBusyUntil_Cycle )
	{
		// EFU unit is already busy //
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		
		// wait until EFU unit is done with what it is doing
		v->PipelineWaitP ();
	}
#else
	// todo: update cycle count if PBusyUntil_Cycle is greater than CycleCount
	//v->vi [ VU::REG_P ].f = v->NextP.f;
	v->SetP ();
#endif

	
	fs = (float&) v->vf [ i.Fs ].vuw [ i.fsf ];
	
	fx2 = PS2_Float_Mul ( fs, fs, 0, & NoFlags, & NoFlags );
	fx3 = PS2_Float_Mul ( fs, fx2, 0, & NoFlags, & NoFlags );
	fx5 = PS2_Float_Mul ( fx3, fx2, 0, & NoFlags, & NoFlags );
	fx7 = PS2_Float_Mul ( fx5, fx2, 0, & NoFlags, & NoFlags );
	fx9 = PS2_Float_Mul ( fx7, fx2, 0, & NoFlags, & NoFlags );
	
	// c1 * x + c2 * x^3 + c3 * x^5 + c4 * x^7 + c5 * x^9
	// *TODO*: should use fast floating point ?
	v->NextP.f = ( c_fC1 * fs ) + ( c_fC2 * fx3 ) + ( c_fC3 * fx5 ) + ( c_fC4 * fx7 ) + ( c_fC5 * fx9 );
	v->PBusyUntil_Cycle = v->CycleCount + c_CycleTime;
}

static void Execute::ERSQRT ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ERSQRT || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	//cout << "\nhps2x64: ERROR: VU: Instruction not implemented: ERSQRT";
	
	static const u64 c_CycleTime = 18;

	u16 NoFlags;
	float fs;
	
#ifdef ENABLE_STALLS
	// if the EFU unit is still running, then need to wait until it finishes first
	//if ( ( (s64)v->CycleCount ) < ( (s64)v->PBusyUntil_Cycle ) )
	if ( v->PBusyUntil_Cycle )
	{
		// EFU unit is already busy //
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		
		// wait until EFU unit is done with what it is doing
		v->PipelineWaitP ();
	}
#else
	// todo: update cycle count if PBusyUntil_Cycle is greater than CycleCount
	//v->vi [ VU::REG_P ].f = v->NextP.f;
	v->SetP ();
#endif
	
	fs = (float&) v->vf [ i.Fs ].vuw [ i.fsf ];
	
	v->NextP.f = PS2_Float_RSqrt ( 1.0f, fs, & NoFlags );
	v->PBusyUntil_Cycle = v->CycleCount + c_CycleTime;
}

static void Execute::ERCPR ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ERCPR || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	static const u64 c_CycleTime = 12;

	u16 NoFlags;
	float fs;
	
	//cout << "\nhps2x64: ERROR: VU: Instruction not implemented: ERCPR";
	
#ifdef ENABLE_STALLS
	// if the EFU unit is still running, then need to wait until it finishes first
	//if ( ( (s64)v->CycleCount ) < ( (s64)v->PBusyUntil_Cycle ) )
	if ( v->PBusyUntil_Cycle )
	{
		// EFU unit is already busy //
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		
		// wait until EFU unit is done with what it is doing
		v->PipelineWaitP ();
	}
#else
	// todo: update cycle count if PBusyUntil_Cycle is greater than CycleCount
	//v->vi [ VU::REG_P ].f = v->NextP.f;
	v->SetP ();
#endif
	
	fs = (float&) v->vf [ i.Fs ].vuw [ i.fsf ];
	
	// todo: need to determine what to do if 1/nan etc
	// todo: flush denormals to zero
	v->NextP.f = PS2_Float_Div ( 1.0f, fs, & NoFlags );

	v->PBusyUntil_Cycle = v->CycleCount + c_CycleTime;
}


static void Execute::ESQRT ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ESQRT || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	//cout << "\nhps2x64: ERROR: VU: Instruction not implemented: ESQRT";
	
	static const u64 c_CycleTime = 12;

	u16 NoFlags;
	float fs;
	
#ifdef ENABLE_STALLS
	// if the EFU unit is still running, then need to wait until it finishes first
	//if ( ( (s64)v->CycleCount ) < ( (s64)v->PBusyUntil_Cycle ) )
	if ( v->PBusyUntil_Cycle )
	{
		// EFU unit is already busy //
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		
		// wait until EFU unit is done with what it is doing
		v->PipelineWaitP ();
	}
#else
	// todo: update cycle count if PBusyUntil_Cycle is greater than CycleCount
	//v->vi [ VU::REG_P ].f = v->NextP.f;
	v->SetP ();
#endif
	
	fs = (float&) v->vf [ i.Fs ].vuw [ i.fsf ];
	
	v->NextP.f = PS2_Float_Sqrt ( fs, & NoFlags );
	v->PBusyUntil_Cycle = v->CycleCount + c_CycleTime;
	
}

static void Execute::ESADD ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ESADD || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	//cout << "\nhps2x64: ERROR: VU: Instruction not implemented: ESADD";

	static const u64 c_CycleTime = 11;

	u16 NoFlags;
	
#ifdef ENABLE_STALLS
	// if the EFU unit is still running, then need to wait until it finishes first
	//if ( ( (s64)v->CycleCount ) < ( (s64)v->PBusyUntil_Cycle ) )
	if ( v->PBusyUntil_Cycle )
	{
		// EFU unit is already busy //
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		
		// wait until EFU unit is done with what it is doing
		v->PipelineWaitP ();
	}
#else
	// todo: update cycle count if PBusyUntil_Cycle is greater than CycleCount
	//v->vi [ VU::REG_P ].f = v->NextP.f;
	v->SetP ();
#endif
	
	v->NextP.f = PS2_Float_Add ( PS2_Float_Add ( PS2_Float_Mul ( v->vf [ i.Fs ].fx, v->vf [ i.Fs ].fx, 0, & NoFlags, & NoFlags ) , PS2_Float_Mul ( v->vf [ i.Fs ].fy, v->vf [ i.Fs ].fy, 0, & NoFlags, & NoFlags ), 0, & NoFlags, & NoFlags ), PS2_Float_Mul ( v->vf [ i.Fs ].fz, v->vf [ i.Fs ].fz, 0, & NoFlags, & NoFlags ), 0, & NoFlags, & NoFlags );
	v->PBusyUntil_Cycle = v->CycleCount + c_CycleTime;
}

static void Execute::ERSADD ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ERSADD || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	//cout << "\nhps2x64: ERROR: VU: Instruction not implemented: ERSADD";
	
	static const u64 c_CycleTime = 18;

	u16 NoFlags;
	//float fs = (float&) v->vf [ i.Fs ].vuw [ i.fsf ];
	
#ifdef ENABLE_STALLS
	// if the EFU unit is still running, then need to wait until it finishes first
	//if ( ( (s64)v->CycleCount ) < ( (s64)v->PBusyUntil_Cycle ) )
	if ( v->PBusyUntil_Cycle )
	{
		// EFU unit is already busy //
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		
		// wait until EFU unit is done with what it is doing
		v->PipelineWaitP ();
	}
#else
	// todo: update cycle count if PBusyUntil_Cycle is greater than CycleCount
	//v->vi [ VU::REG_P ].f = v->NextP.f;
	v->SetP ();
#endif
	
	// todo: need to determine what to do if 1/nan etc
	// todo: flush denormals to zero
	v->NextP.f = PS2_Float_Div ( 1.0f, PS2_Float_Add ( PS2_Float_Add ( PS2_Float_Mul ( v->vf [ i.Fs ].fx, v->vf [ i.Fs ].fx, 0, & NoFlags, & NoFlags ) , PS2_Float_Mul ( v->vf [ i.Fs ].fy, v->vf [ i.Fs ].fy, 0, & NoFlags, & NoFlags ), 0, & NoFlags, & NoFlags ), PS2_Float_Mul ( v->vf [ i.Fs ].fz, v->vf [ i.Fs ].fz, 0, & NoFlags, & NoFlags ), 0, & NoFlags, & NoFlags ), & NoFlags );

	v->PBusyUntil_Cycle = v->CycleCount + c_CycleTime;
}


static void Execute::ESUM ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ESUM || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	//cout << "\nhps2x64: ERROR: VU: Instruction not implemented: ESUM";
	
	static const u64 c_CycleTime = 12;

	u16 NoFlags;
	
#ifdef ENABLE_STALLS
	// if the EFU unit is still running, then need to wait until it finishes first
	//if ( ( (s64)v->CycleCount ) < ( (s64)v->PBusyUntil_Cycle ) )
	if ( v->PBusyUntil_Cycle )
	{
		// EFU unit is already busy //
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		
		// wait until EFU unit is done with what it is doing
		v->PipelineWaitP ();
	}
#else
	// todo: update cycle count if PBusyUntil_Cycle is greater than CycleCount
	//v->vi [ VU::REG_P ].f = v->NextP.f;
	v->SetP ();
#endif
	
	v->NextP.f = PS2_Float_Add ( PS2_Float_Add ( v->vf [ i.Fs ].fx, v->vf [ i.Fs ].fy, 0, & NoFlags, & NoFlags ), PS2_Float_Add ( v->vf [ i.Fs ].fz, v->vf [ i.Fs ].fw, 0, & NoFlags, & NoFlags ), 0, & NoFlags, & NoFlags );
	v->PBusyUntil_Cycle = v->CycleCount + c_CycleTime;
}


static void Execute::ELENG ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ELENG || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	//cout << "\nhps2x64: ERROR: VU: Instruction not implemented: ELENG";
	
	static const u64 c_CycleTime = 18;

	u16 NoFlags;
	
#ifdef ENABLE_STALLS
	// if the EFU unit is still running, then need to wait until it finishes first
	//if ( ( (s64)v->CycleCount ) < ( (s64)v->PBusyUntil_Cycle ) )
	if ( v->PBusyUntil_Cycle )
	{
		// EFU unit is already busy //
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		
		// wait until EFU unit is done with what it is doing
		v->PipelineWaitP ();
	}
#else
	// todo: update cycle count if PBusyUntil_Cycle is greater than CycleCount
	//v->vi [ VU::REG_P ].f = v->NextP.f;
	v->SetP ();
#endif
	
	v->NextP.f = PS2_Float_Sqrt ( PS2_Float_Add ( PS2_Float_Add ( PS2_Float_Mul ( v->vf [ i.Fs ].fx, v->vf [ i.Fs ].fx, 0, & NoFlags, & NoFlags ) , PS2_Float_Mul ( v->vf [ i.Fs ].fy, v->vf [ i.Fs ].fy, 0, & NoFlags, & NoFlags ), 0, & NoFlags, & NoFlags ), PS2_Float_Mul ( v->vf [ i.Fs ].fz, v->vf [ i.Fs ].fz, 0, & NoFlags, & NoFlags ), 0, & NoFlags, & NoFlags ), & NoFlags );
	v->PBusyUntil_Cycle = v->CycleCount + c_CycleTime;
}


static void Execute::ERLENG ( VU *v, Instruction::Format i )
{
#if defined INLINE_DEBUG_ERLENG || defined INLINE_DEBUG_VU || defined INLINE_DEBUG_INT || defined INLINE_DEBUG_UNIMPLEMENTED
	debug << "\r\n" << hex << "VU#" << v->Number << " " << setw( 8 ) << v->PC << " " << dec << v->CycleCount << " " << Print::PrintInstructionLO ( i.Value ).c_str () << "; " << hex << i.Value;
#endif

	//cout << "\nhps2x64: ERROR: VU: Instruction not implemented: ERLENG";
	
	static const u64 c_CycleTime = 24;

	u16 NoFlags;
	
#ifdef ENABLE_STALLS
	// if the EFU unit is still running, then need to wait until it finishes first
	//if ( ( (s64)v->CycleCount ) < ( (s64)v->PBusyUntil_Cycle ) )
	if ( v->PBusyUntil_Cycle )
	{
		// EFU unit is already busy //
#ifdef INLINE_DEBUG_STALLS
	debug << " STALL ";
#endif
		
		// wait until EFU unit is done with what it is doing
		v->PipelineWaitP ();
	}
#else
	// todo: update cycle count if PBusyUntil_Cycle is greater than CycleCount
	//v->vi [ VU::REG_P ].f = v->NextP.f;
	v->SetP ();
#endif
	
	v->NextP.f = PS2_Float_RSqrt ( 1.0f, PS2_Float_Add ( PS2_Float_Add ( PS2_Float_Mul ( v->vf [ i.Fs ].fx, v->vf [ i.Fs ].fx, 0, & NoFlags, & NoFlags ) , PS2_Float_Mul ( v->vf [ i.Fs ].fy, v->vf [ i.Fs ].fy, 0, & NoFlags, & NoFlags ), 0, & NoFlags, & NoFlags ), PS2_Float_Mul ( v->vf [ i.Fs ].fz, v->vf [ i.Fs ].fz, 0, & NoFlags, & NoFlags ), 0, & NoFlags, & NoFlags ), & NoFlags );
	v->PBusyUntil_Cycle = v->CycleCount + c_CycleTime;
}










static const Execute::Function Execute::FunctionList []
{
	Execute::INVALID,
	
	// VU macro mode instructions //
	
	//Execute::COP2
	//Execute::QMFC2_NI, Execute::QMFC2_I, Execute::QMTC2_NI, Execute::QMTC2_I, Execute::LQC2, Execute::SQC2,
	//Execute::CALLMS, Execute::CALLMSR,
	
	// upper instructions //
	
	Execute::ABS,
	Execute::ADD, Execute::ADDi, Execute::ADDq, Execute::ADDBCX, Execute::ADDBCY, Execute::ADDBCZ, Execute::ADDBCW,
	Execute::ADDA, Execute::ADDAi, Execute::ADDAq, Execute::ADDABCX, Execute::ADDABCY, Execute::ADDABCZ, Execute::ADDABCW,
	Execute::CLIP,
	Execute::FTOI0, Execute::FTOI4, Execute::FTOI12, Execute::FTOI15,
	Execute::ITOF0, Execute::ITOF4, Execute::ITOF12, Execute::ITOF15,
	
	Execute::MADD, Execute::MADDi, Execute::MADDq, Execute::MADDBCX, Execute::MADDBCY, Execute::MADDBCZ, Execute::MADDBCW,
	Execute::MADDA, Execute::MADDAi, Execute::MADDAq, Execute::MADDABCX, Execute::MADDABCY, Execute::MADDABCZ, Execute::MADDABCW,
	Execute::MAX, Execute::MAXi, Execute::MAXBCX, Execute::MAXBCY, Execute::MAXBCZ, Execute::MAXBCW,
	Execute::MINI, Execute::MINIi, Execute::MINIBCX, Execute::MINIBCY, Execute::MINIBCZ, Execute::MINIBCW,
	
	Execute::MSUB, Execute::MSUBi, Execute::MSUBq, Execute::MSUBBCX, Execute::MSUBBCY, Execute::MSUBBCZ, Execute::MSUBBCW,
	Execute::MSUBA, Execute::MSUBAi, Execute::MSUBAq, Execute::MSUBABCX, Execute::MSUBABCY, Execute::MSUBABCZ, Execute::MSUBABCW,
	Execute::MUL, Execute::MULi, Execute::MULq, Execute::MULBCX, Execute::MULBCY, Execute::MULBCZ, Execute::MULBCW,
	Execute::MULA, Execute::MULAi, Execute::MULAq, Execute::MULABCX, Execute::MULABCY, Execute::MULABCZ, Execute::MULABCW,
	Execute::NOP, Execute::OPMSUB, Execute::OPMULA,
	Execute::SUB, Execute::SUBi, Execute::SUBq, Execute::SUBBCX, Execute::SUBBCY, Execute::SUBBCZ, Execute::SUBBCW,
	Execute::SUBA, Execute::SUBAi, Execute::SUBAq, Execute::SUBABCX, Execute::SUBABCY, Execute::SUBABCZ, Execute::SUBABCW,
	
	// lower instructions //
	
	Execute::DIV,
	Execute::IADD, Execute::IADDI, Execute::IAND,
	Execute::ILWR,
	Execute::IOR, Execute::ISUB,
	Execute::ISWR,
	Execute::LQD, Execute::LQI,
	Execute::MFIR, Execute::MOVE, Execute::MR32, Execute::MTIR,
	Execute::RGET, Execute::RINIT, Execute::RNEXT,
	Execute::RSQRT,
	Execute::RXOR,
	Execute::SQD, Execute::SQI,
	Execute::SQRT,
	Execute::WAITQ,

	// instructions not in macro mode //
	
	Execute::B, Execute::BAL,
	Execute::FCAND, Execute::FCEQ, Execute::FCGET, Execute::FCOR, Execute::FCSET,
	Execute::FMAND, Execute::FMEQ, Execute::FMOR,
	Execute::FSAND, Execute::FSEQ, Execute::FSOR, Execute::FSSET,
	Execute::IADDIU,
	Execute::IBEQ, Execute::IBGEZ, Execute::IBGTZ, Execute::IBLEZ, Execute::IBLTZ, Execute::IBNE,
	Execute::ILW,
	Execute::ISUBIU, Execute::ISW,
	Execute::JALR, Execute::JR,
	Execute::LQ,
	Execute::MFP,
	Execute::SQ,
	Execute::WAITP,
	Execute::XGKICK, Execute::XITOP, Execute::XTOP,

	// External Unit //

	Execute::EATAN, Execute::EATANxy, Execute::EATANxz, Execute::EEXP, Execute::ELENG, Execute::ERCPR, Execute::ERLENG, Execute::ERSADD,
	Execute::ERSQRT, Execute::ESADD, Execute::ESIN, Execute::ESQRT, Execute::ESUM
};





