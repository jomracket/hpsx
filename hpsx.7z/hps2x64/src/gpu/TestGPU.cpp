

#include "PS2_Gpu.h"
#include <iostream>

using namespace std;

int main ()
{

	cin.ignore();
	return 0;
}


