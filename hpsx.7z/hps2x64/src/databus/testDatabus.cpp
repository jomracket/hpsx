
#include <iostream>
#include "PS2DataBus.h"

using namespace std;


int main ( void )
{
	cout << "\ntesting";
	
	
	
	cin.ignore ();
	return 0;
}

