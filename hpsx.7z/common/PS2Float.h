

#include "types.h"
#include <math.h>


#ifndef PSFLOAT_H

#define PSFLOAT_H


#define ENABLE_FLAG_CHECK
//#define USE_DOUBLE
//#define CALC_WITH_INF


// this is for testing negation of the msub multiply result
#define NEGATE_MSUB_MULTIPLY_RESULT


namespace PS2Float
{
	static const long long c_llPS2DoubleMax = ( 1151ULL << 52 );
	static const long long c_llPS2DoubleMin = ( 897ULL << 52 );
	//static const long long c_llPS2DoubleMin = ( 1ULL << 63 ) | ( 1151ULL << 52 );
	static const long long c_llDoubleINF = ( 0x7ffULL << 52 );
	static const long long c_llDoubleAbsMask = ( 1ULL << 63 );

	static const long c_lFloatINF = ( 0xff << 23 );
	static const long c_lFloat_SignExpMask = ( 0x1ff << 23 );
	static const long c_lFloat_SignMask = 0x80000000;
	static const long c_lFloat_ExpMask = ( 0xff << 23 );
	static const long c_lFloat_MantissaMask = 0x7fffff;
	
	static const long c_lFloat_ValidMax = 0x7f7fffff;
	
	// difference between max ps2 float and next value down
	static const long c_lFloatMaxDiff = 0x73800000;
	
	// these 3 functions are from: http://cottonvibes.blogspot.com/2010/07/testing-for-nan-and-infinity-values.html
	//inline bool isNaN(float x) { return x != x; }
	//inline bool isInf(float x) { return fabs(x) == numeric_limits<float>::infinity(); }
	static inline bool isNaNorInf(float x) { return ((long&)x & 0x7fffffff) >= 0x7f800000; }
	//inline bool isNaN_d (double x) { return x != x; }
	//inline bool isInf_d (double x) { return fabs(x) == numeric_limits<float>::infinity(); }
	static inline bool isNaNorInf_d (double x) { return ((long long&)x & 0x7fffffffffffffffULL) >= 0x7ff0000000000000ULL; }
	
	
	inline static void SetFlagsOnResult_d ( double& Dd, int index, short* StatusFlag, short* MACFlag )
	{
		// set sign flags
		if ( Dd < 0.0L )
		{
			// set sign flags
			*StatusFlag |= 0x82;
			*MACFlag |= ( 1 << ( index + 4 ) );
		}
		

		// check for underflow
		// smallest float value is 2^-126 = 0x00800000
		// value as a double is 1023-126 = 897
		if ( ( ( (long long&) Dd ) & ~c_llDoubleAbsMask ) <= c_llPS2DoubleMin && ( ( (long long&) Dd ) & ~c_llDoubleAbsMask ) )
		{
			// underflow //
			*StatusFlag |= 0x104;
			*MACFlag |= ( 1 << ( index + 8 ) );
		}
		
		// check for overflow
		if ( ( ( (long long&) Dd ) & ~c_llDoubleAbsMask ) >= c_llPS2DoubleMax )
		{
			// overflow //
			*StatusFlag |= 0x208;
			*MACFlag |= ( 1 << ( index + 12 ) );
		}
		
		// set zero flags
		if ( Dd == 0.0L )
		{
			// set zero flags
			*StatusFlag |= 0x41;
			*MACFlag |= ( 1 << index );
		}
	}
	
	
	inline static void SetFlagsOnResult_f ( float& Result, int index, short* StatusFlag, short* MACFlag )
	{
		long lResult;
		
		lResult = (long&) Result;
		
		// set sign flags
		if ( lResult >> 31 )
		{
			// set sign flags
			*StatusFlag |= 0x82;
			*MACFlag |= ( 1 << ( index + 4 ) );
		}
		

		// check for underflow
		// smallest float value is 2^-126 = 0x00800000
		// value as a double is 1023-126 = 897
		if ( ( lResult & c_lFloat_MantissaMask ) && !( lResult & c_lFloat_ExpMask ) )
		{
			// underflow //
			*StatusFlag |= 0x104;
			*MACFlag |= ( 1 << ( index + 8 ) );
			
			// set to +/-0
			lResult = c_lFloat_SignMask & lResult;
		}
		
		// check for overflow
		if ( ( lResult & c_lFloat_ExpMask ) == c_lFloat_ExpMask )
		{
			// overflow //
			*StatusFlag |= 0x208;
			*MACFlag |= ( 1 << ( index + 12 ) );
			
			// set to +/-max
			lResult = c_lFloat_MantissaMask | lResult;
		}
		
		Result = (float&) lResult;
		
		// set zero flags
		if ( Result == 0.0f )
		{
			// set zero flags
			*StatusFlag |= 0x41;
			*MACFlag |= ( 1 << index );
		}
	}



	//inline static void FlushDenormal_d ( double& d1 )
	//{
	//}

	inline static void FlushDenormal_f ( float& f1 )
	{
		long lValue;
		
		lValue = (long&) f1;
		
		// check if exponent is zero
		if ( ! ( lValue & c_lFloat_ExpMask ) )
		{
			// exponent is zero, so flush value to zero //
			
			lValue &= c_lFloat_SignMask;
			
			f1 = (float&) lValue;
		}
	}

	
	inline static void FlushDenormal2_f ( float& f1, float& f2 )
	{
		FlushDenormal_f ( f1 );
		FlushDenormal_f ( f2 );
	}


	
	
	inline static void ClampValue_d ( double& d )
	{
		long long ll;
		if ( isNaNorInf_d ( d ) )
		{
			ll = ( c_llPS2DoubleMax | ( c_llDoubleAbsMask & ((long long&) d) ) );
			d = (double&) ll;
		}
	}
	
	inline static void ClampValue_f ( float& f )
	{
		long l;
		
		// ps2 treats denormals as zero
		FlushDenormal_f ( f );
		
		// check for not a number and infinity
		if ( isNaNorInf ( f ) )
		{
#ifdef CALC_WITH_INF
			//Ds.l = c_llPS2DoubleMax | ( Ds.l & c_llDoubleAbsMask );
			//fs = (float&) ( c_lFloat_SignExpMask & ( c_lFloatINF | (long&) fs ) );
			// or could just clear mantissa, or set to next valid value
			l = ( c_lFloat_SignExpMask & ( (long&) f ) );
#else
			// or set to next valid value
			l = ( c_lFloat_ValidMax | ( c_lFloat_SignMask & ( (long&) f ) ) );
#endif

			f = (float&) l;
		}
		
	}


	inline static void ClampValue2_d ( double& d1, double& d2 )
	{
		ClampValue_d ( d1 );
		ClampValue_d ( d2 );
	}

	inline static void ClampValue2_f ( float& f1, float& f2 )
	{
		ClampValue_f ( f1 );
		ClampValue_f ( f2 );
		
		// should also flush denormals to zero
		// this is handle by clamp function now
		//FlushDenormal2_f ( f1, f2 );
	}

	
	
	// PS2 floating point ADD
	inline static float PS2_Float_Add ( float fs, float ft, int index, short* StatusFlag, short* MACFlag )		//long* zero, long* sign, long* overflow, long* underflow,
									//long* zero_sticky, long* sign_sticky, long* overflow_sticky, long* underflow_sticky )
	{
		// fd = fs + ft
		
		FloatLong Result;


		ClampValue2_f ( fs, ft );
		
		Result.f = fs + ft;

#ifdef ENABLE_FLAG_CHECK

		SetFlagsOnResult_f ( Result.f, index, StatusFlag, MACFlag );
		
#endif
		
		// done?
		return Result.f;
	}

	// PS2 floating point SUB
	inline static float PS2_Float_Sub ( float fs, float ft, int index, short* StatusFlag, short* MACFlag )		//long* zero, long* sign, long* overflow, long* underflow,
										//long* zero_sticky, long* sign_sticky, long* overflow_sticky, long* underflow_sticky )
	{
		// fd = fs - ft
		
		FloatLong Result;
		

		ClampValue2_f ( fs, ft );
		
		Result.f = fs - ft;

		
#ifdef ENABLE_FLAG_CHECK


		SetFlagsOnResult_f ( Result.f, index, StatusFlag, MACFlag );

#endif
		
		// done?
		return Result.f;
	}

	// PS2 floating point MUL
	inline static float PS2_Float_Mul ( float fs, float ft, int index, short* StatusFlag, short* MACFlag )		//long* zero, long* sign, long* underflow, long* overflow,
								//long* zero_sticky, long* sign_sticky, long* underflow_sticky, long* overflow_sticky )
	{
		// fd = fs * ft
		
		FloatLong Result;
		
		ClampValue2_f ( fs, ft );
		
		Result.f = fs * ft;

		
#ifdef ENABLE_FLAG_CHECK


		SetFlagsOnResult_f ( Result.f, index, StatusFlag, MACFlag );

		
#endif
		
		// done?
		return Result.f;
	}

	// PS2 floating point MADD
	inline static float PS2_Float_Madd ( float dACC, float fd, float fs, float ft, int index, short* StatusFlag, short* MACFlag )		//long* zero, long* sign, long* underflow, long* overflow,
								//long* zero_sticky, long* sign_sticky, long* underflow_sticky, long* overflow_sticky )
	{
		// fd = ACC + fs * ft
		
		FloatLong Result;
		

		ClampValue2_f ( fs, ft );
		
		// also need to clamp accumulator
		// no, actually, you don't
		//ClampValue_f ( dACC );
		
		Result.f = fs * ft;
		
#ifdef ENABLE_FLAG_CHECK

		//SetFlagsOnResult_f ( Result.f, index, StatusFlag, MACFlag );
		
		
		// if multiply overflow, then set flags and return result
		// for now, just set flags
		if ( ( Result.l & c_lFloat_ExpMask ) == c_lFloat_ExpMask )
		{
			// multiply overflow in MADD //
			*StatusFlag |= 0x208;
			*MACFlag |= ( 1 << ( index + 12 ) );
			
			// sign flag
			if ( Result.l >> 31 )
			{
				*StatusFlag |= 0x82;
				*MACFlag |= ( 1 << ( index + 4 ) );
			}
			
			// set to +/-max
			Result.l = c_lFloat_MantissaMask | Result.l;
			
			// return result
			return Result.f;
		}
		
		
		
		// if multiply underflow, then only store ACC if it is +/-MAX, otherwise keep previous value
		// for now, just set sticky flags
		if ( ( Result.l & c_lFloat_MantissaMask ) && !( Result.l & c_lFloat_ExpMask ) )
		{
			// multiply underflow in MADD //
			
			// *note* ONLY set underflow sticky flag on underflow
			*StatusFlag |= 0x100;
			// *MACFlag |= ( 1 << ( index + 8 ) );

		}
		
#endif

		
		// perform the addition
		Result.f += dACC;



#ifdef ENABLE_FLAG_CHECK


		SetFlagsOnResult_f ( Result.f, index, StatusFlag, MACFlag );

#endif

		
		// done?
		return Result.f;
	}
	
	// PS2 floating point MSUB
	inline static float PS2_Float_Msub ( float dACC, float fd, float fs, float ft, int index, short* StatusFlag, short* MACFlag )		//long* zero, long* sign, long* underflow, long* overflow,
								//long* zero_sticky, long* sign_sticky, long* underflow_sticky, long* overflow_sticky )
	{
		// fd = ACC + fs * ft
		
		FloatLong Result;
		

		ClampValue2_f ( fs, ft );
		
		// also need to clamp accumulator
		// no, actually, you don't
		//ClampValue_f ( dACC );
		
		// probably does -fs times ft, then adds with the accumulator
#ifdef NEGATE_MSUB_MULTIPLY_RESULT
		Result.f = -( fs * ft );
#else
		Result.f = fs * ft;
#endif
		
#ifdef ENABLE_FLAG_CHECK

		//SetFlagsOnResult_f ( Result.f, index, StatusFlag, MACFlag );
		
		
		// if multiply overflow, then set flags and return result
		// for now, just set flags
		if ( ( Result.l & c_lFloat_ExpMask ) == c_lFloat_ExpMask )
		{
			// multiply overflow in MADD //
			
			// overflow flag
			*StatusFlag |= 0x208;
			*MACFlag |= ( 1 << ( index + 12 ) );
			
			// sign flag
			if ( Result.l >> 31 )
			{
				*StatusFlag |= 0x82;
				*MACFlag |= ( 1 << ( index + 4 ) );
			}
			
			// set to +/-max
			Result.l = c_lFloat_MantissaMask | Result.l;
			
			// return result
			return Result.f;
		}
		
		
		
		// if multiply underflow, then only store ACC if it is +/-MAX, otherwise keep previous value
		// for now, just set sticky flags
		if ( ( Result.l & c_lFloat_MantissaMask ) && !( Result.l & c_lFloat_ExpMask ) )
		{
			// multiply underflow in MADD //
			
			// *note* ONLY set underflow sticky flag on underflow
			*StatusFlag |= 0x100;
			// *MACFlag |= ( 1 << ( index + 8 ) );

		}
		
#endif

		
		// perform the addition
#ifdef NEGATE_MSUB_MULTIPLY_RESULT
		Result.f = dACC + Result.f;
#else
		Result.f = dACC - Result.f;
#endif



#ifdef ENABLE_FLAG_CHECK


		SetFlagsOnResult_f ( Result.f, index, StatusFlag, MACFlag );

#endif

		
		// done?
		return Result.f;
	}


	
	inline static long PS2_Float_ToInteger ( float fs )
	{
		//FloatLong Result;
		long lResult;
		
		//if ( isNaNorInf ( fs ) ) (long&) fs = ( ( (long&) fs ) & 0xff800000 );
		//if ( isNaNorInf ( ft ) ) (long&) ft = ( ( (long&) ft ) & 0xff800000 );
		
		lResult = (long&) fs;
		
		// get max
		//fResult = ( ( fs < ft ) ? fs : ft );
		if ( ( lResult & 0x7f800000 ) <= 0x4e800000 )
		{
			lResult = (long) fs;
		}
		else if ( lResult & 0x80000000 )
		{
			// set to negative integer max
			lResult = 0x80000000;
		}
		else
		{
			// set to positive integer max
			lResult = 0x7fffffff;
		}
		
		// MIN does NOT affect any flags
		
		// done?
		return lResult;
	}


	inline static float PS2_Float_Max ( float fs, float ft )
	{
		//FloatLong Result;
		float fResult;
		
		//if ( isNaNorInf ( fs ) ) (long&) fs = ( ( (long&) fs ) & 0xff800000 );
		//if ( isNaNorInf ( ft ) ) (long&) ft = ( ( (long&) ft ) & 0xff800000 );
		ClampValue2_f ( fs, ft );

		// get max
		fResult = ( ( fs > ft ) ? fs : ft );
		
		// MAX does NOT affect any flags
		
		// done?
		return fResult;
	}

	inline static float PS2_Float_Min ( float fs, float ft )
	{
		//FloatLong Result;
		float fResult;
		
		//if ( isNaNorInf ( fs ) ) (long&) fs = ( ( (long&) fs ) & 0xff800000 );
		//if ( isNaNorInf ( ft ) ) (long&) ft = ( ( (long&) ft ) & 0xff800000 );
		ClampValue2_f ( fs, ft );
		
		// get max
		fResult = ( ( fs < ft ) ? fs : ft );
		
		// MIN does NOT affect any flags
		
		// done?
		return fResult;
	}

	

	// PS2 floating point SQRT
	inline static float PS2_Float_Sqrt ( float ft, short* StatusFlag )	//long* invalid_negative, long* invalid_zero,
										//long* divide_sticky, long* invalid_negative_sticky, long* invalid_zero_sticky )
	{
		FloatLong Result;
		long l;
		float f;
		
#ifdef USE_DOUBLE
		// Q = sqrt ( ft )
		DoubleLong Dd, Ds, Dt;
		
		// convert to double
		// note: after conversion, if +/- inf/nan, should stay same
		//Ds.d = (double) fs;
		Dt.d = (double) ft;
		
		//if ( isNaNorInf_d ( Ds.d ) )
		//{
		//	Ds.l = c_llPS2DoubleMax | ( Ds.l & c_llDoubleAbsMask );
		//}
		
		if ( isNaNorInf_d ( Dt.d ) )
		{
			Dt.l = c_llPS2DoubleMax | ( Dt.l & c_llDoubleAbsMask );
		}
		
		// absolute value
		Dt.l &= ~c_llDoubleAbsMask;
		
		// sqrt the numbers
		Dd.d = sqrt ( Dt.d );
		
		// convert back to float
		// note: for now, this is cool, because...
		// *** todo *** implement proper conversion (max PS2 value of +/- INF does not convert correctly)
		Result.f = (float) Dd.d;
#else

		ClampValue_f ( ft );
		
		// absolute value of ft
		l = ( 0x7fffffff & (long&) ft );
		f = (float&) l;
		
		Result.f = sqrt ( f );

#endif
		
		// clear affected non-sticky flags
		// note: mind as well clear the sticky flag area too since this shouldn't set the actual flag
		// *StatusFlag &= ~0x30;
		*StatusFlag &= ~0xc30;
		
		// check zero division flag -> set to zero if divide by zero
		// write zero division flag -> set to zero for SQRT
		//*divide = -1;
		
		// write invalid flag (SQRT of negative number or 0/0)
		//*invalid_negative = (long&) ft;
		if ( ft < 0.0f )
		{
			*StatusFlag |= 0x410;
		}
		
		// write zero divide/invalid sticky flags
		// leave divide by zero sticky flag alone, since it did not accumulate
		//*divide_stickyflag &= -1;
		//*invalid_negative_sticky |= (long&) ft;
		
		// invalid zero is ok, since there is no divide here
		// leave sticky flag alone
		//*invalid_zero = 0;
		//*invalid_zero_sticky -> leave alone
		
		// done?
		return Result.f;
	}

	
	// PS2 floating point RSQRT
	inline static float PS2_Float_RSqrt ( float fs, float ft, short* StatusFlag )	//long* divide, long* invalid_negative, long* invalid_zero,
										//long* divide_sticky, long* invalid_negative_sticky, long* invalid_zero_sticky )
	{
		FloatLong Result;
		long l;
		float f;
		
#ifdef USE_DOUBLE
		// fd = fs + ft
		DoubleLong Dd, Ds, Dt;
		
		
		long temp1, temp2;
		
		// convert to double
		// note: after conversion, if +/- inf/nan, should stay same
		Ds.d = (double) fs;
		Dt.d = (double) ft;
		
		if ( isNaNorInf_d ( Ds.d ) )
		{
			Ds.l = c_llPS2DoubleMax | ( Ds.l & c_llDoubleAbsMask );
		}
		
		if ( isNaNorInf_d ( Dt.d ) )
		{
			Dt.l = c_llPS2DoubleMax | ( Dt.l & c_llDoubleAbsMask );
		}
		
		// absolute value
		Dt.l &= ~c_llDoubleAbsMask;
		
		// RSQRT the numbers
		Dd.d = Ds.d / sqrt ( Dt.d );
		
		// convert back to float
		// note: for now, this is cool, because...
		// *** todo *** implement proper conversion (max PS2 value of +/- INF does not convert correctly)
		Result.f = (float) Dd.d;
#else

		ClampValue2_f ( fs, ft );
		
		// absolute value of ft
		l = ( 0x7fffffff & (long&) ft );
		f = (float&) l;
		
		Result.f = fs / sqrt ( f );

#endif
		
		// clear affected non-sticky flags
		// note: mind as well clear the sticky flag area too since this shouldn't set the actual flag
		// *StatusFlag &= ~0x30;
		*StatusFlag &= ~0xc30;
		
		// write invalid flag (SQRT of negative number or 0/0)
		//*invalid_negative = (long&) ft;
		//temp1 = (long&) fs;
		//temp2 = (long&) ft;
		//*invalid_zero = temp1 | temp2;
		// *** todo ***
		//*invalid_zero = (long&) fs | (long&) ft;
		if ( ( ft < 0.0f ) || ( fs == 0.0f && ft == 0.0f ) )
		{
			*StatusFlag |= 0x410;
			
			if ( fs == 0.0f )
			{
				// make sure result is zero??
				Result.l &= 0x80000000;
			}
		}
		
		
		// write zero division flag -> set to zero for SQRT
		// write denominator
		//*divide = (long&) ft;
		if ( fs != 0.0f && ft == 0.0f )
		{
			*StatusFlag |= 0x820;
			
			// set result to +max/-max ??
			Result.l |= 0x7fffffff;
		}
		
		
		// write zero/sign sticky flags
		//*divide_sticky &= *divide;
		//*invalid_negative_sticky |= *invalid_negative;
		//*invalid_zero_sticky &= *invalid_zero;
		
		// done?
		return Result.f;
	}


	// PS2 floating point DIV
	inline static float PS2_Float_Div ( float fs, float ft, short* StatusFlag )		//long* divide, long* invalid_negative, long* invalid_zero,
										//long* divide_sticky, long* invalid_negative_sticky, long* invalid_zero_sticky )
	{
		FloatLong Result;
		
		
#ifdef USE_DOUBLE
		// fd = fs + ft
		DoubleLong Dd, Ds, Dt;
		
		// convert to double
		// note: after conversion, if +/- inf/nan, should stay same
		Ds.d = (double) fs;
		Dt.d = (double) ft;
		
		if ( isNaNorInf_d ( Ds.d ) )
		{
			Ds.l = c_llPS2DoubleMax | ( Ds.l & c_llDoubleAbsMask );
		}
		
		if ( isNaNorInf_d ( Dt.d ) )
		{
			Dt.l = c_llPS2DoubleMax | ( Dt.l & c_llDoubleAbsMask );
		}
		
		// fd = fs / ft
		Dd.d = Ds.d / Dt.d;
		
		// convert back to float
		// note: for now, this is cool, because...
		// *** todo *** implement proper conversion (max PS2 value of +/- INF does not convert correctly)
		Result.f = (float) Dd.d;
#else

		ClampValue2_f ( fs, ft );
		
		Result.f = fs / ft;
		
#endif
		
		// clear affected non-sticky flags
		// note: mind as well clear the sticky flag area too since this shouldn't set the actual flag
		// *StatusFlag &= ~0x30;
		*StatusFlag &= ~0xc30;
		
		// write zero division flag -> set to zero for SQRT
		// write denominator
		if ( ft == 0.0f )
		{
			if ( fs != 0.0f )
			{
				// set divide by zero flag //
				*StatusFlag |= 0x820;
				
				// also set result to +max or -max
				Result.l |= 0x7fffffff;
			}
			else
			{
				// set invalid flag //
				*StatusFlag |= 0x410;
				
				// set to zero ??
				Result.l &= 0x80000000;
			}
		}
		
		// done?
		return Result.f;
	}
	
	

}


#endif



