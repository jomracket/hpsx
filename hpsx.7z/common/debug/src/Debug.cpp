

#include "Debug.h"


// define this to output debug information using ofstream instead of platform API
#define USE_CFILE

// define this to ALSO output debug information into a combined file
//#define DEBUG_COMBINE

// define this to combine ALL debug information into one sequential file ONLY
// MUST also define DEBUG_COMBINE with this for it to work
//#define COMBINE_ONLY


using namespace Debug;


const char *Log::c_sCombinedFile = "CombinedMaster.txt";

int Log::iInstance = 0;
ofstream Log::cOutputCombined;



Log::Log()
{
}

Log::~Log()
{
#ifdef USE_CFILE

	if ( bEnableSplit )
	{

//#ifndef COMBINE_ONLY
	if ( cOutput.is_open () )
	{
		cOutput.close ();
	}
//#endif

	}
	
	
	if ( !bDisableCombine )
	{
	
//#ifdef DEBUG_COMBINE
	if ( cOutputCombined.is_open () )
	{
		cOutputCombined.close ();
	}
//#endif

	}

#else
	OutputFile.Close ();
#endif
}

bool Log::Create ( char* LogFileName )
{
	OutputFileName = LogFileName;
	
#ifdef USE_CFILE

	if ( bEnableSplit )
	{
	cOutput.open ( LogFileName );
	}
	
//#ifdef DEBUG_COMBINE
	if ( !iInstance )
	{
		cOutputCombined.open ( c_sCombinedFile );
	}
//#endif

	iInstance++;
#else
	//OutputFile.open ( LogFileName );
	OutputFile.Create ( LogFileName );
	//OutputFile.close ();
	ss.str("");
#endif


	return true;
}


